﻿/*
   Задача. Дана матрица n*n. Для каждой строки найти серию максимальной длинны
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    class Program
    {
        static int[,] array;
        static int n;

        /*Ввод и заполнение матрицы*/
        static void Create_Array(ref int[,] array, out int n)
        {
            do
            {
                Console.WriteLine("Введите размерность массива (N)");
                n = Convert.ToInt32(Console.ReadLine());
            } while (n < 1);

            array = new int[n, n];
            Random rnd = new Random();
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    array[i, j] = rnd.Next(0, 100);
                    Console.Write(array[i, j] + "\t");
                }
                Console.WriteLine();
            }
        }

        /*Нахождение начальной и конечной позиции элементов максимальной серии в строке [ВЫВОД:массив с 1 по n, где хранятся номера позиций]*/
        static int[,] Beg_End_Str_Pos_Array(ref int[,] array, int n)
        {
            int ryad = 0;//ряд
            int num = 0;
            int begMaxSer = 0;
            int endMaxSer = 0;
            int tempLen;
            int max = 0;
            int[,] end_beg_arr = new int[n, 2];//хранит первый и поседний номер ячейки end beg
            num = 0;

            for (ryad = 0; ryad < n; ryad++)
            {
                tempLen = max = 0;
                for (int i = 0; i < n - 1; i++)
                {
                    if (array[ryad,i + 1] > array[ryad,i])
                    {
                        tempLen++;
                    }
                    else
                        tempLen = 0;
                    if (tempLen > max)
                    {
                        max = tempLen;
                        endMaxSer = i + 1;
                    }
                }
                max++;
                begMaxSer = endMaxSer - max + 1;
                end_beg_arr[num, 0] = begMaxSer;
                end_beg_arr[num, 1] = endMaxSer;
                num++;
            }
            return end_beg_arr;
        }        
        /*Создание матрицы со всеми значениями между началом и концом*/
        static int[][] Create_Beg_End_Array(ref int[,] array, int n)
        {
            int len;          
            int [][] new_array = new int[n][];
            int [,]pos_array = Beg_End_Str_Pos_Array(ref array, n); //создали массив с индексами min max для каждой строки  
            for (int i = 0; i < n; i++)
            {
                len = (pos_array [i, 1] - pos_array[i, 0])+1;
                new_array[i] = new int[len];
                //Заполняем массив в массиве
                int elm = pos_array[i,0];//текущий номер позиции для заполнения
                for (int j = 0; j < len; j++)
                {
                    new_array[i][j] = array[i, elm];
                    elm++;
                }
            }
			return new_array;
        }
        /*Вывод [][] со всеми значениями между beg и end*/
        static void Output_Beg_End_Array(ref int[][] arr)
        {
            Console.WriteLine("=======================");
           for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < arr[i].Length; j++)
                {
                    Console.Write("{0,-6}  ", arr[i][j]);
                }
                Console.WriteLine();
            }
        }

        static void Main(string[] args)
        {
            Create_Array(ref array, out n);
            int [][] new_array = Create_Beg_End_Array(ref array, n); 
            Console.WriteLine();
            Output_Beg_End_Array(ref new_array);
          
            Console.ReadKey();
        }
    }
}
