﻿/*
 *GUI-приложение в виде меню:
 *Критерии:
 * -создать новый файл
 * -открыть существующий
 * -сохранять его
 * -сохранять под другим именем
 * -обрабатывать открытый файл
 * -сохранять результат обработки (в случае необходимости)
 * -очищать результат обработки
 *Задача:
 *17. Дан текстовый файл, слова в котором разделены одним или несколькими пробелами. 
 * Сформировать три новых файла. Первый файл должен содержать только те строки исходного 
 * файла, количество слов в которых больше заданного значения k. Второй файл должен содержать
 * только те строки исходного файла, количество слов в которых меньше заданного значения k,
 * а третий - только строки, содержащие ровно k слов.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Lab_5
{
    public partial class MainForm : Form
    {
        static string FILENAME;
        public MainForm()
        {
            InitializeComponent();
        }

        private void buttonOpenFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Открыть файл";
            ofd.Filter = "Text Files (*.txt)|*.txt";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                StreamReader read = new StreamReader(File.OpenRead(ofd.FileName));
                FILENAME = ofd.FileName;
                textBox.Text = read.ReadToEnd();
                btnSaveFile.Enabled = true;
                btnTask.Enabled = true;
                textBoxInK.Enabled = true;
                read.Dispose();
            }
        }

        private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonSaveFile_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Сохранить файл";
            save.Filter = "Text Files (*.txt)|*.txt";
            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter write = new StreamWriter(File.Create(save.FileName));
                write.Write(textBox.Text);// сохраняет текст в новом файле!!!
                write.Dispose();
            }
        }

        static void SkipSpaces(string input_str, ref int i)
        {
            while ((i < input_str.Length)&&(input_str[i] == ' '))
                i++;
        }

        static void SkipWord(string input_str, ref int i)
        {
            while ((i < input_str.Length)&&(input_str[i] != ' '))
                i++;
        }

        //Возвращает максимальное количество слов в строке
        static int CountWordInStr(string input_str)
        {
            int i = 0;
            int cnt = 0;
            int len = input_str.Length;
            if (input_str == "") return 0;
            else
            {
                while (i < len)
                {
                    SkipSpaces(input_str, ref i);
                    if (i < input_str.Length)
                        cnt++;
                    SkipWord(input_str, ref i);
                }

                return cnt; 
            }
        }
        private void btnTask_Click(object sender, EventArgs e)
        {
            StreamReader read = new StreamReader(File.OpenRead(FILENAME));
            StreamWriter writeBiggerK = new StreamWriter(File.OpenWrite("Temp_BK.txt"));
            StreamWriter writeSmallerK = new StreamWriter(File.OpenWrite("Temp_SK.txt"));
            StreamWriter writeEqualK = new StreamWriter(File.OpenWrite("Temp_EK.txt"));

            int cnt;
            string s = "";
            int k = Convert.ToInt32(textBoxInK.Text);
 

            while (s != null)
            {
                s = read.ReadLine();
                if (s != null)
                {
                    cnt = CountWordInStr(s);
                    if (cnt > k)
                        writeBiggerK.WriteLine(s);
                    else
                        if (cnt < k)
                        writeSmallerK.WriteLine(s);
                    else
                        writeEqualK.WriteLine(s);
                }
            }

            read.Dispose();
            writeBiggerK.Dispose();
            writeSmallerK.Dispose();
            writeEqualK.Dispose();

            StreamReader outBK_textBoxOut = new StreamReader(File.OpenRead("Temp_BK.txt"));
            textBoxOut1.Text = outBK_textBoxOut.ReadToEnd();
            outBK_textBoxOut.Dispose();

            StreamReader outSK_textBoxOut = new StreamReader(File.OpenRead("Temp_SK.txt"));
            textBoxOut2.Text = outSK_textBoxOut.ReadToEnd();
            outSK_textBoxOut.Dispose();

            StreamReader outEK_textBoxOut = new StreamReader(File.OpenRead("Temp_EK.txt"));
            textBoxOut3.Text = outEK_textBoxOut.ReadToEnd();
            outEK_textBoxOut.Dispose();

            File.Delete("Temp_BK.txt");
            File.Delete("Temp_SK.txt");
            File.Delete("Temp_EK.txt");

            btnClrRes.Enabled = true;
            btnSaveTask.Enabled = true;
        }

        private void buttonCreate_Click(object sender, EventArgs e)
        {
            CreateForm form = new CreateForm();
            form.Show();
        }

        private void btnSaveTask_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Сохранить файл №1 (строки большие k)";
            save.Filter = "Text Files (*.txt)|*.txt";
            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter write = new StreamWriter(File.Create(save.FileName));
                write.Write(textBoxOut1.Text);
                write.Dispose();
            }
            save.Title = "Сохранить файл №2 (строки меньшие k)";
            save.Filter = "Text Files (*.txt)|*.txt";
            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter write = new StreamWriter(File.Create(save.FileName));
                write.Write(textBoxOut2.Text);
                write.Dispose();
            }
            save.Title = "Сохранить файл №3 (строки равные k)";
            save.Filter = "Text Files (*.txt)|*.txt";
            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter write = new StreamWriter(File.Create(save.FileName));
                write.Write(textBoxOut3.Text);
                write.Dispose();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBoxInK.Text = "";
            textBoxOut1.Text = "";
            textBoxOut2.Text = "";
            textBoxOut3.Text = "";
        }

        private void создатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreateForm form = new CreateForm();
            form.Show();
        }

        private void открытьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Открыть файл";
            ofd.Filter = "Text Files (*.txt)|*.txt";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                StreamReader read = new StreamReader(File.OpenRead(ofd.FileName));
                FILENAME = ofd.FileName;
                textBox.Text = read.ReadToEnd();
                btnSaveFile.Enabled = true;
                btnTask.Enabled = true;
                textBoxInK.Enabled = true;
                read.Dispose();
            }
        }

        private void сохранитьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Сохранить файл №1 (строки большие k)";
            save.Filter = "Text Files (*.txt)|*.txt";
            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter write = new StreamWriter(File.Create(save.FileName));
                write.Write(textBoxOut1.Text);
                write.Dispose();
            }
            save.Title = "Сохранить файл №2 (строки меньшие k)";
            save.Filter = "Text Files (*.txt)|*.txt";
            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter write = new StreamWriter(File.Create(save.FileName));
                write.Write(textBoxOut2.Text);
                write.Dispose();
            }
            save.Title = "Сохранить файл №3 (строки равные k)";
            save.Filter = "Text Files (*.txt)|*.txt";
            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter write = new StreamWriter(File.Create(save.FileName));
                write.Write(textBoxOut3.Text);
                write.Dispose();
            }
        }

        private void выходToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void сохранитьКакToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Сохранить файл";
            save.Filter = "Text Files (*.txt)|*.txt";
            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter write = new StreamWriter(File.Create(save.FileName));
                write.Write(textBox.Text);
                write.Dispose();
            }
        }
    }
}
