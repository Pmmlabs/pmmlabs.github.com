﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace OddNumbersFileProject
{
    class Task
    {
        public static void doTask(string inputStr, out string oddStr, out string evenStr)
        {
            oddStr = "";
            evenStr = "";
            if (inputStr == "")
            {
                throw new ArgumentException("Передана пустая строка");
            }
            else
            {
                oddStr = "";
                evenStr = "";
                string[] strNumbers = inputStr.Split(new char[] { ' ', '\t', '\n' });
                for (int i = 0; i < strNumbers.Length; i++)
                {
                    try
                    {
                        int number = Int32.Parse(strNumbers[i]);
                        if ((number & 1) == 0)
                        {
                            evenStr += strNumbers[i] + ' ';
                        }
                        else
                        {
                            oddStr += strNumbers[i] + ' ';
                        }
                    }
                    catch { }

                }
            }
        }
        public static void WriteInFiles(ref string folderName, string odd, string even)
        {
            StreamWriter f_Out_odd = new StreamWriter(folderName + "/odd.txt");
            StreamWriter f_Out_even = new StreamWriter(folderName + "/even.txt");

            f_Out_odd.Write(odd);
            f_Out_even.Write(even);

            f_Out_odd.Close();
            f_Out_even.Close();
        }
    }
}
