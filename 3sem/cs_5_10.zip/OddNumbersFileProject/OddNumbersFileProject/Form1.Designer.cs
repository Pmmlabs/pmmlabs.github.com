﻿namespace OddNumbersFileProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainTextbox = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.taskToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doTaskToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showTaskToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteResultsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.sourceLabel = new System.Windows.Forms.Label();
            this.oddLabel = new System.Windows.Forms.Label();
            this.evenLabel = new System.Windows.Forms.Label();
            this.oddText = new System.Windows.Forms.TextBox();
            this.evenText = new System.Windows.Forms.TextBox();
            this.writeInFilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainTextbox
            // 
            this.mainTextbox.Location = new System.Drawing.Point(0, 40);
            this.mainTextbox.Multiline = true;
            this.mainTextbox.Name = "mainTextbox";
            this.mainTextbox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.mainTextbox.Size = new System.Drawing.Size(434, 187);
            this.mainTextbox.TabIndex = 0;
            this.mainTextbox.TextChanged += new System.EventHandler(this.mainTextbox_TextChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.taskToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(434, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createToolStripMenuItem,
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.saveAsToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.fileToolStripMenuItem.Text = "Файл";
            // 
            // createToolStripMenuItem
            // 
            this.createToolStripMenuItem.Name = "createToolStripMenuItem";
            this.createToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.createToolStripMenuItem.Text = "Создать";
            this.createToolStripMenuItem.Click += new System.EventHandler(this.createToolStripMenuItem_Click);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.openToolStripMenuItem.Text = "Открыть...";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.saveToolStripMenuItem.Text = "Сохранить";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.saveAsToolStripMenuItem.Text = "Сохранить как...";
            this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.saveAsToolStripMenuItem_Click);
            // 
            // taskToolStripMenuItem
            // 
            this.taskToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.doTaskToolStripMenuItem,
            this.showTaskToolStripMenuItem,
            this.deleteResultsToolStripMenuItem,
            this.writeInFilesToolStripMenuItem});
            this.taskToolStripMenuItem.Name = "taskToolStripMenuItem";
            this.taskToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.taskToolStripMenuItem.Text = "Задача";
            // 
            // doTaskToolStripMenuItem
            // 
            this.doTaskToolStripMenuItem.Name = "doTaskToolStripMenuItem";
            this.doTaskToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.doTaskToolStripMenuItem.Text = "Решить задачу";
            this.doTaskToolStripMenuItem.Click += new System.EventHandler(this.doTaskToolStripMenuItem_Click);
            // 
            // showTaskToolStripMenuItem
            // 
            this.showTaskToolStripMenuItem.Name = "showTaskToolStripMenuItem";
            this.showTaskToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.showTaskToolStripMenuItem.Text = "Показать условие";
            this.showTaskToolStripMenuItem.Click += new System.EventHandler(this.showTaskToolStripMenuItem_Click);
            // 
            // deleteResultsToolStripMenuItem
            // 
            this.deleteResultsToolStripMenuItem.Name = "deleteResultsToolStripMenuItem";
            this.deleteResultsToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.deleteResultsToolStripMenuItem.Text = "Удалить файлы результата";
            this.deleteResultsToolStripMenuItem.Click += new System.EventHandler(this.deleteResultsToolStripMenuItem_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // sourceLabel
            // 
            this.sourceLabel.AutoSize = true;
            this.sourceLabel.Location = new System.Drawing.Point(12, 24);
            this.sourceLabel.Name = "sourceLabel";
            this.sourceLabel.Size = new System.Drawing.Size(89, 13);
            this.sourceLabel.TabIndex = 2;
            this.sourceLabel.Text = "Исходный текст";
            // 
            // oddLabel
            // 
            this.oddLabel.AutoSize = true;
            this.oddLabel.Location = new System.Drawing.Point(12, 230);
            this.oddLabel.Name = "oddLabel";
            this.oddLabel.Size = new System.Drawing.Size(57, 13);
            this.oddLabel.TabIndex = 3;
            this.oddLabel.Text = "Нечетные";
            // 
            // evenLabel
            // 
            this.evenLabel.AutoSize = true;
            this.evenLabel.Location = new System.Drawing.Point(225, 230);
            this.evenLabel.Name = "evenLabel";
            this.evenLabel.Size = new System.Drawing.Size(46, 13);
            this.evenLabel.TabIndex = 4;
            this.evenLabel.Text = "Четные";
            // 
            // oddText
            // 
            this.oddText.Location = new System.Drawing.Point(0, 245);
            this.oddText.Multiline = true;
            this.oddText.Name = "oddText";
            this.oddText.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.oddText.Size = new System.Drawing.Size(216, 165);
            this.oddText.TabIndex = 5;
            // 
            // evenText
            // 
            this.evenText.Location = new System.Drawing.Point(218, 245);
            this.evenText.Multiline = true;
            this.evenText.Name = "evenText";
            this.evenText.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.evenText.Size = new System.Drawing.Size(216, 165);
            this.evenText.TabIndex = 6;
            // 
            // writeInFilesToolStripMenuItem
            // 
            this.writeInFilesToolStripMenuItem.Name = "writeInFilesToolStripMenuItem";
            this.writeInFilesToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.writeInFilesToolStripMenuItem.Text = "Записать результаты в файлы";
            this.writeInFilesToolStripMenuItem.Click += new System.EventHandler(this.writeInFilesToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 411);
            this.Controls.Add(this.evenText);
            this.Controls.Add(this.oddText);
            this.Controls.Add(this.evenLabel);
            this.Controls.Add(this.oddLabel);
            this.Controls.Add(this.sourceLabel);
            this.Controls.Add(this.mainTextbox);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Четность чисел";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox mainTextbox;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem taskToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doTaskToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showTaskToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteResultsToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Label sourceLabel;
        private System.Windows.Forms.Label oddLabel;
        private System.Windows.Forms.Label evenLabel;
        private System.Windows.Forms.TextBox oddText;
        private System.Windows.Forms.TextBox evenText;
        private System.Windows.Forms.ToolStripMenuItem writeInFilesToolStripMenuItem;
    }
}

