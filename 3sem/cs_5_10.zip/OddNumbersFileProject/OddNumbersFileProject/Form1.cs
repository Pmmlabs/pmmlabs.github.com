﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;


//Леденев Д. А., ПММ, 2 курс, 9 группа, задача 5
//10. Дан текстовый файл .  Известно,  что в нем записаны целые числа. 
//Записать в один файл все четные числа исходного файла, а в другой – все нечетные.
namespace OddNumbersFileProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string fileName = "";
        private string folderName = "";
        private bool textChanged = false;
        private const string NAME_OF_PROGRAM = "Четность числа";
        private const int BORDER = 8;

        //метод выводит условие задачи
        private void showTaskToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("10. Дан текстовый файл. Известно, что в нем записаны целые числа. Записать в один файл все четные числа исходного файла, а в другой – все нечетные.", 
                "Задача 5", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        //изменяет размер textbox'а по размеру формы
        private void Form1_Resize(object sender, EventArgs e)
        {
            mainTextbox.Width = this.Width - 2 * BORDER;
            mainTextbox.Height = this.Height/2 - mainTextbox.Top;
            evenLabel.Top = mainTextbox.Bottom;
            oddLabel.Top = mainTextbox.Bottom;
            
            evenLabel.Left = this.Width / 2;
            evenText.Top = evenLabel.Bottom;
            evenText.Left = this.Width / 2 + 1;
            evenText.Width = this.Width / 2 - 1 - 2*BORDER;
            evenText.Height = this.Bottom - evenLabel.Bottom;
            oddText.Top = oddLabel.Bottom;
            oddText.Width = this.Width / 2 - 1 - BORDER;
            oddText.Height = this.Bottom - evenLabel.Bottom;
        }

        //создание файла
        private void createToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((mainTextbox.Text != "" && fileName == "")  || (fileName != "" && textChanged))
            {
                DialogResult dr = MessageBox.Show("Хотите сохранить изменения в файле " + fileName + "?",
                    "Предупреждение!", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    saveToolStripMenuItem_Click(sender, e);
                }
                else if (dr == DialogResult.No)
                {
                    mainTextbox.Clear();
                    textChanged = true;
                }
            }
            else
            {
                mainTextbox.Clear();
            }
        }

        //сохранение файла
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fileName == "")
            {
                saveAsToolStripMenuItem_Click(sender, e);
            }
            else
            {
                StreamWriter f_Out = new StreamWriter(fileName);
                f_Out.WriteLine(mainTextbox.Text);
                f_Out.Close();
                textChanged = false;
            }
        }

        //сохранение в новый файл
        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.FileName = "text";
            saveFileDialog1.DefaultExt = ".txt";
            saveFileDialog1.Filter = "Текстовый документ|*.txt";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                fileName = saveFileDialog1.FileName;
                if (fileName != "")
                {
                    saveToolStripMenuItem_Click(sender, e);
                }
            }
        }

        //открытие файла
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = "";
            openFileDialog1.DefaultExt = ".txt";
            openFileDialog1.Filter = "Текстовый документ|*.txt";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamReader f_In = new StreamReader(openFileDialog1.FileName);
                fileName = openFileDialog1.FileName;
                mainTextbox.Text = f_In.ReadToEnd();
                this.Text = openFileDialog1.SafeFileName + " - " + NAME_OF_PROGRAM;
                textChanged = false;
                folderName = "";
            }
        }

        //выполнение основной задачи
        private void doTaskToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string odd, even;
            try
            {
                Task.doTask(mainTextbox.Text, out odd, out even);
                oddText.Text = odd;
                evenText.Text = even;
            }
            catch(ArgumentException)
            {
                MessageBox.Show("Исходные данные не заполнены, результатом будут пустые поля",
                    "Предупреждение!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            textChanged = false;

        }

        //удаление результатов
        private void deleteResultsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (folderName == "")
            {
                folderBrowserDialog1.Description = "Не удалось найти рабочую папку, укажите расположение файлов вручную";
                if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                {
                    folderName = folderBrowserDialog1.SelectedPath;
                }
            }

            File.Delete(folderName + "/odd.txt");
            File.Delete(folderName + "/even.txt");

        }

        //закрытие формы. проверка, что нужные данные сохранены
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if ((mainTextbox.Text != "" && fileName == "") || (fileName != "" && textChanged))
            {
                DialogResult dr = MessageBox.Show("Хотите сохранить изменения в файле " + fileName + "?",
                    "Предупреждение", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    saveToolStripMenuItem_Click(sender, e);
                }
                else if (dr == DialogResult.Cancel)
                {
                    e.Cancel = true;   
                }
            }
        }

        //проверка, что текст не поменялся
        private void mainTextbox_TextChanged(object sender, EventArgs e)
        {
            textChanged = true;
        }

        private void writeInFilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(textChanged)
            {
                DialogResult dr = MessageBox.Show("Текст изменен! Решить задачу заново?",
                    "Предупреждение!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if(dr == DialogResult.Yes)
                {
                    doTaskToolStripMenuItem_Click(sender, e);
                }
            }

            if (folderName == "")
            {
                folderBrowserDialog1.Description = "Укажите расположение, в котором будут храниться файлы результата";
                if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                {
                    folderName = folderBrowserDialog1.SelectedPath;
                }
            }

            if (folderName != "")
            {
                Task.WriteInFiles(ref folderName, oddText.Text, evenText.Text);
                MessageBox.Show("Результат находится по адресу:\n" + folderName, "Готово!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
        }
    }
}