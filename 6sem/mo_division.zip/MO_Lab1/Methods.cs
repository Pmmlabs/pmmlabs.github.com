﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MO_Lab1
{
    class Methods
    {
        public static double MPD(double a, double b, double eps, Func<double, double> func)
        {
            double x = 0, f1, f2;
            while(Math.Abs(b - a) > eps)
            {
                x = (a + b) / 2;
                f1 = func(x - eps / 2);
                f2 = func(x + eps / 2);
                if (f1 < f2)
                {
                    b = x;
                }
                else
                {
                    a = x;
                }
            }
            return x;
        }

        public static double SampleFunction(double x)
        {
            return 6 * x * x*x+6 * x * x + 9 * x + 10;
        }
    }
}
