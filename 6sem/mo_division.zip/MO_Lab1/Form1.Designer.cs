﻿namespace MO_Lab1
{
    partial class mainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.funcChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btPerform = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.funcChart)).BeginInit();
            this.SuspendLayout();
            // 
            // funcChart
            // 
            chartArea1.Name = "ChartArea1";
            this.funcChart.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.funcChart.Legends.Add(legend1);
            this.funcChart.Location = new System.Drawing.Point(17, 20);
            this.funcChart.Name = "funcChart";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.funcChart.Series.Add(series1);
            this.funcChart.Size = new System.Drawing.Size(529, 457);
            this.funcChart.TabIndex = 0;
            this.funcChart.Text = "chart1";
            // 
            // btPerform
            // 
            this.btPerform.Location = new System.Drawing.Point(17, 483);
            this.btPerform.Name = "btPerform";
            this.btPerform.Size = new System.Drawing.Size(75, 23);
            this.btPerform.TabIndex = 1;
            this.btPerform.Text = "Perform";
            this.btPerform.UseVisualStyleBackColor = true;
            this.btPerform.Click += new System.EventHandler(this.btPerform_Click);
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 518);
            this.Controls.Add(this.btPerform);
            this.Controls.Add(this.funcChart);
            this.Name = "mainForm";
            this.Text = "Plot";
            ((System.ComponentModel.ISupportInitialize)(this.funcChart)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart funcChart;
        private System.Windows.Forms.Button btPerform;
    }
}

