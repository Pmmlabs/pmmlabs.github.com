CREATE OR REPLACE PACKAGE Labyrinth AS

  -- ������� ���� ������
  /*procedure clearall(a integer);*/

  -- ������ ���������
  PROCEDURE print(
            message IN VARCHAR2);

  --�������� �������� ����������
  PROCEDURE create_labyrinth_size(
            aName IN labyrinth_size.name%TYPE
           ,aWidth IN labyrinth_size.width%TYPE
           ,aHeight IN labyrinth_size.height%TYPE);

  -- ��������� ������
  FUNCTION get_size(aName IN labyrinth_size.name%TYPE)
           RETURN labyrinth_size%ROWTYPE;
           
  -- ��������� ������ �� id
  FUNCTION get_size_byID(aID IN labyrinth_run.id%TYPE)
           RETURN labyrinth_size%ROWTYPE;
  
  -- �������� ������� ��� ���������
  procedure create_labyrinth_cell_state(
            aName IN labyrinth_cell_state.name%TYPE
            ,aState IN labyrinth_cell_state.state%TYPE);
    
  -- ��������� �������  
  function get_state(aName IN labyrinth_cell_state.name%TYPE)
           RETURN labyrinth_cell_state%ROWTYPE;
  
  -- �������� ���������
  procedure create_labyrinth(
            aName IN labyrinth_size.name%TYPE);
    
  -- ��������� ���������
  procedure generate_labyrinth(
            aSize IN labyrinth_size%ROWTYPE);
            
  -- ��������� ��������� ����������� �����          
  procedure generate_labyrinth_2(
            aSize IN labyrinth_size%ROWTYPE);
    
  -- �������� ��������� ��� ��������        
  procedure create_empty_labyrinth(
    aSize IN labyrinth_size%ROWTYPE);
    
  -- ���������� ��������� �����  
  procedure mark_frontier_cell(
    xvalue IN labyrinth_cells.x%TYPE,
    yvalue IN labyrinth_cells.y%TYPE);
            
  -- ������ ���������           
  procedure print_labyrinth(
            aID IN labyrinth_run.id%TYPE,
            res IN boolean);
            
  procedure set_start_point(
    aID IN labyrinth_run.id%TYPE,
    xvalue IN labyrinth_cells.x%TYPE,
    yvalue IN labyrinth_cells.y%TYPE);
    
  procedure set_end_point(
    aID IN labyrinth_run.id%TYPE,
    xvalue IN labyrinth_cells.x%TYPE,
    yvalue IN labyrinth_cells.y%TYPE);

  -- ������ ���������            
  procedure run_wave(
    aID IN labyrinth_run.id%TYPE);
    
  procedure create_path(
    aID IN labyrinth_run.id%TYPE,
    xvalue IN labyrinth_cells.x%TYPE,
    yvalue IN labyrinth_cells.x%TYPE,
    wave IN labyrinth_cells.wave_number%TYPE);
    
  function set_wave(
    aID IN labyrinth_run.id%TYPE,
    xvalue IN labyrinth_cells.x%TYPE,
    yvalue IN labyrinth_cells.y%TYPE,
    wave IN labyrinth_cells.wave_number%TYPE)
  RETURN integer;
  
  procedure change_labyrinth_item(
    aID IN labyrinth_run.id%TYPE,
    xvalue IN labyrinth_cells.x%TYPE,
    yvalue IN labyrinth_cells.y%TYPE,
    state_in IN labyrinth_cell_state.id%TYPE);
 
END labyrinth;
/
CREATE OR REPLACE PACKAGE BODY Labyrinth AS

  -- ������� ���� ������
  /*procedure clearall(a integer)
    IS
    Begin
      TRUNCATE TABLE labyrinth_size;
    End clearall;*/
 
  -- ������ ��������� 
  PROCEDURE print(message IN VARCHAR2)
  IS
  BEGIN  
    dbms_output.enable; 
    dbms_output.put_line(message);
  END print;  

--�������� �������� ����������  
PROCEDURE create_labyrinth_size(
  aName IN labyrinth_size.name%TYPE  
  ,aWidth IN labyrinth_size.width%TYPE
  ,aHeight IN labyrinth_size.height%TYPE)
  IS
  BEGIN
    IF get_size(aName).id IS NULL THEN
      INSERT INTO labyrinth_size VALUES(labyrinth_size_seq_ID.NEXTVAL,
        aName, aWidth, aHeight);
      COMMIT;
    ELSE
      UPDATE labyrinth_size 
      SET
        width = aWidth,
        height = aHeight
      WHERE name = aName;
      COMMIT;
    END IF;
  END create_labyrinth_size;
  
  -- ��������� �������� ��������� �� ����� ���������
  FUNCTION get_size(aName IN labyrinth_size.name%TYPE)
           RETURN labyrinth_size%ROWTYPE
   IS
    CURSOR size_cur(name_in IN labyrinth_size.name%TYPE)
      RETURN labyrinth_size%ROWTYPE
    IS
      SELECT * FROM labyrinth_size WHERE name=name_in;
    level labyrinth_size%ROWTYPE;
  BEGIN 
    OPEN size_cur(aName);
    FETCH size_cur INTO level;
    IF size_cur%NOTFOUND THEN
      RETURN NULL;
    END IF;
    CLOSE size_cur;
    RETURN level;
  END get_size;
  
  
  -- ��������� ������ �� id
  FUNCTION get_size_byID(aID IN labyrinth_run.id%TYPE)
               RETURN labyrinth_size%ROWTYPE
  IS
    CURSOR cur_byid(id_in IN labyrinth_run.id%TYPE)
      RETURN labyrinth_size%ROWTYPE
    IS
      SELECT * FROM labyrinth_size WHERE id in (SELECT labyrinth_size_id FROM labyrinth_run WHERE id = id_in);
    level labyrinth_size%ROWTYPE;
  BEGIN
    OPEN cur_byid(aID);
    FETCH cur_byid INTO level;
    IF cur_byid%NOTFOUND THEN
      RETURN NULL;
    END IF;
    CLOSE cur_byid;
    RETURN level;
  END get_size_byID;
  
  procedure create_labyrinth_cell_state(
            aName IN labyrinth_cell_state.name%TYPE
            ,aState IN labyrinth_cell_state.state%TYPE)
  IS
  BEGIN
    IF get_state(aName).id IS NULL THEN
      INSERT INTO labyrinth_cell_state VALUES(labyrinth_cell_state_seq_ID.NEXTVAL,
        aName, aState);
      COMMIT;
    ELSE
      UPDATE labyrinth_cell_state
      SET 
        state = aState
      WHERE name = aName;
      COMMIT;
    END IF;
  END create_labyrinth_cell_state;
    
  -- ��������� �������  
 function get_state(aName IN labyrinth_cell_state.name%TYPE)
           RETURN labyrinth_cell_state%ROWTYPE
     IS
       CURSOR state_cur(name_in IN labyrinth_cell_state.name%TYPE)
         RETURN labyrinth_cell_state%ROWTYPE
       IS
         SELECT * FROM labyrinth_cell_state WHERE name=name_in;
         level labyrinth_cell_state%ROWTYPE;
     BEGIN
       OPEN state_cur(aName);
       FETCH state_cur INTO level;
       IF state_cur%NOTFOUND THEN
         RETURN NULL;
       END IF;
       CLOSE state_cur;
       RETURN level;
     END get_state;
     
  -- public ��������� ���������
  PROCEDURE create_labyrinth(
            aName IN labyrinth_size.name%TYPE)
  IS
    mSize labyrinth_size%ROWTYPE;
  BEGIN
    mSize:= get_size(aName);
    IF NOT(mSize.id IS NULL) THEN
      generate_labyrinth(mSize);
    END IF;
  END create_labyrinth;
  
  -- private 
  procedure generate_labyrinth(
            aSize IN labyrinth_size%ROWTYPE)
  IS
    new_id labyrinth_run.id%TYPE;
    state_id labyrinth_cell_state.id%TYPE;
  BEGIN
    SELECT labyrinth_run_seq_ID.NEXTVAL INTO new_id FROM DUAL;
    INSERT INTO labyrinth_run VALUES (new_id, aSize.id , SYSDATE, 0);
    COMMIT;
    dbms_random.seed(to_char(SYSDATE,'MM-DD-YYYY HH24:MI:SS'));
    FOR x IN 0..aSize.width-1
    LOOP
      FOR y IN 0..aSize.height-1
        LOOP
        IF (x = 0) OR (y = 0) OR (x = aSize.width-1) OR (y = aSize.height-1) THEN         
          INSERT INTO labyrinth_cells (id, labyrinth_id, x, y, state_id, wave_number) VALUES
                 	(labyrinth_cells_seq_ID.NEXTVAL, new_id, x, y, 3, 0);
          COMMIT;
        ELSE  
          SELECT MOD(ABS(dbms_random.random), 3) INTO state_id FROM DUAL;  
          IF state_id = 0 THEN
            INSERT INTO labyrinth_cells (id, labyrinth_id, x, y, state_id, wave_number) VALUES
                 	(labyrinth_cells_seq_ID.NEXTVAL, new_id, x, y, 3, 0);
            COMMIT;
          ELSE
            INSERT INTO labyrinth_cells (id, labyrinth_id, x, y, state_id, wave_number) VALUES
                 	(labyrinth_cells_seq_ID.NEXTVAL, new_id, x, y, 4, 0); 
            COMMIT;
          END IF;
        END IF;          
      END LOOP;
    END LOOP;
    print_labyrinth(new_id, false);
  END generate_labyrinth;
  
  procedure generate_labyrinth_2(
            aSize IN labyrinth_size%ROWTYPE)
  IS
    xvalue labyrinth_cells.x%TYPE;
    yvalue labyrinth_cells.y%TYPE;
  BEGIN
    -- ������� ������ ��������
    --create_empty_labyrinth(aSize);
    
    -- ��������� �������� ������ �����    
    dbms_random.seed(to_char(SYSDATE,'MM-DD-YYYY HH24:MI:SS'));
    SELECT MOD(ABS(dbms_random.random), aSize.width) INTO xvalue FROM DUAL;
    SELECT MOD(ABS(dbms_random.random), aSize.height) INTO yvalue FROM DUAL;
    print('X:'||xvalue);
    print('Y:'||yvalue);
    
    -- �������� ��������� ������
    mark_frontier_cell(xvalue, yvalue);
    
  END generate_labyrinth_2;
  
  -- ������� ������ �������� �� ������
  procedure create_empty_labyrinth(
    aSize IN labyrinth_size%ROWTYPE)
  IS
    new_id labyrinth_run.id%TYPE;
  BEGIN
    SELECT labyrinth_run_seq_ID.NEXTVAL INTO new_id FROM DUAL;
    INSERT INTO labyrinth_run VALUES (new_id, aSize.id , SYSDATE, 0);
    COMMIT;
    FOR x IN 0..aSize.width-1
    LOOP
      FOR y IN 0..aSize.height-1
      LOOP
        INSERT INTO labyrinth_cells (id, labyrinth_id, x, y, state_id) VALUES
                 	(labyrinth_cells_seq_ID.NEXTVAL, new_id, x, y, 3);
        COMMIT; 
      END LOOP;
    END LOOP;
  END create_empty_labyrinth;
  
  -- ���������� ��������� �����  
  procedure mark_frontier_cell(
    xvalue IN labyrinth_cells.x%TYPE,
    yvalue IN labyrinth_cells.y%TYPE)
  IS
  BEGIN
    Print('DO');
    -- ����
    
    -- ����
    -- ������
    -- �����
  END mark_frontier_cell;
  
  -- ������ ���������
  procedure print_labyrinth(
            aID IN labyrinth_run.id%TYPE,
            res IN boolean)
  IS
    mSize labyrinth_size%ROWTYPE;
    outputline varchar2(100);
    mState labyrinth_cell_state.state%TYPE;
    wave labyrinth_cells.wave_number%TYPE;
    mStateID labyrinth_cell_state.id%TYPE;
  BEGIN
    mSize:= get_size_byID(aID);
    IF NOT(mSize.id IS NULL) THEN
      FOR i IN 0..mSize.width-1
        LOOP
        outputline := '';
        FOR j IN 0..mSize.height-1
        LOOP
          --SELECT state INTO mState FROM labyrinth_cell_state WHERE id in (
           --      SELECT state_id FROM labyrinth_cells WHERE labyrinth_id = aID AND x = i AND y = j);
                 
            SELECT state_id INTO mStateID FROM labyrinth_cells WHERE labyrinth_id = aID AND x = i AND y = j;
                  
            IF ((mStateID = 4 OR mStateID = 5) AND NOT res) THEN 
              SELECT wave_number INTO wave FROM labyrinth_cells WHERE labyrinth_id = aID AND x = i AND y = j; 
               IF wave > 0 THEN
                 outputline := outputline||wave;
               ELSE
                 outputline := outputline||' ';
               END IF;
            ELSE
              SELECT state INTO mState FROM labyrinth_cell_state WHERE id = mStateID;
              outputline := outputline||mState;
            END IF;
          END LOOP;
        print(outputline);
      END LOOP;
    END IF;
  END print_labyrinth;    

  -- ������ ���������            
  procedure run_wave(
    aID IN labyrinth_run.id%TYPE)
  IS
    mSize labyrinth_size%ROWTYPE;
    xStart labyrinth_cells.x%TYPE;
    yStart labyrinth_cells.y%TYPE;
    wave_in labyrinth_cells.wave_number%TYPE;
    res integer;
    w_end labyrinth_cells.wave_number%TYPE;
  BEGIN
    mSize := get_size_byID(aID);
    
    SELECT x INTO xStart FROM labyrinth_cells
    WHERE labyrinth_id = aID AND state_id = 1; -- �������� �� 2 
    
    SELECT y INTO yStart FROM labyrinth_cells
    WHERE labyrinth_id = aID AND state_id = 1; -- �������� �� 2 
    
    res := set_wave(aID, xStart, yStart, 1);
    w_end := 1;
    FOR i IN 2..(mSize.width)*(mSize.height)
      LOOP
        
        FOR xx IN 0..mSize.width-1
        LOOP 
          FOR yy IN 0..mSize.height-1
          LOOP
            
            IF (res = 0) THEN
            
              SELECT wave_number INTO wave_in FROM labyrinth_cells
              WHERE labyrinth_id = aID AND x = xx AND y = yy;
            
              --print('wave_in: "'||wave_in||'"');
              --print('i'||TO_CHAR(i));
                        
              IF wave_in = (i - 1) THEN
               res := set_wave(aID, xx, yy, i);
              END IF;
            w_end:=i;
            END IF;
          
          END LOOP;        
        END LOOP;
      END LOOP;
      
    SELECT x INTO xStart FROM labyrinth_cells
    WHERE labyrinth_id = aID AND state_id = 2;
        
    SELECT y INTO yStart FROM labyrinth_cells
    WHERE labyrinth_id = aID AND state_id = 2;
    
    SELECT wave_number INTO wave_in FROM labyrinth_cells
    WHERE labyrinth_id = aID AND x = xStart AND y = yStart;
   
    IF (res = 1) THEN 
       create_path(aID, xStart, yStart, w_end);
       labyrinth.print_labyrinth(aID, true);
    ELSE
      print('��� �������!');
      labyrinth.print_labyrinth(aID, true);
    END IF;
    
    UPDATE labyrinth_run
    SET
       result = res
    WHERE id = aID;
    COMMIT;
    
  END run_wave;
  
  
  procedure create_path(
    aID IN labyrinth_run.id%TYPE,
    xvalue IN labyrinth_cells.x%TYPE,
    yvalue IN labyrinth_cells.x%TYPE,
    wave IN labyrinth_cells.wave_number%TYPE)
  IS
    x_in labyrinth_cells.x%TYPE;
    y_in labyrinth_cells.x%TYPE;
    wave_number_in labyrinth_cells.wave_number%TYPE;
  BEGIN
    
    --print('x'||TO_CHAR(xvalue));
    --print('y'||TO_CHAR(xvalue));
    --print('wave'||TO_CHAR(wave));
    
    -- �����
    x_in := xvalue - 1;
    y_in := yvalue;    
    
    SELECT wave_number INTO wave_number_in FROM labyrinth_cells
    WHERE labyrinth_id = aID AND x = x_in AND y = y_in;
    
    
    IF (wave_number_in = wave -1 ) AND (wave_number_in > 0 ) THEN
      UPDATE labyrinth_cells
      SET
        state_id = 6
      WHERE labyrinth_id = aID AND x = x_in AND y = y_in;
      COMMIT;
      
      create_path(aID, x_in, y_in, wave_number_in);
          
    ELSE
      
      -- ����
       x_in := xvalue + 1;
       y_in := yvalue;
       
       SELECT wave_number INTO wave_number_in FROM labyrinth_cells
       WHERE labyrinth_id = aID AND x = x_in AND y = y_in;
       
       IF (wave_number_in = wave - 1) AND (wave_number_in > 0 )  THEN
         UPDATE labyrinth_cells
         SET
                state_id = 6
         WHERE labyrinth_id = aID AND x = x_in AND y = y_in;
         COMMIT;
      
         create_path(aID, x_in, y_in, wave_number_in);
         
       ELSE
          -- ������
         x_in := xvalue;
         y_in := yvalue + 1;
    
         SELECT wave_number INTO wave_number_in FROM labyrinth_cells
         WHERE labyrinth_id = aID AND x = x_in AND y = y_in;
         
         IF (wave_number_in = wave -1 ) AND (wave_number_in > 0 ) THEN
            UPDATE labyrinth_cells
            SET
                state_id = 6
            WHERE labyrinth_id = aID AND x = x_in AND y = y_in;
            COMMIT;
      
            create_path(aID, x_in, y_in, wave_number_in);
         ELSE
            -- �����
            x_in := xvalue;
            y_in := yvalue - 1;
            
            SELECT wave_number INTO wave_number_in FROM labyrinth_cells
            WHERE labyrinth_id = aID AND x = x_in AND y = y_in;
            
            IF (wave_number_in = wave - 1 ) AND (wave_number_in > 0 ) THEN
               UPDATE labyrinth_cells
               SET
                      state_id = 6
               WHERE labyrinth_id = aID AND x = x_in AND y = y_in;
               COMMIT;
       
               create_path(aID, x_in, y_in, wave_number_in);
            END IF;                
                
         END IF;
    
       END IF;
        
    END IF;
    
  END create_path;
  
  
  function set_wave(
    aID IN labyrinth_run.id%TYPE,
    xvalue IN labyrinth_cells.x%TYPE,
    yvalue IN labyrinth_cells.y%TYPE,
    wave IN labyrinth_cells.wave_number%TYPE)
   RETURN integer
  IS 
    x_in labyrinth_cells.x%TYPE;
    y_in labyrinth_cells.x%TYPE;
    state_in labyrinth_cells.state_id%TYPE;
  BEGIN
    --print('wave:'||wave);
    -- �����
    x_in := xvalue - 1;
    y_in := yvalue;
    
    --print('up');
    --print('x_in:'||x_in);
    --print('y_in:'||y_in);
    
    SELECT state_id INTO state_in FROM labyrinth_cells
    WHERE labyrinth_id = aID AND x = x_in AND y = y_in;
    
    --print('state_in:'||state_in);
    
    IF (state_in = 4) THEN -- ���� ������
      UPDATE labyrinth_cells
      SET  
        wave_number = wave,
        state_id = 5
      WHERE labyrinth_id = aID AND x = x_in AND y = y_in;
      COMMIT;
    END IF;
    IF (state_in = 2) THEN
      return 1;
    END IF;
    
    -- ����
    x_in := xvalue + 1;
    y_in := yvalue;
    
    --print('down');  
    --print('x_in:'||x_in);
    --print('y_in:'||y_in);
    
    SELECT state_id INTO state_in FROM labyrinth_cells
    WHERE labyrinth_id = aID AND x = x_in AND y = y_in;
    
    --print('state_in:'||state_in);
    
    IF (state_in = 4) THEN -- ���� ������
      UPDATE labyrinth_cells
      SET
        wave_number = wave,
        state_id = 5
      WHERE labyrinth_id = aID AND x = x_in AND y = y_in;  
      COMMIT;
    END IF;
    IF (state_in = 2) THEN
      return 1;
    END IF;
    
    -- ������
    
    x_in := xvalue;
    y_in := yvalue + 1;
    
    --print('right');
    --print('x_in:'||x_in);
    --print('y_in:'||y_in);
    
    SELECT state_id INTO state_in FROM labyrinth_cells
    WHERE labyrinth_id = aID AND x = x_in AND y = y_in;
    
    --print('state_in:'||state_in);
    
    IF (state_in = 4) THEN -- ���� ������
      UPDATE labyrinth_cells
      SET
        wave_number = wave,
        state_id = 5
      WHERE labyrinth_id = aID AND x = x_in AND y = y_in;  
      COMMIT;
    END IF;
    IF (state_in = 2) THEN
      return 1;
    END IF;
    
    -- �����
    x_in := xvalue;
    y_in := yvalue - 1;
   
    --print('left'); 
    --print('x_in:'||x_in);
    --print('y_in:'||y_in);
    
    SELECT state_id INTO state_in FROM labyrinth_cells
    WHERE labyrinth_id = aID AND x = x_in AND y = y_in;
    
    --print('state_in:'||state_in);
    
    IF (state_in = 4) THEN -- ���� ������
      UPDATE labyrinth_cells
      SET
        wave_number = wave,
        state_id = 5
      WHERE labyrinth_id = aID AND x = x_in AND y = y_in;
      COMMIT; 
    END IF;
    IF (state_in = 2) THEN
      return 1;
    END IF;
    
    --print('-------------------'); 
    return 0;
  END set_wave;
  
  procedure set_start_point(
    aID IN labyrinth_run.id%TYPE,
    xvalue IN labyrinth_cells.x%TYPE,
    yvalue IN labyrinth_cells.y%TYPE)
  IS
  BEGIN
    UPDATE labyrinth_cells
    SET 
      state_id = 1
    WHERE labyrinth_id = aID AND x = xvalue AND y = yvalue;
    COMMIT;
  END set_start_point;
    
  procedure set_end_point(
    aID IN labyrinth_run.id%TYPE,
    xvalue IN labyrinth_cells.x%TYPE,
    yvalue IN labyrinth_cells.y%TYPE)
  IS
  BEGIN
    UPDATE labyrinth_cells
    SET 
      state_id = 2
    WHERE labyrinth_id = aID AND x = xvalue AND y = yvalue;   
    COMMIT; 
  END set_end_point;
  
  procedure change_labyrinth_item(
    aID IN labyrinth_run.id%TYPE,
    xvalue IN labyrinth_cells.x%TYPE,
    yvalue IN labyrinth_cells.y%TYPE,
    state_in IN labyrinth_cell_state.id%TYPE)
  IS
  BEGIN
    UPDATE labyrinth_cells
    SET
        state_id = state_in
    WHERE labyrinth_id = aID AND x = xvalue AND y = yvalue;
    COMMIT;
  END change_labyrinth_item;
  
END labyrinth;
/
