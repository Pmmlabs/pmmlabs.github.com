begin
/*
labyrinth.create_labyrinth_size('small', 10, 10);
labyrinth.create_labyrinth_size('big', 20, 20);
labyrinth.create_labyrinth_size('large', 40, 40);

labyrinth.create_labyrinth_cell_state('Start', 's'); -- 1
labyrinth.create_labyrinth_cell_state('Exit', 'e'); -- 2
labyrinth.create_labyrinth_cell_state('Wall', 'x'); -- 3
labyrinth.create_labyrinth_cell_state('Pass', ' '); -- 4
labyrinth.create_labyrinth_cell_state('Num', ' '); -- 5
labyrinth.create_labyrinth_cell_state('Way', '+'); -- 6

labyrinth.create_labyrinth('big');
labyrinth.set_start_point(1, 8, 3);
labyrinth.set_end_point(1, 6, 12);
labyrinth.print_labyrinth(4, false);
labyrinth.run_wave(2);

labyrinth.change_labyrinth_item(22, 9, 6, 4);
labyrinth.print_labyrinth(22, true);
*/



labyrinth.run_wave(22);


end;
