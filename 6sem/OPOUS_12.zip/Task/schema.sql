-- ������� ����������
CREATE TABLE labyrinth_size(
  id integer primary key,
  name varchar(15),
  height integer,
  width integer);

-- ������ ����������
CREATE TABLE labyrinth_cells(
  id integer primary key,
  labyrinth_id integer,
  x integer,
  y integer,
  state_id integer,
  wave_number integer);
  
-- ���������
CREATE TABLE labyrinth_run(
  id integer primary key,
  labyrinth_size_id integer,
  dat date,
  result integer);

-- ��������� ������
CREATE TABLE labyrinth_cell_state(
  id integer primary key,
  name varchar(50),
  state varchar(1));
  
-- seq ��� primary key
CREATE SEQUENCE labyrinth_size_seq_ID START WITH 1 INCREMENT BY 1 NOCYCLE;
CREATE SEQUENCE labyrinth_cells_seq_ID START WITH 1 INCREMENT BY 1 NOCYCLE;
CREATE SEQUENCE labyrinth_run_seq_ID START WITH 1 INCREMENT BY 1 NOCYCLE;
CREATE SEQUENCE labyrinth_cell_state_seq_ID START WITH 1 INCREMENT BY 1 NOCYCLE;

/*
-- ��������
CREATE OR REPLACE TRIGGER BI_labyrinth_size
BEFORE INSERT ON labyrinth_size
REFERENCING OLD AS OLD NEW AS NEW
FOR EACH ROW
 WHEN (NEW.ID IS NULL)
BEGIN
  select labyrinth_size_seq_ID.NEXTVAL
   INTO :NEW.ID from dual;
END;

CREATE OR REPLACE TRIGGER BI_labyrinth_cells
BEFORE INSERT ON labyrinth_cells
REFERENCING OLD AS OLD NEW AS NEW
FOR EACH ROW
 WHEN (NEW.ID IS NULL)
BEGIN
  select labyrinth_cells_seq_ID.NEXTVAL
   INTO :NEW.ID from dual;
END;

CREATE OR REPLACE TRIGGER BI_labyrinth_run
BEFORE INSERT ON labyrinth_run
REFERENCING OLD AS OLD NEW AS NEW
FOR EACH ROW
 WHEN (NEW.ID IS NULL)
BEGIN
  select labyrinth_run_seq_ID.NEXTVAL
   INTO :NEW.ID from dual;
END;

CREATE OR REPLACE TRIGGER BI_labyrinth_cell_state
BEFORE INSERT ON labyrinth_cell_state
REFERENCING OLD AS OLD NEW AS NEW
FOR EACH ROW
 WHEN (NEW.ID IS NULL)
BEGIN
  select labyrinth_cell_state_seq_ID.NEXTVAL
   INTO :NEW.ID from dual;
END;*/
