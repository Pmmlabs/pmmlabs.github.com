﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace t2
{
    class Founder
    {
        private string path;
        private ListView lvMain;
        private TextBox mTextBox;
        private int count = 0;

        public int getCount()
        {
            return count;
        }

        public Founder(string _path, ListView _lvMain, TextBox aTextBox)
        {
            path = _path;
            lvMain = _lvMain;
            mTextBox = aTextBox;
        }

        public void getSubDirs()
        {
            try
            {
                foreach (string dir in RsdnDirectory.GetDirectories(path))
                {
                    if ((dir != ".") && (dir != ".."))
                    {
                        ListViewItem test = new ListViewItem(dir, 0);
                        test.ImageIndex = 0;
                        lvMain.Invoke(new MethodInvoker(delegate() { lvMain.Items.AddRange(new ListViewItem[] { test }); }));
                    }
                }
            }
            catch (Exception ex)
            {
                /*
                if (tb.InvokeRequired)
                    tb.Invoke(new Action<string>((tbtest) => tb.AppendText(tbtest)),ex.Message );*/                
            }
        }

        public void getFilesAndDirsInDir()
        {
            try
            {
                foreach (string file in RsdnDirectory.GetFiles(path))
                {

                    if ((file != ".") && (file != ".."))
                    {
                        ListViewItem test = new ListViewItem(file, 0);
                        test.ImageIndex = 1;
                        lvMain.Invoke(new MethodInvoker(delegate() { lvMain.Items.AddRange(new ListViewItem[] { test }); }));
                    }
                }

                foreach (string dir in RsdnDirectory.GetDirectories(path))
                {

                    if ((dir != ".") && (dir != ".."))
                    {
                        ListViewItem test = new ListViewItem(dir, 0);
                        test.ImageIndex = 0;
                        lvMain.Invoke(new MethodInvoker(delegate() { lvMain.Items.AddRange(new ListViewItem[] { test }); }));
                    }
                }
            }
            catch (Exception ex)
            {
                /*
                if (tb.InvokeRequired)
                    tb.Invoke(new Action<string>((tbtest) => tb.AppendText(tbtest)),ex.Message );*/
            }
        }

        public void getInformation()
        {
            try
            {
                mTextBox.Invoke(new MethodInvoker(delegate
                {
                    mTextBox.Text = String.Format("Directory - {0}", RsdnDirectory.GetFilesInfo(path).Count(x => x.Directory && x.Path != "." && x.Path != "..")) +
                                    Environment.NewLine +
                                    String.Format("Read Only - {0}", RsdnDirectory.GetFilesInfo(path).Count(x => x.ReadOnly)) +
                                    Environment.NewLine +
                                    String.Format("Hidden - {0}", RsdnDirectory.GetFilesInfo(path).Count(x => x.Hidden)) +
                                    Environment.NewLine +
                                    String.Format("System - {0}", RsdnDirectory.GetFilesInfo(path).Count(x => x.System)) +
                                    Environment.NewLine +
                                    String.Format("Archive - {0}", RsdnDirectory.GetFilesInfo(path).Count(x => x.Archive)) +
                                    Environment.NewLine +
                                    String.Format("Device - {0}", RsdnDirectory.GetFilesInfo(path).Count(x => x.Device)) +
                                    Environment.NewLine +
                                    String.Format("Normal - {0}", RsdnDirectory.GetFilesInfo(path).Count(x => x.Normal)) +
                                    Environment.NewLine +
                                    String.Format("Temporary - {0}", RsdnDirectory.GetFilesInfo(path).Count(x => x.Temporary)) +
                                    Environment.NewLine +
                                    String.Format("Sparse File - {0}", RsdnDirectory.GetFilesInfo(path).Count(x => x.SparseFile)) +
                                    Environment.NewLine +
                                    String.Format("Reparse Point - {0}", RsdnDirectory.GetFilesInfo(path).Count(x => x.ReparsePoint)) +
                                    Environment.NewLine +
                                    String.Format("Compressed - {0}", RsdnDirectory.GetFilesInfo(path).Count(x => x.Compressed)) +
                                    Environment.NewLine +
                                    String.Format("Offline - {0}", RsdnDirectory.GetFilesInfo(path).Count(x => x.Offline)) +
                                    Environment.NewLine +
                                    String.Format("Not Content Indexed - {0}", RsdnDirectory.GetFilesInfo(path).Count(x => x.NotContentIndexed)) +
                                    Environment.NewLine +
                                    String.Format("Encrypted - {0}", RsdnDirectory.GetFilesInfo(path).Count(x => x.Encrypted)) +
                                    Environment.NewLine;
                }));
            }
            catch
            {

            }
        }

        public void getInformationDetail()
        {
            try
            {
                foreach (var item in RsdnDirectory.GetFilesInfo(path).Where(x => x.Path != ".." && x.Path != "."))
                {
                    string ret = string.Empty;

                    ret = ret + (item.Directory ? "Directory|" : "");
                    ret = ret + (item.ReadOnly ? "Read Only|" : "");
                    ret = ret + (item.Hidden ? "Hidden|" : "");
                    ret = ret + (item.System ? "System|" : "");
                    ret = ret + (item.Archive ? "Archive|" : "");
                    ret = ret + (item.Device ? "Device|" : "");
                    ret = ret + (item.Temporary ? "Temporary|" : "");
                    ret = ret + (item.SparseFile ? "Sparse File|" : "");
                    ret = ret + (item.ReparsePoint ? "Reparse Point|" : "");
                    ret = ret + (item.Compressed ? "Compressed|" : "");
                    ret = ret + (item.Offline ? "Offline|" : "");
                    ret = ret + (item.NotContentIndexed ? "Not Content Indexed|" : "");
                    ret = ret + (item.Encrypted ? "Encrypted|" : "");

                    mTextBox.Invoke(new MethodInvoker(delegate
                    {
                        mTextBox.Text = mTextBox.Text +
                            String.Format(item.Path + " - {0}", ret.Remove(ret.LastIndexOf("|"),1)) +
                            Environment.NewLine + Environment.NewLine;
                    }));
                }
            }
            catch
            {

            }
        }

    }
}
