﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace t2
{
    internal class FInfo
    {
        public string Path { get; set; }
        public bool ReadOnly { get; set; }
        public bool Hidden { get; set; }
        public bool System { get; set; }
        public bool Directory { get; set; }
        public bool Archive { get; set; }
        public bool Device { get; set; }
        public bool Normal { get; set; }
        public bool Temporary { get; set; }
        public bool SparseFile { get; set; }
        public bool ReparsePoint { get; set; }
        public bool Compressed { get; set; }
        public bool Offline { get; set; }
        public bool NotContentIndexed { get; set; }
        public bool Encrypted { get; set; }
    }
}
