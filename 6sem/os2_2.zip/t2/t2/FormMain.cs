﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace t2
{
    public partial class FormMain : Form
    {

        private Thread foundDirs;
        private Thread infThread;
        private bool mIsOpened;

        private class Counts
        {
            public string Extension { get; set; }
            public int Count { get; set; }
        }

        public FormMain()
        {
            InitializeComponent();
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                mIsOpened = true;
                if (folderBrowserDialog1.SelectedPath.Length < 4)
                {
                    txtPath.Text = folderBrowserDialog1.SelectedPath.Replace(@"\\", @"\");
                }
                else
                {
                    txtPath.Text = folderBrowserDialog1.SelectedPath;
                }
                UpdateFoldersList();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            if (mIsOpened && txtPath.Text.Length > 3)
            {
                txtPath.Text = txtPath.Text.Remove((txtPath.Text.Remove(txtPath.Text.LastIndexOf("\\"))).LastIndexOf("\\"));
                txtPath.Text += "\\";
                UpdateFoldersList();
            }
        }

        private void lstFolders_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (ListViewItem item in lstFolders.SelectedItems)
            {
                // TODO : проверка на папку
                txtPath.Text += item.Text + "\\";
                UpdateFoldersList();
            }
        }

        private void UpdateFoldersList()
        {
            if (foundDirs != null)
             if (foundDirs.ThreadState != ThreadState.Stopped)
                 foundDirs.Abort();

            Founder test = new Founder(txtPath.Text, lstFolders, txtStatistics);
            foundDirs = new Thread(test.getFilesAndDirsInDir);
            lstFolders.Clear();
            foundDirs.Start();

            if (infThread != null)
                if (infThread.ThreadState != ThreadState.Stopped)
                    infThread.Abort();

            infThread = new Thread(test.getInformation);
            txtStatistics.Text = string.Empty;
            infThread.Start();
        }

        private void btnDetail_Click(object sender, EventArgs e)
        {
            if (infThread != null)
                if (infThread.ThreadState != ThreadState.Stopped)
                    infThread.Abort();

            Founder test = new Founder(txtPath.Text, lstFolders, txtStatistics);

            infThread = new Thread(test.getInformationDetail);
            txtStatistics.Text = string.Empty;
            infThread.Start();
        }

        private void btnShort_Click(object sender, EventArgs e)
        {
            if (infThread != null)
                if (infThread.ThreadState != ThreadState.Stopped)
                    infThread.Abort();

            Founder test = new Founder(txtPath.Text, lstFolders, txtStatistics);

            infThread = new Thread(test.getInformation);
            txtStatistics.Text = string.Empty;
            infThread.Start();
        }

    }
}
