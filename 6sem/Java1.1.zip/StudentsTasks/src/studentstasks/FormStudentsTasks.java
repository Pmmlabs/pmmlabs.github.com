package studentstasks;

import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableModel;

/*Реализовать таблицу и Renderer+Editor для неё, для удобного редактирования дат
 * При выходе и входе в программу содержимое таблицы должно сохраниться. 
 * Пример: колонки : Список студентов(ФИО), дата сдачи зад.1, дата сдачи зад.2, дата сдачи зад.3.*/

public class FormStudentsTasks extends JFrame{
    ArrayList<Schedule> listSchedule;
    Connection connection;
    
    public FormStudentsTasks(){
        super("Расписание сдачи заданий");
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        DBConnection dbcon = new DBConnection();
        connection = dbcon.getConnectionMySql("root", "admin");
        
        listSchedule = Schedule.getScheduleList(connection);
        
                addWindowListener( new WindowAdapter(){
            public void windowClosing(WindowEvent e)
            {
                for(int i=0; i<listSchedule.size(); i++){
                    listSchedule.get(i).UpdateSchedule(connection);
                }
                setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            }
        });
        
        TableModel model = new StudentsTableModel(listSchedule);
        JTable table = new JTable(model);
       
        
         table.getColumnModel().getColumn(0).setMinWidth(20);
         table.getColumnModel().getColumn(0).setMaxWidth(20); 
         table.getColumnModel().getColumn(1).setMinWidth(220);
         table.getColumnModel().getColumn(1).setMaxWidth(220);
         table.setRowHeight(20);
         table.getColumnModel().getColumn(0).setResizable(false);
         table.getColumnModel().getColumn(1).setResizable(false);
         
         //table.getColumnModel().getColumn(2).setCellRenderer(new DateCellRendererEditor());
         table.getColumnModel().getColumn(2).setCellEditor(new DateCellRendererEditor());
         //table.getColumnModel().getColumn(3).setCellRenderer(new DateCellRendererEditor());
         table.getColumnModel().getColumn(3).setCellEditor(new DateCellRendererEditor());
         //table.getColumnModel().getColumn(4).setCellRenderer(new DateCellRendererEditor());
         table.getColumnModel().getColumn(4).setCellEditor(new DateCellRendererEditor());
         //table.getColumnModel().getColumn(5).setCellRenderer(new DateCellRendererEditor());
         table.getColumnModel().getColumn(5).setCellEditor(new DateCellRendererEditor());
        
        
        getContentPane().add(new JScrollPane(table));
        setPreferredSize(new Dimension(700, 250));
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JFrame.setDefaultLookAndFeelDecorated(true);
                new FormStudentsTasks();
            }
        });
    }
    
}
