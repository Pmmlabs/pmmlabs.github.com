package studentstasks;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;


public class StudentsTableModel implements TableModel {

    private List<Schedule> schedules;
    //private DateFormat df = new SimpleDateFormat("Y-MM-dd", Locale.ENGLISH);
    
    public StudentsTableModel(List<Schedule> aSchedule){
        this.schedules = aSchedule;
    }
    
    
    @Override
    public int getRowCount() {
        return schedules.size();
    }

    @Override
    public int getColumnCount() {
        return 6;       
    }

    @Override
    public String getColumnName(int columnIndex) {
         switch (columnIndex){
            case 0:
                 return "ID";
            case 1: 
                return "ФИО";
            case 2:
                return "Задача №1";
            case 3:
                return "Задача №2";
            case 4:
                return "Задача №3";
            case 5:
                return "Задача №4";
        }
        return "";
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        switch (columnIndex){
            case 0: 
                return Integer.class;
            case 1:
                return String.class;
            case 2:
                return Date.class;
            case 3:
                return Date.class;
            case 4:
                return Date.class;
            case 5:
                return Date.class;
        }
        return null;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
       switch (columnIndex) {
        case 0:
            return false;
        case 1:
            return false;
         }        
        return true;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Schedule schedule = schedules.get(rowIndex);
        switch (columnIndex) {
        case 0:
            return schedule.getStudent_ID();
        case 1:
            return schedule.getName();    
        case 2:
            return schedule.getFirstTaskDate();
        case 3:
            return schedule.getSecondTaskDate();
        case 4:
            return schedule.getThirdTaskDate();
        case 5:
            return schedule.getFourthTaskDate();
         }
        return "";
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        Schedule schedule = schedules.get(rowIndex); 
        switch (columnIndex) {
        case 0:
            schedule.setStudent_ID((Integer) aValue);
        case 1:
            schedule.setName((String) aValue);    
        case 2:
            schedule.setFirstTaskDate((Date) aValue);
            break;
        case 3:
            schedule.setSecondTaskDate((Date) aValue);
            break;
        case 4:
            schedule.setThirdTaskDate((Date) aValue);
            break;
        case 5:
            schedule.setFourthTaskDate((Date) aValue);
            break;
         } 
    }
    
    private Set<TableModelListener> listeners = new HashSet<TableModelListener>();

    @Override
    public void addTableModelListener(TableModelListener l) {
        listeners.add(l);
    }

    @Override
    public void removeTableModelListener(TableModelListener l) {
        listeners.remove(l);        
    }
    
}
