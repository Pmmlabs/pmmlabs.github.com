/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package studentstasks;

import java.awt.Component;
import java.util.Date;
import java.util.EventObject;
import javax.swing.AbstractCellEditor;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import org.jdesktop.swingx.JXDatePicker;

class DateCellRendererEditor extends AbstractCellEditor implements TableCellRenderer, TableCellEditor {

    private static final long serialVersionUID = 1L;
    private JXDatePicker renderer = new JXDatePicker();
    private JXDatePicker editor = new JXDatePicker();
    
    public DateCellRendererEditor(){
        //renderer.setFormats("Y-MM-dd");
        //editor.setFormats("Y-MM-dd");       
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        if (value != ""){
        renderer.setDate((Date) value);
        }
        return renderer;
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        editor.setDate((Date) value);     
        return editor;
    }

    @Override
    public Object getCellEditorValue() {
        if ("".equals(editor.getEditor().getText())){
            return null;
        }
        return editor.getDate();
    }

    @Override
    public boolean isCellEditable(EventObject anEvent) {
        return true;
    }

    @Override
    public boolean shouldSelectCell(EventObject anEvent) {
        return false;
    }
}