package studentstasks;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Schedule {
   private String mName;
   private Integer mStudent_id;
   private Date mFirstTaskDate;
   private Date mSecondTaskDate;
   private Date mThirdTaskDate;
   private Date mFourthTaskDate;
   private boolean IsModify;
   
    public Schedule(Integer aStudent_id, String aName, Date aFirstTaskDate, Date aSecondTaskDate, Date aThirdTaskDate, Date aFourthTaskDate) {
            this.setName(aName);
            this.setStudent_ID(aStudent_id);
            this.mFirstTaskDate = aFirstTaskDate;
            this.mSecondTaskDate = aSecondTaskDate;
            this.mThirdTaskDate = aThirdTaskDate;
            this.mFourthTaskDate = aFourthTaskDate;
            this.IsModify = false;
    }
    
    public void setName(String aFName){
        this.mName = aFName;
    }
    
    public String getName(){
        return mName;
    }
    
    public void setStudent_ID(Integer aStudent_id){
        this.mStudent_id = aStudent_id;
    }
    
    public Integer getStudent_ID(){
        return mStudent_id;
    }
    
    public boolean getIsModify(){
        return IsModify;
    }
    
    public void setFirstTaskDate(Date aDate){
        mFirstTaskDate = aDate;
        this.IsModify = true;
    }
    public void setSecondTaskDate(Date aDate){
        mSecondTaskDate = aDate;
        this.IsModify = true;
    }
    public void setThirdTaskDate(Date aDate){
        mThirdTaskDate = aDate;
        this.IsModify = true;
    }
    public void setFourthTaskDate(Date aDate){
        mFourthTaskDate = aDate;
        this.IsModify = true;
    }
    
    
    public Date getFirstTaskDate(){
        return mFirstTaskDate;
    }
     public Date getSecondTaskDate(){
        return mSecondTaskDate;
    }
    public Date getThirdTaskDate(){
        return mThirdTaskDate;
    }
    public Date getFourthTaskDate(){
        return mFourthTaskDate;
    }
    
    public static ArrayList<Schedule> getScheduleList(Connection dbCon){
       Statement stmt = null;
       ArrayList<Schedule> sch = new ArrayList<>();
          try
          {
            stmt = dbCon.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT s.fname,s.lname,s.pname,t.id, t.task1, t.task2, t.task3, t.task4 FROM tasks t\n" +
                "JOIN students s ON s.id = t.student_id;");
            while (rs.next())
            {               
              int id = rs.getInt("id");
              String fname = rs.getString("lname") +" "+ rs.getString("fname") +" "+ rs.getString("pname");
              Date first_task_date = rs.getDate("task1");
              Date second_task_date = rs.getDate("task2");
              Date third_task_date = rs.getDate("task3");
              Date fourth_task_date = rs.getDate("task4");
              sch.add(new Schedule( id, fname, first_task_date, second_task_date, third_task_date, fourth_task_date));
            }
          }
          catch(Exception ex)
          {
          }

          try
          {
            stmt.close();
          }
          catch(Exception ex)
          {
          } 
          return sch;
    }
    
    public void UpdateSchedule(Connection dbCon){
        if (IsModify){
            Statement stmt = null;
            DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            try
            {
                StringBuilder str = new StringBuilder();
                str.append("UPDATE tasks SET ").append("task1 = ");
                if (mFirstTaskDate != null){
                    str.append("'").append(format.format(mFirstTaskDate)).append("', ");
                } else {
                    str.append("null, ");
                }
                str.append("task2 = ");
                if (mSecondTaskDate != null){
                    str.append("'").append(format.format(mSecondTaskDate)).append("', ");
                } else {
                    str.append("null, ");
                }
                str.append("task3 = ");
                if (mThirdTaskDate != null){
                    str.append("'").append(format.format(mThirdTaskDate)).append("', ");
                } else {
                    str.append("null, ");
                }
                str.append("task4 = ");
                if (mFourthTaskDate != null){
                    str.append("'").append(format.format(mFourthTaskDate)).append("' ");
                } else {
                    str.append("null ");
                }
                str.append("WHERE id = ").append(mStudent_id).append(";");
                
                stmt = dbCon.createStatement();
                stmt.executeUpdate(str.toString());
            }
            catch(Exception ex)
            {
            }
          
            try
            {
                stmt.close();
            }
            catch(Exception ex)
            {
            }
        }
    }
}