/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package studentstasks;

import java.awt.Component;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.AbstractCellEditor;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import org.jdesktop.swingx.JXDatePicker;

/**
 *
 * @author Павел
 */
public class DateTableCellEditor extends AbstractCellEditor implements TableCellEditor {

    String input;
    
    @Override
    public Object getCellEditorValue() {
       return input;
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        if (isSelected)
        {
//            JOptionPane dialog = new JOptionPane();
//            input = dialog.showInputDialog(null, "new value");
            JXDatePicker picker = new JXDatePicker();
            picker.setFormats(new SimpleDateFormat("Y-MM-dd"));
            picker.setDate((Date)value);
            return picker;   
        }
        return null;
    }
    
}
