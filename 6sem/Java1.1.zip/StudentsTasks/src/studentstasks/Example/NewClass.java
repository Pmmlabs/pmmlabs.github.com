/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package studentstasks;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Павел
 */
public class NewClass {
    public static void main(String args[]) throws SQLException {
     DBConnection dbcon = new DBConnection();
     Connection connection = dbcon.getConnectionMySql("root", "admin");
     
    DatabaseMetaData md;
        try {
            md = connection.getMetaData();
            System.out.println(md.getDatabaseMajorVersion());
            System.out.println(md);
        } catch (SQLException ex) {
            Logger.getLogger(NewClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        Statement stmt = null;
  try
  {
    stmt = connection.createStatement();
    ResultSet rs = stmt.executeQuery("select * from student;");
    while (rs.next())
    {
      int id = rs.getInt(1);
      String name = rs.getString(2);
      System.out.println("Row: " +id+ "     " + name);
    }
  }
  catch(Exception ex)
  {
    ex.printStackTrace();
  }
    }
}
