use task1;

DROP TABLE IF EXISTS `student`;
CREATE TABLE
    `student` (
        `id` INT(11) NOT NULL AUTO_INCREMENT,
        `fname` CHAR(30) NOT NULL,
        `lname` CHAR(30) NOT NULL,
		`pname` CHAR(30) NULL,
        PRIMARY KEY(`id`)
    );

DROP TABLE IF EXISTS `tasks`;
CREATE TABLE
    `tasks` (
        `id` INT(11) NOT NULL AUTO_INCREMENT,
        `task_name` CHAR(50) NOT NULL,
        PRIMARY KEY(`id`)
    );

DROP TABLE IF EXISTS `schedule`;
CREATE TABLE
	`schedule` (
		`id` INT(11) NOT NULL AUTO_INCREMENT,
		`student_id` INT(11) NOT NULL,
		`task_id` INT(11) NOT NULL,
		`task_date` DATETIME NOT NULL,
		PRIMARY KEY(`id`)
	);


