﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCHM_Lab3
{
    public partial class Form1 : Form
    {
        Random rnd;
        public Form1()
        {
            InitializeComponent();
            rnd = new Random((int)System.DateTime.Now.Ticks);
            dataGridView1.Rows.Add(11);
        }

        private InitData Generate(int N, int range, double eps)
        {
            double[,] A = new double[N, N];
            double[,] dopA = new double[N, N];
            double[,] H = new double[N, N];
            double[] L = new double[N];
            double[] w = new double[N];
            int indexValue = -1, countMin = 2;
            double minValue;
            while (countMin > 1)
            { 
                minValue = range * 10 + 1;
                for (int i=0; i<N; i++)
                    L[i] = Convert.ToDouble(rnd.Next(-range * 10, range * 10)) / 10;
                for (int i = 0; i < N; i++)
                {
                    if (Math.Abs(L[i]) == minValue)
                        countMin++;
                    if (Math.Abs(L[i]) < minValue)
                    {
                        minValue = Math.Abs(L[i]);
                        countMin = 1;
                        indexValue = i;
                    }
                }
            }
            
            for (int i = 0; i < N; i++)
            {
                w[i] = Convert.ToDouble(rnd.Next(-100, 100)) / 10;
            }
            double length = LengthOfVector(w);
            for (int i = 0; i < N; i++)
                w[i] = w[i] / length;
            
            //Генерация матрицы Хаусхолдера
            for (int i = 0; i < N; i++)
                for (int j = 0; j < N; j++)
                    H[i, j] = -2 * w[i] * w[j];
            for (int i = 0; i < N; i++)
                H[i, i] += 1;


            //Генерация матрицы А
            for (int i = 0; i < N; i++)
                for (int j = 0; j < N; j++)
                    dopA[i, j] = H[i, j] * L[j];
            for (int i = 0; i < N; i++)
                for (int j = 0; j < N; j++)
                {
                    A[i, j] = 0;
                    for (int k = 0; k < N; k++)
                        A[i, j] += dopA[i, k] * H[j, k];
                }

            double[] eigenVector = new double[N];
            for (int i = 0; i < N; i++)
                eigenVector[i] = H[indexValue, i];

            InitData obj = new InitData(N,A,L[indexValue],Normallized(eigenVector),eps,1000);
            return obj;
        }
        private double LengthOfVector(double[] a)
        {
            double res = 0;
            for (int i = 0; i < a.Length; i++)
                res += a[i] * a[i];
            return Math.Sqrt(res);
        }
        private double eigenValue(double sobs_znach1,double sobs_znach2)
        {
            double eigenValue=0;
            return eigenValue=Math.Abs(sobs_znach2-sobs_znach1);
        }

        private double eigenVector(double sobs_vect1, double sobs_vect2)
        {
            double eigenVector = 0;
            return eigenVector = Math.Abs(sobs_vect2 - sobs_vect1);
        }
        private double[] Halessky(double[,] A, double[] rightPart, int N, ref int code)   //Метод Халецкого
        {
            code = 0;
            double[] x = new double[N];
            double[] y = new double[N];
            double[,] B = new double[N, N];
            double R = 0;
            for (int j = 0; j < N; j++)
            {
                for (int i = j; i < N; i++)
                {
                    B[i, j] = A[i, j];
                    for (int k = 0; k <= j - 1; k++)
                    {
                        if (B[k,k] == 0) {
                            code = 1;
                            return x;
                        }
                        R = 1 / B[k, k];
                        B[i, j] -= B[i, k] * B[j, k] * R;
                    }
                }
            }
            //Обратный ход метода
            double sum = 0;
            for (int i = 0; i < N; i++)
            {
                y[i] = rightPart[i];
                for (int k=0; k<=i-1; k++)
                {
                    y[i] -= B[i, k] * y[k];
                }
                if (B[i, i] == 0)
                {
                    code = 1;
                    return x;
                }
                R = 1 / B[i, i];
                y[i] = y[i] * R;
            }
            for (int i = N - 1; i >= 0; i--)
            {
                x[i] = y[i];
                sum = 0;
                for (int k = i + 1; k < N; k++)
                {
                    sum += B[k, i] * x[k];
                }
                if (B[i, i] == 0)
                {
                    code = 1;
                    return x;
                }
                R = 1 / B[i, i];
                x[i] -= sum * R;
            }
            return x;
        }
        private OutputData Method(InitData obj)
        {
            double[,] A = obj.matrix;
            int N = obj.size;
            double eps = obj.eps;
            int maxNumOfTerrace = obj.maxNumOfTerrace;
            double eigenValue = obj.eigenValue;
            double[] eigenVector = obj.eigenVector;

            double[] x = new double[N];
            double[] nuk = new double[N];
            double[] nuk_1 = new double[N];
            double valOfCos;
            double alpha = 90, alphaNew = 90;
            double eigenValue_calc, eigenValueNew_calc = -1;
            int code = 0;
            for (int i = 0; i < N; i++)
            {
                nuk_1[i] = Convert.ToDouble(rnd.Next(-20,20))/10;
            }
            int count = 0;
            bool flag = false;
            while (!flag && (count < maxNumOfTerrace))
            {
                eigenValue_calc = eigenValueNew_calc;
                alpha = alphaNew;
                nuk = nuk_1;
                x = Halessky(A, nuk, N, ref code);
                if (code == 1)
                    return null;
                nuk_1 = Normallized(x);
                valOfCos = ScalarProduct(nuk, nuk_1);
                if (valOfCos > 1)
                    valOfCos = 1;
                alphaNew = Math.Sqrt(2*(1-valOfCos));
                eigenValueNew_calc = ScalarProduct(nuk, x);
                if (Math.Abs(alpha - alphaNew)<(eps / 2) && Math.Abs(eigenValueNew_calc - eigenValue_calc)<eps)
                {
                    flag = true;
                }
                count++;
            }

            double[] calculatedEigenVector = new double[N];
            double calculatedEigenValue;
            calculatedEigenValue = (1.0) / ScalarProduct(nuk,x);
            calculatedEigenVector = nuk_1;
            OutputData result = new OutputData(0, calculatedEigenValue, calculatedEigenVector, 
                count, Math.Abs(eigenValue - calculatedEigenValue), 
                GetErrorOfEigenVector(eigenVector, calculatedEigenVector), 
                GetMeasureOfAccuracy(A, calculatedEigenValue, calculatedEigenVector));
            return result;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
        }
        private double ScalarProduct(double[] a, double[] b)
        {
            double res = 0;
            for (int i = 0; i < a.Length; i++)
                res += a[i] * b[i];
            return res;
        }
        private double GetErrorOfEigenVector(double[] a, double[] b)
        {
            double res = Min(Math.Abs((a[0] - b[0])), Math.Abs((a[0] + b[0])));
            double curr;
            for (int i = 0; i < a.Length; i++)
            {
                curr = Min(Math.Abs((a[i] - b[i])), Math.Abs((a[i] + b[i])));
                if (curr > res)
                    res = curr;
            }
            return res;
        }
        private double GetMeasureOfAccuracy(double[,] A, double val, double[] vector)
        {
            int N = vector.Length;
            double[] a = new double[N];
            double[] b = new double[N];
            for (int i = 0; i < N; i++)
            {
                a[i] = 0;
                b[i] = val * vector[i];
                for (int k = 0; k < N; k++)
                {
                    a[i] += A[i, k] * vector[k];
                }
            }
            return VariationFromZero(a, b);
        }
        private double VariationFromZero(double[] a, double[] b)
        {
            double res = Math.Abs(a[0] - b[0]);
            double curr;
            for (int i = 0; i < a.Length; i++)
            {
                curr = Math.Abs(a[i] - b[i]);
                if (curr > res)
                    res = curr;
            }
            return res;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            /*InitData obj = InitInputData(10, 2, 0.00001);
            double[,] A = obj.matrix;
            int N = obj.size;
            double[] solve = new double[N];
            double[] rightPart = new double[N];
            for (int i=0; i<N; i++)
                solve[i] = Convert.ToDouble(rnd.Next(-100, 100)) / 10;
            for (int i = 0; i < N; i++)
            {
                rightPart[i] = 0;
                for (int k = 0; k < N; k++)
                    rightPart[i] += A[i, k] * solve[k];
            }
            double[] calculatedSolve = GetSolveOfSystem(A, rightPart, N);
            textBox1.Text = GetErrorOfEigenVector(solve, calculatedSolve).ToString();*/

            List<double> listVal = new List<double>();
            List<double> listVector = new List<double>();
            List<double> listMeasure = new List<double>();
            List<double> listTerrace = new List<double>();
            InitData obj;
            OutputData res;
            int N = 10;
            int range = 2;
            int eps = 5;
            int count = 0;
            int happyCycle = 0;
            for (N = 10; N <= 50; N += 20 )
            {
                for (range = 2; range <= 50; range += 48)
                {
                    for (eps = 5; eps <= 8; eps += 3)
                    {
                        dataGridView1.Rows[count].Cells[0].Value = (count + 1).ToString();
                        dataGridView1.Rows[count].Cells[1].Value = N.ToString();
                        dataGridView1.Rows[count].Cells[2].Value = "-" + range.ToString() + ":" + range.ToString();
                        double prec = Math.Pow(10, -eps);
                        dataGridView1.Rows[count].Cells[3].Value = prec.ToString();
                        happyCycle = 0;
                        listVal.Clear();
                        listVector.Clear();
                        listTerrace.Clear();
                        listMeasure.Clear();
                        while (happyCycle < 10)
                        {
                            obj = Generate(N, range, prec);
                            res = Method(obj);
                            if (res != null)
                            {
                                listVal.Add(res.errorOfEigenValue);
                                listVector.Add(res.errorOfEigenVector);
                                listMeasure.Add(res.measureOfAccuracy);
                                listTerrace.Add(res.terrace);
                                happyCycle++;
                            }
                        }
                        dataGridView1.Rows[count].Cells[4].Value = AverageValue(listVal);
                        dataGridView1.Rows[count].Cells[5].Value = AverageValue(listVector);
                        dataGridView1.Rows[count].Cells[6].Value = AverageValue(listMeasure);
                        dataGridView1.Rows[count].Cells[7].Value = AverageValue(listTerrace);
                        count++;
                    }
                }
            }
            
        }

        private double[] Normallized(double[] x)
        {
            double[] result = new double[x.Length];
            double length = LengthOfVector(x);
            for (int i = 0; i < x.Length; i++)
                result[i] = x[i] / length;
            return result;
        }
        private double AverageValue(List<double> list)
        {
            double res = 0;
            foreach (double val in list)
                res += val;
            return res / list.Count;
        }

        private double Min(double a, double b)
        {
            if (a < b)
                return a;
            else
                return b;
        }
    }
}
