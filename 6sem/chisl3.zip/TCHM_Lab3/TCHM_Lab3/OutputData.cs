﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCHM_Lab3
{
    class OutputData
    {
        public int code
        { get; set; }
        public double calculatedEigenValue
        { get; set; }
        public double[] calculatedEigenVector
        { get; set; }
        public int terrace
        { get; set; }
        public double errorOfEigenValue
        { get; set; }
        public double errorOfEigenVector
        { get; set; }
        public double measureOfAccuracy
        { get; set; }

        public OutputData(int _code, double _calculatedEigenValue, double[] _calculatedEigenVector, 
            int _terrace, double _errorOfEigenValue, double _errorOfEigenVector, double _measureOfAccuracy)
        {
            code = _code;
            calculatedEigenValue = _calculatedEigenValue;
            calculatedEigenVector = _calculatedEigenVector;
            terrace = _terrace;
            errorOfEigenValue = _errorOfEigenValue;
            errorOfEigenVector = _errorOfEigenVector;
            measureOfAccuracy = _measureOfAccuracy;
        }
    }
}
