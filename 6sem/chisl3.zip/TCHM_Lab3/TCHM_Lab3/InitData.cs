﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCHM_Lab3
{
    class InitData
    {
        public int size
        { get; set; }
        public double[,] matrix
        { get; set; }
        public double[] sobs_znach1                                                                                                                              
        { get; set; }                                                                                                                             
        public double[] sobs_vect1                                                                                                                              
        { get; set; }                                                                                                                              
        public double[] sobs_znach2
        { get; set; } 
        public double[] sobs_vect2
        { get; set; }
        public double eps
        { get; set; }                                                                                                                                  public double eigenValue
                                                                                                                                                      { get; set; }
                                                                                                                                                      public double[] eigenVector
                                                                                                                                                      { get; set; }        
        public int maxNumOfTerrace
        { get; set; }

        public InitData(int _size, double[,] _matrix, double _eigenValue, double[] _eigenVector, double _eps, int _maxNumOfTerrace)
        {
            size = _size;
            matrix = _matrix;
            eigenValue = _eigenValue;
            eigenVector = _eigenVector;
            eps = _eps;
            maxNumOfTerrace = _maxNumOfTerrace;
        }
    }
}
