﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO;

namespace os2
{
    class Founder
    {
        string path;
        DateTime date;
        int count = 0;
        
        public int getCount()
        {
            return count;
        }
        public Founder(string _path, DateTime _date)
        {
            path = _path;
            date = _date;
        }
        public void countYungFiles()
        {
            foreach (string dir in RsdnDirectory.GetAllDirectories(path))
            {
                foreach (string file in RsdnDirectory.GetFilse(dir))
                    if (File.GetLastWriteTime(dir+"\\"+file) > date) count++;
            }                                                                                                                                           if (count > 0) count += 2; 
        }
    }
}
