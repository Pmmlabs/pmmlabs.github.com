CREATE OR REPLACE PACKAGE Kommivoyajor AS

  procedure addCity(cname in city.name_city%type);
   
  procedure delCity(cname in city.name_city%type);
  
  function getIdCity(cname in city.name_city%type) return INT;
  
  function getNameCity(idcity in int) return city.name_city%type;
  
  procedure addRoad(c1 in city.name_city%type, c2 in city.name_city%type, ndistance IN INT);
  
  procedure delRoad(c1 IN city.name_city%type, c2 IN city.name_city%type);
  
  function getRoad(city_out in city.id_city%type, city_in in city.id_city%type) return INT;
     
  procedure addGame(city_start in int, city_finish in int,distance int);
  
  function getResultGame(id_game in game.id_game%type) return int;
 
  function getGame(city_start in int, city_finish in int) return int;
  
  procedure getPath(id_game in game.id_game%type);
  
  procedure addPath(id_game in game.id_game%type,id_city_path in int,npossition in int);
  
  procedure delPath(id_game in game.id_game%type);
        
  procedure print;
        
  procedure setStartPosition(idcity in int);
  
  procedure setPosition(temp in int,idcity in int);
  
  function getPosition(idcity in int) return int;
  
  procedure getSolution(cStart in city.name_city%type, cFinish in city.name_city%type);
  
END Kommivoyajor;
/
CREATE OR REPLACE PACKAGE BODY Kommivoyajor AS

  procedure addCity(cname in city.name_city%type)
  is
  begin
    insert into city (id_city,name_city) values (seq_id_city.nextval,cname);
    commit;
  end addCity;
  
  procedure delCity(cname in city.name_city%type)
  is
    idc number;
  begin
    idc:=getIdCity(cname);
    delete from road where id_out_city_fk=idc;
    delete from road where id_input_city_fk=idc;
    delete from city where name_city=cname;
    commit;
  end delCity;
  
  function getNameCity(idcity in int) return city.name_city%type
  is
    cursor cur is select name_city from city where id_city=idcity;
    res cur%rowtype;
  begin
    open cur;
    fetch cur into res;
    close cur;
    return res.name_city;
  end;
  
  function getIdCity(cname in city.name_city%type) return INT
  IS
    cursor getid is select max(id_city) from city where name_city=cname; 
    id_result INT;
  begin
    open getid;
    if getid%notfound
      then
        return 0;
      else
        fetch getid into id_result;
        return id_result;
      end if;
    close getid;
  end getIdCity;
  
  procedure getPath(id_game in game.id_game%type)
  is
    str varchar2(100);
    i INT;
    j INT;
  begin
    DBMS_OUTPUT.enable;
    for i in (select id_city_path_fk from path where id_game_fk=id_game order by path.position) 
    loop
      str:='';
      for j in (select city.id_city from city where city.id_city=i.id_city_path_fk order by city.id_city) 
        loop
          str:=str+getNameCity(i.id_city_path_fk)+'->';
        end loop;
      dbms_output.put_line(str);
    end loop;
  end getPath;
  procedure addPath(id_game in game.id_game%type,id_city_path in int,npossition in int)
  is
  begin
   insert into path(id_path,id_game_fk,id_city_path_fk,position) values(seq_id_path.nextval,id_game,id_city_path,npossition);
   commit;
  end addPath;
  procedure delPath(id_game in game.id_game%type)IS
  i int;
  begin
   for i in (select id_path from path order by id_path) loop
   delete from path where id_game_fk=id_game;
   commit;
   end loop;
  end delPath;
  
  function getRoad(city_out in city.id_city%type, city_in in city.id_city%type) return INT
  is
    cursor getDistance is select distance from road where city_out=id_out_city_fk and city_in=id_input_city_fk;
    cursor getCountDistance is select count(distance) from road where city_out=id_out_city_fk and city_in=id_input_city_fk;
    l INT;
  begin
    open getCountDistance ;
    fetch getCountDistance into l;
    if l=0
      then
        return 0;
      else
        open getDistance;
        fetch getDistance into l;
        return l;
        close getDistance;
      end if;
    close getCountDistance;
  end getRoad;
  procedure addRoad(c1 in city.name_city%type, c2 in city.name_city%type, ndistance IN INT)
  is
    id1 INT;
    id2 INT;
  begin
    id1:=getIdCity(c1);
    id2:=getIdCity(c2);
    if id1<>0 and id2<>0 and ndistance>0 and id1<>id2
      then
        if getRoad(id1,id2)<>0
          then
            update road set distance=ndistance where id_out_city_fk=id1 and id_input_city_fk=id2;
          else
            insert into road (id_road,id_out_city_fk,id_input_city_fk,distance) values (seq_id_road.nextval,id1,id2,ndistance);
          end if;
      end if;
      commit;
  end addRoad;
  procedure delRoad(c1 IN city.name_city%type, c2 IN city.name_city%type)
  is
    idc1 INT;
    idc2 INT;
  begin
    idc1:=getIdCity(c1);
    idc2:=getIdCity(c2);
    delete from road where id_out_city_fk=idc1 and id_input_city_fk=idc2;
    commit;
  end delRoad;
-- ������ ������  
  procedure print
  is
    str varchar2(300);    
    i int;
    j int;
    lenght int;
  begin
    for i in (select id_city from city order by id_city) loop
      str:='';
      for j in (select id_city from city order by id_city) loop
        lenght:=getRoad(i.id_city,j.id_city);       
        str:=' '||getNameCity(i.id_city)||' <--> '||getNameCity(j.id_city)||' = '||lenght||';'||str; 
      end loop;
      dbms_output.put_line(str);
    end loop;
  end print;   

  procedure setStartPosition(idcity in int)is
  begin
   if idcity=0
   then
    update city set tpos=9999999;
    commit;
   else
    update city set tpos=0 where id_city=idcity;
    commit;
   end if; 
  end setStartPosition;
  
  procedure setPosition(temp int,idcity in int)is
  begin
   update city set tpos=temp where id_city=idcity;
   commit;
  end setPosition;
  
  function getPosition(idcity in int) return int
  is
    cursor cur is select tpos from city where id_city=idcity;
    res int;
  begin
    open cur;
    fetch cur into res;
    close cur;
    return res;
  end getPosition;
  
  function getResultGame(id_game in game.id_game%type) return int
  is
  cursor findGame is select result_game from game where game.id_game=id_game;
    gresult INT;
  begin
    open findGame;
    if findGame%notfound
      then
        return 0;
      else
        fetch findGame into gresult;
        return gresult;
      end if;
    close findGame;
  end getResultGame;
  
  function getGame(city_start in int, city_finish in int) return int
  is
  cursor findGame is select id_game from game where (id_city_start_fk=city_start) and (id_city_finish_fk=city_finish);
    id_result INT;
  begin
    open findGame;
    if findGame%notfound
      then
        return 0;
      else
        fetch findGame into id_result;
        return id_result;
      end if;
    close findGame;
  end getGame;
  
  procedure addGame(city_start in int, city_finish in int,distance int)
  is
  cursor findGame is select id_game from game 
                     where  (id_city_start_fk=city_start) and 
                            (id_city_finish_fk=city_finish) and 
                            (result_game=distance);
  begin
    open findGame;
    if findGame%notfound
    then insert into game (id_game,id_city_start_fk,id_city_finish_fk) values (seq_id_game.nextval,city_start,city_finish);
    end if;
  end addGame;
  
  procedure getSolution(cStart in city.name_city%type, cFinish in city.name_city%type)
  is
    cursor curGetSolution(temp in int) is select min(city_temp.id_city) from city city_temp 
                                          where (select tpos from city 
                                                 where id_city=temp)-city_temp.tpos=
                                                (select distance from road 
                                                 where id_out_city_fk=city_temp.id_city and
                                                        id_input_city_fk=temp);
    --flag
    done boolean;
    --Str result
    out_str varchar2(300);
    --index
    i int;
    j int;
    k int;
    --temp value
    temp_value int;
    temp_idgame int;
    -- id city start and finish
    idc_start int; 
    idc_finish int;     
  begin
   DBMS_OUTPUT.enable();
   idc_start:=getIdCity(cStart);
   idc_finish:=getIdCity(cFinish);
   if (idc_start<>idc_finish) then        
    setStartPosition(0);
    setStartPosition(idc_start);
    done:=false;
    while not done loop
      done:=true;
      if (getPosition(idc_finish)=9999999)
      then
        for i in (select id_city from city) loop
          for j in (select id_input_city_fk from road where id_out_city_fk=i.id_city) loop
            if ((getRoad(i.id_city,j.id_input_city_fk)<>0)and
               (getPosition(i.id_city)<>9999999))
            then 
              temp_value:=getRoad(i.id_city,j.id_input_city_fk)+getPosition(i.id_city);              
              if (getPosition(j.id_input_city_fk)=9999999) or 
                 (getPosition(j.id_input_city_fk)>temp_value)
              then           
                setPosition(temp_value,j.id_input_city_fk); 
                done:=false;
              end if;
            end if;            
          end loop; 
        end loop;
      else
        k:=0;
        addGame(idc_start,idc_finish,getPosition(idc_finish));
        temp_idgame:=getGame(idc_start,idc_finish);
        temp_value:=idc_finish;
        addPath(temp_idgame,temp_value,k);
        out_str:=getNameCity(temp_value);
        while temp_value<>idc_start loop
          open curGetSolution(temp_value);
          fetch curGetSolution into temp_value;
          close curGetSolution;
          k:=k+1;
          addPath(temp_idgame,temp_value,k);
          out_str:=getNameCity(temp_value)||'->'||out_str;          
        end loop;
          out_str:='< '||out_str||' >';
          dbms_output.put_line('Result solution : '||getPosition(idc_finish));
      end if;    
    end loop;      
    dbms_output.put_line(out_str);         
    dbms_output.put_line('Done!');
   else
    dbms_output.put_line('Bolt!');
   end if; 
  end getSolution;
 
end Kommivoyajor;
