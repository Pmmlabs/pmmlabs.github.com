
begin
  Kommivoyajor.addCity('Voronej');
  Kommivoyajor.addCity('Rostov');
  Kommivoyajor.addCity('Yaroslavl');
  Kommivoyajor.addCity('Novgorod');
  
  --c_out in city.name_city%type, c_in in city.name_city%type, ndistance IN INT
  Kommivoyajor.addRoad('Voronej','Rostov',600);
  Kommivoyajor.addRoad('Voronej','Yaroslavl',500);
  Kommivoyajor.addRoad('Voronej','Novgorod',400);
  Kommivoyajor.addRoad('Novgorod','Voronej',400);
  Kommivoyajor.addRoad('Novgorod','Yaroslavl',40);
  Kommivoyajor.addRoad('Novgorod','Rostov',50);
  Kommivoyajor.addRoad('Rostov','Yaroslavl',340);
  Kommivoyajor.addRoad('Rostov','Voronej',600);
  Kommivoyajor.addRoad('Rostov','Novgorod',50);
  Kommivoyajor.addRoad('Yaroslavl','Rostov',340);
  Kommivoyajor.addRoad('Yaroslavl','Voronej',500);
  Kommivoyajor.addRoad('Yaroslavl','Novgorod',40);
 
end;