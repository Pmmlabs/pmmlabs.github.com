﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace os1
{
    class Program
    {
        public static Semaphore writeSem;
        public static Semaphore readSem;
        public static Mutex mut; 
        public const int n = 10; // Размер буфера
        static Queue<int> buffer = new Queue<int>(); // буфер-очередь
        static void Main(string[] args)
        {
            writeSem = new Semaphore(n, n);
            readSem = new Semaphore(0, n);
            Random r = new Random();
            int randomInt;
            int number = 1; // порядковый номер текущего потока
            mut = new Mutex();
            while (true)
                {
                    randomInt = r.Next(500, 2000);
                    Thread.Sleep(randomInt);
                    /* Типы потоков:
                     * true = поставщик
                     * false = потребитель
                     */
                    MutexThread s = new MutexThread(number, (r.Next(2) == 0), buffer);
                    number++;
                }
        }
    }
}
