﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace os1
{
    class MutexThread
    {
        bool supplier;
      
        Queue<int> buffer;
        Random r = new Random();
        public MutexThread(int _num, bool type, Queue<int> _buffer)
        {
            supplier = type;
            buffer = _buffer;
            /* Типы потоков:
             * true = поставщик
             * false = потребитель
             */
            Console.WriteLine("[C] " + "Создан " + (supplier ? "поставщик " : "потребитель ") + _num.ToString());
            Thread thr = new Thread(new ThreadStart(f));
            thr.Name = _num.ToString();
            thr.Start();
        }
        void f()
        {
            Thread.Sleep(r.Next(2000));
            Console.WriteLine("[W] " + (supplier ? "Поставщик" : "Потребитель") + " {0} ждет семафор.", Thread.CurrentThread.Name);
            if (supplier) Program.writeSem.WaitOne();
            else Program.readSem.WaitOne();
            Console.WriteLine("[W] " + (supplier ? "Поставщик" : "Потребитель") + " {0} ждет мьютекс.", Thread.CurrentThread.Name);
            Program.mut.WaitOne();
            Console.WriteLine("[B] " + (supplier ? "Поставщик" : "Потребитель") + " {0} начинает " + (supplier ? "запись" : "удаление"), Thread.CurrentThread.Name);
            if (supplier)
            {
                buffer.Enqueue(Int32.Parse(Thread.CurrentThread.Name)); // запись в буфер
                Program.readSem.Release();
            }
            else
            {
                buffer.Dequeue();
                Program.writeSem.Release();
            }
            foreach (Object obj in buffer) // печать буфера
                Console.Write("{0} <- ", obj);
            Console.WriteLine();
            Console.WriteLine("[R] " + (supplier ? "Поставщик" : "Потребитель") + " {0} возвращает мьютекс", Thread.CurrentThread.Name);
            Program.mut.ReleaseMutex();
        }
    }
}
