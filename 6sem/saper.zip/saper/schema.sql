-- ������
CREATE TABLE saper_players(id integer primary key, name varchar(15));
-- ������
CREATE TABLE saper_levels(id int primary key, name varchar(15), height integer, width integer, mines integer);
-- ������
CREATE TABLE saper_cells(id integer primary key, x integer, y integer, game_id integer, near integer, mine integer, state integer);
-- ����
CREATE TABLE saper_games(id integer primary key, level_id integer, player_id integer, dat date);
-- ������
create sequence SAPER_PLAYERS_SEQ
minvalue 1
maxvalue 99
start with 1
increment by 1
cache 10;
-- ������ 
create sequence saper_levels_seq
minvalue 1
maxvalue 99
start with 1
increment by 1
cache 10;
-- ����
create sequence saper_games_seq
minvalue 1
maxvalue 99
start with 1
increment by 1
cache 10;
-- ������
create sequence saper_cells_seq
minvalue 1
maxvalue 990
start with 1
increment by 1
cache 10;
