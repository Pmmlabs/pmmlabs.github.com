﻿BEGIN
saper.add_level('Newby',10,10,10);
saper.add_player('Alex');
saper.add_game('Newby','Alex');
saper.look(2,2,3);
END;