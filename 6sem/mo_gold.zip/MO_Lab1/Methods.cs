﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MO_Lab1
{
    class Methods
    {
        public static double GoldenSection(double a, double b, double eps, Func<double, double> func)
        {
            double gs = (Math.Sqrt(5) - 1) / 2;
            double ak = a;
            double bk = b;

            double u1 = ak + (1 - gs) * (bk - ak);
            double u2 = ak + gs * (bk - ak);

            double i1 = func(u1);
            double i2 = func(u2);

            while (bk - ak >= eps)
            {
                if (i1 <= i2)
                {
                    bk = u2;
                    u2 = u1;
                    u1 = ak + (1 - gs) * (bk - ak);
                    i2 = i1;
                    i1 = func(u1);
                }
                else
                {
                    ak = u1;
                    u1 = u2;
                    u2 = ak + gs * (bk - ak);
                    i1 = i2;
                    i2 = func(u2);
                }
            }
        return (ak + bk) / 2;
        }

        public static double SampleFunction(double x)
        {
            return 6 *x * x + 9 * x + 10;
        }
    }
}
