﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MO_Lab4
{
    public partial class mainForm : Form
    {    
        public mainForm()
        {
            InitializeComponent();
            Application.Idle += onIdle;
        }

        void onIdle(object sender, EventArgs e)
        {
            btPerform.Enabled = tbEps.Text.All(x => Char.IsDigit(x) || x == CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator[0]);
        }

        private void btPerform_Click(object sender, EventArgs e)
        {
            Vector<double> x0 = Methods.GradientMethod(Convert.ToDouble(tbEps.Text), Methods.SampleFunction, Methods.dx1, Methods.dx2);
            lbRes.Text = "Точка минимума: " + x0.ToString("F3");
        }
    }
}
