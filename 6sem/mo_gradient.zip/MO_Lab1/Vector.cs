﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MO_Lab4
{

    class Vector<T> : IEnumerable<T>
    {
        /// <summary>
        /// размер вектора
        /// </summary>
        public int size { get; private set; }

        /// <summary>
        /// массив компонент вектора
        /// </summary>
        public T[] cells { get; private set; }

        /// <summary>
        /// тип делегата нормы вектора
        /// </summary>
        public delegate T Norm<T>(Vector<T> vector);

        /// <summary>
        /// делегат нормы вектора
        /// </summary>
        public Norm<T> norm { get; set; }

        /// <summary>
        /// автоматически сгенерированный энумератор для вектора
        /// </summary>
        /// <returns></returns>
        public IEnumerator<T> GetEnumerator()
        {
            return ((IEnumerable<T>)cells).GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return ((IEnumerable<T>)cells).GetEnumerator();
        }

        /// <summary>
        /// выделение памяти под size компонент
        /// </summary>
        /// <param name="size">размер аллоцируемой памяти</param>
        private void AllocateCells(int size)
        {
            cells = new T[size];
            this.size = size;
        }

        /// <summary>
        /// очистка вектора
        /// </summary>
        public void Clear()
        {
            cells = null;
            size = 0;
        }

        /// <summary>
        /// норма по умолчанию - корень из суммы квадратов координат
        /// </summary>
        public static T MaxElem<T>(Vector<T> vector)
        {
            T res = default(T);
            foreach(T cell in vector)
            {
                res += (dynamic)cell * cell;
            }
            return Math.Sqrt((dynamic)res);
        }

        /// <summary>
        /// норма этого вектора
        /// </summary>
        /// <returns>норма</returns>
        public T VectorNorm()
        {
            return norm(this);
        }

        /// <summary>
        /// конструктор
        /// </summary>
        /// <param name="p">компоненты</param>
        public Vector(params T[] p) : this(MaxElem, p) { }

        public Vector(Norm<T> norm, params T[] p)
        {
            this.norm = norm;
            size = p.Count();
            cells = new T[size];
            for(int i = 0; i < size; ++i)
            {
                cells[i] = p[i];
            }
        }
        /// <summary>
        /// конструктор
        /// </summary>
        /// <param name="size">размер</param>
        /// <param name="source">контейнер-источник</param>
        public Vector(int size, IEnumerable<T> source = null) : this(size, MaxElem, source) { }

        public Vector(int size, Norm<T> norm, IEnumerable<T> source = null)
        {
            AllocateCells(size);
            int i = 0;
            this.norm = norm;
            if (source != null)
            {
                foreach (T elem in source)
                {
                    if (i < size)
                    {
                        cells[i] = elem;
                    }
                    else
                    {
                        break;
                    }
                    ++i;
                }
            }
        }

        /// <summary>
        /// конструктор для задания случайного вектора
        /// </summary>
        /// <param name="size">размер</param>
        /// <param name="minValue">минимальное значение</param>
        /// <param name="maxValue">максимальное значение</param>
        /// <param name="rd">генератор случайных значений</param>
        public Vector(int size, int minValue, int maxValue, Random rd) : this(size, MaxElem, minValue, maxValue, rd) { }

        public Vector(int size, Norm<T> norm, int minValue, int maxValue, Random rd)
        {
            this.norm = norm;
            AllocateCells(size);
            for(int i = 1; i <= size; ++i)
            {
                this[i] = (T)(dynamic)(rd.NextDouble() * (maxValue - minValue) + minValue);
            }
        }
        
        /// <summary>
        /// индексатор (нумерация с единицы)
        /// </summary>
        /// <param name="index">индекс</param>
        /// <returns>компонента вектора</returns>
        public T this[int index] { get { return cells[index - 1]; } set { cells[index - 1] = value; } }

        public static Vector<T> operator+ (Vector<T> v1, Vector<T> v2)
        {
            if(v1.size != v2.size)
            {
                throw new ArgumentException("Size mismatch");
            }
            else
            {
                Vector<T> res = new Vector<T>(v1.size);
                for(int i = 1; i <= v1.size; ++i)
                {
                    res[i] = (dynamic)v1[i] + (dynamic)v2[i];
                }
                return res;
            }
        }

        public static Vector<T> operator- (Vector<T> v1, Vector<T> v2)
        {
            if (v1.size != v2.size)
            {
                throw new ArgumentException("Size mismatch");
            }
            else
            {
                Vector<T> res = new Vector<T>(v1.size);
                for (int i = 1; i <= v1.size; ++i)
                {
                    res[i] = (dynamic)v1[i] - (dynamic)v2[i];
                }
                return res;
            }
        }

        public static Vector<T> operator- (Vector<T> v)
        {
            Vector<T> res = new Vector<T>(v.size);
            for(int i = 1; i <= v.size; ++i) 
            {
                res[i] = -(dynamic)v[i];
            }
            return res;
        }

        public static T operator *(Vector<T> v1, Vector<T> v2)
        {
            if (v1.size != v2.size)
            {
                throw new ArgumentException("Size mismatch");
            }
            else
            {
                T res = default(T);
                for (int i = 1; i <= v1.size; ++i)
                {
                    res += (dynamic)v1[i] * (dynamic)v2[i];
                }
                return res;
            }
        }

        public static Vector<T> operator *(T a, Vector<T> v)
        {
            Vector<T> res = new Vector<T>(v.size);
            for (int i = 1; i <= v.size; ++i)
            {
                res[i] = a * (dynamic)v[i];
            }
            return res;
        }

        public Vector<T> PerformFuncs(Vector<Func<Vector<T>, T>> funcs)
        {
            if (size != funcs.size)
            {
                throw new ArgumentException("Size mismatch");
            }
            else
            {
                Vector<T> res = new Vector<T>(size);
                for (int i = 1; i <= size; ++i)
                {
                    res[i] = funcs[i](this);
                }
                return res;
            }
        }
        public override string ToString()
        {
            string res = "(";
            for(int i = 1; i < size; ++i)
            {
                res += this[i].ToString() + "; ";
            }
            res += this[size].ToString() + ")";
            return res;
        }

        public string ToString(string format)
        {
            string res = "(";
            for (int i = 1; i < size; ++i)
            {
                res += ((dynamic)this[i]).ToString(format) + "; ";
            }
            res += ((dynamic)this[size]).ToString(format) + ")";
            return res;
        }

    }
}
