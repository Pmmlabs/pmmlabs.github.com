﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MO_Lab4
{
    class Methods
    {
        public static Vector<double> GradientMethod(double eps, Func<Vector<double>, double> func, params Func<Vector<double>, double>[] dX)
        {
            Vector<Func<Vector<double>, double>> grad = new Vector<Func<Vector<double>, double>>(dX); //вектор частных производных (функций)
            Vector<double> xPrev; //предыдущее значение функции
            Vector<double> gradPrev; //предыдущее значение градиента
            Vector<double> xCurr = new Vector<double>(dX.Count()); //текущее значение функции 
            Vector<double> gradCurr = xCurr.PerformFuncs(grad); //текущее значение градиента
            double h = eps * 100; //коэффициент шага
            do
            {
                xPrev = xCurr; 
                gradPrev = gradCurr;
                xCurr = xPrev - h * gradPrev;
                gradCurr = xCurr.PerformFuncs(grad);
                if(func(xCurr) > func(xPrev))
                {
                    h /= 2;
                }
            } while (Math.Abs((gradCurr - gradPrev).VectorNorm()) > eps); // Критерий остановки
            return xCurr;

        }

        public static double SampleFunction(Vector<double> x)
        {
            return Math.Pow(x[1], 4) + Math.Pow(x[2], 4) + Math.Pow(x[1], 3) * x[2] - 7 * x[1] + 9 * x[2] + 2;
        }

        public static double dx1(Vector<double> x)
        {
            return 4 * Math.Pow(x[1], 3) + 3 * Math.Pow(x[1], 2) * x[2] - 7;
        }

        public static double dx2(Vector<double> x)
        {
            return Math.Pow(x[1], 3) + 4 * Math.Pow(x[2], 3) + 9;
        }
    }
}
