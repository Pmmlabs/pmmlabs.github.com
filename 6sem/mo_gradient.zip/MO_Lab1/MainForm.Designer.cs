﻿namespace MO_Lab4
{
    partial class mainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.btPerform = new System.Windows.Forms.Button();
            this.lbEps = new System.Windows.Forms.Label();
            this.tbEps = new System.Windows.Forms.TextBox();
            this.lbRes = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btPerform
            // 
            this.btPerform.Location = new System.Drawing.Point(245, 5);
            this.btPerform.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btPerform.Name = "btPerform";
            this.btPerform.Size = new System.Drawing.Size(100, 28);
            this.btPerform.TabIndex = 1;
            this.btPerform.Text = "Найти";
            this.btPerform.UseVisualStyleBackColor = true;
            this.btPerform.Click += new System.EventHandler(this.btPerform_Click);
            // 
            // lbEps
            // 
            this.lbEps.AutoSize = true;
            this.lbEps.Location = new System.Drawing.Point(16, 11);
            this.lbEps.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbEps.Name = "lbEps";
            this.lbEps.Size = new System.Drawing.Size(78, 17);
            this.lbEps.TabIndex = 2;
            this.lbEps.Text = "Точность: ";
            // 
            // tbEps
            // 
            this.tbEps.Location = new System.Drawing.Point(104, 7);
            this.tbEps.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbEps.Name = "tbEps";
            this.tbEps.Size = new System.Drawing.Size(132, 22);
            this.tbEps.TabIndex = 3;
            this.tbEps.Text = "0,001";
            // 
            // lbRes
            // 
            this.lbRes.AutoSize = true;
            this.lbRes.Location = new System.Drawing.Point(16, 37);
            this.lbRes.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbRes.Name = "lbRes";
            this.lbRes.Size = new System.Drawing.Size(126, 17);
            this.lbRes.TabIndex = 4;
            this.lbRes.Text = "Точка минимума: ";
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(375, 73);
            this.Controls.Add(this.lbRes);
            this.Controls.Add(this.tbEps);
            this.Controls.Add(this.lbEps);
            this.Controls.Add(this.btPerform);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "mainForm";
            this.Text = "Lab4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btPerform;
        private System.Windows.Forms.Label lbEps;
        private System.Windows.Forms.TextBox tbEps;
        private System.Windows.Forms.Label lbRes;
    }
}

