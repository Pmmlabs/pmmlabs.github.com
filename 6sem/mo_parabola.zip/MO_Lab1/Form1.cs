﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MO_Lab1
{
    public partial class mainForm : Form
    {
        public mainForm()
        {
            InitializeComponent();
            funcChart.Series.Add("min point");
            funcChart.Series[0].Name = "Plot";
            funcChart.Series[1].ToolTip = "X = #VALX, Y = #VALY";
        }

        private void btPerform_Click(object sender, EventArgs e)
        {
            funcChart.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            for(double i = -2; i < 2; i += 1.0E-2)
            {
                funcChart.Series[0].Points.AddXY(i, Methods.SampleFunction(i));
            }
            double x = Methods.ParabolMethod(-2, 2, 1.0E-2, Methods.SampleFunction);            
            funcChart.Series[1].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            funcChart.Series[1].Color = Color.Red;
            funcChart.Series[1].Points.AddXY(Math.Round(x, 4), Math.Round(Methods.SampleFunction(x), 4));

        }
    }
}
