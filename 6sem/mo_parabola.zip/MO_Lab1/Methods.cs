﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MO_Lab1
{
    class Methods
    {
        private static double N = 100;
        public static double ParabolMethod(double a, double b, double eps, Func<double, double> func)
        {
            double u0 = (a + b ) / 2;    // начальная точка
            double h = (b - a) / N;      // шаг
            double i0;                   // значение фун в начальное точке
            double u1, u2;               // 2 и 3 точки
            double i1, i2;               // значение фун в 2, 3 точке
            double w = double.NaN;       // точка min параболы
            double w_pred = double.NaN;  // предыдущая  точка min параболы

            
            while (!(Math.Abs(w - w_pred) < eps))
            {
                i0 = func(u0);
                u1 = u0 + h;
                i1 = func(u1);
                if (i1 < i0)
                {
                    u2 = u1 + h;
                }
                else
                {
                    u1 = u0 - h;
                    i1 = func(u1);
                    u2 = u1 - h;
                }
                i2 = func(u2);
                w_pred = w;
                w = -0.5 * ((i1 - i0) * Math.Pow(u2, 2) + (i0 - i2) * Math.Pow(u1, 2) + (i2 - i1) * Math.Pow(u0, 2)) / 
                           ((i0 - i1) * u2 + (i2 - i0) * u1 + (i1 - i2) * u0);
                u0 = w;
            }

            return w;

        }

        public static double SampleFunction(double x)
        {
            return Math.Pow(x, 6) + 2 * x + 10;
        }
    }
}
