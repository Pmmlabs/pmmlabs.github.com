package RSSDB;

import java.io.*;
import java.sql.*;
import java.text.*;
import java.util.*;
import java.lang.*;

public class DBConnection {
    
    private static String urlMySQL = "jdbc:mysql://localhost/rss";
    private static String driverMySQL = "com.mysql.jdbc.Driver";
    private static String urlLinter = "jdbc:linter:linapid:localhost:1070";
    private static String driverLinter = "com.relx.jdbc.LinterDriver";

    private static Connection dbConnection = null;

    public DBConnection ()
    {
    }  
    
    public Connection getConnectionMySql(String name, String password) {
    try {
          if (dbConnection == null) {
            Class.forName(driverMySQL); //.newInstance();
            System.out.println("Driver found. Now connecting to database ... ");
            Properties props = new Properties();
            props.put( "user", name );
            props.put( "password", password );
            props.put( "encoding", "Cp1251");


            Connection connection = DriverManager.getConnection(urlMySQL, props);
            System.out.println(" Connection established ... ");
            dbConnection = connection;
          }
      }
      catch (Exception ex) { 
        System.out.println("Catch :" + ex + "mes = " + ex.getMessage());
        ex.printStackTrace();
      }
      return dbConnection;
      } 
}
