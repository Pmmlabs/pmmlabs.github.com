/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RSSModel;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Павел
 */
public class FeedMessage {           
       
    Integer id;
    Integer feed_id;
    String title;
    String description;
    String link;
    String author;
    String guid;
    Date pubdate;
    
    static DateFormat formatDB = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH); //YYYY-MM-DD HH:MM:SS
    DateFormat formatRSS = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss Z", Locale.ENGLISH); //Fri, 10 May 2013 00:38:19 +0400
    
    public Integer getID(){
        return id;
    }
    
    public void setID(Integer id){
        this.id = id;
    }
    
    public Integer getFeedID(){
        return feed_id;
    }
    
    public void setFeedID(Integer id){
        this.feed_id = id;
    }
    
    public String getTitle(){
        return title;
    }
    
    public void setTitle(String aTitle){
        this.title = aTitle;
    }
    
    public String getDescription(){
        return description;
    }
    
    public void setDescription(String aDescription){
        this.description = aDescription;
    }
    
    public String getLink(){
        return link;
    }
    
    public void setLink(String aLink){
        this.link = aLink;
    }
    
    public String getAuthor(){
        return author;
    }
    
    public void setAuthor(String aAuthor){
        this.author = aAuthor;
    }
    
    public String getGuid(){
        return guid;
    }
    
    public void setGuid(String aGuid){
        this.guid = aGuid;
    }
    
    public Date getPubDate(){
        return pubdate;
    }
    
    public void setPubDate(String aPubDate){
        try {
            this.pubdate = formatRSS.parse(aPubDate);
        } catch (ParseException ex) {
            Logger.getLogger(FeedMessage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    public void setPubDate(Date aPubDate){
        this.pubdate = aPubDate;
    }
    
    @Override
    public String toString(){
        return "FeedMessage [title=" + title + ", description=" + description
                + ", link=" + link + ", author=" + author + ", guid=" + guid
                + ", pubDate=" + pubdate + "]";
    }
    
    public void Save(Connection dbCon, Integer feed_id){
        if (feed_id < 0) return;
        
        Statement stmt = null;
        try {
            StringBuilder str = new StringBuilder();
            
            str.append("INSERT INTO `message` (`feed_id`, `link`, `title`, `description`, `author`, `guid`, `date`) VALUES ");
            
            str.append("(")
               .append("").append(feed_id).append(",")     
               .append("'").append(link).append("',")
               .append("'").append(title).append("',")
               .append("'").append(description.replace("'", "''")).append("',")
               .append("'").append(author).append("',")
               .append("'").append(guid).append("',")
               .append("'").append(formatDB.format(pubdate)).append("'")
               .append(");");
            
            stmt = dbCon.createStatement();
            stmt.executeUpdate(str.toString());
        }
        catch(Exception ex){            
        }
        
        try {
            stmt.close();
        }
        catch(Exception ex) {
        }
        
    }
}
