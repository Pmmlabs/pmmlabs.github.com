/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package RSSModel.View;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Павел
 */
public class FeedMessageView {
     
    String feed_title;
    String feed_link;
    String title;
    String description;
    String link;
    String author;
    String guid;
    Date pubdate;
    
    static DateFormat formatDB = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH); //YYYY-MM-DD HH:MM:SS
    DateFormat formatRSS = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss Z", Locale.ENGLISH); //Fri, 10 May 2013 00:38:19 +0400
    
    public String getFeedTitle(){
        return feed_title;
    }
    
    public void setFeedTitle(String feed_title){
        this.feed_title = feed_title;
    }
    
    public String getFeedLink(){
        return feed_link;
    }
    
    public void setFeedLink(String feed_link){
        this.feed_link = feed_link;
    }
    
    public String getTitle(){
        return title;
    }
    
    public void setTitle(String aTitle){
        this.title = aTitle;
    }
    
    public String getDescription(){
        return description;
    }
    
    public void setDescription(String aDescription){
        this.description = aDescription;
    }
    
    public String getLink(){
        return link;
    }
    
    public void setLink(String aLink){
        this.link = aLink;
    }
    
    public String getAuthor(){
        return author;
    }
    
    public void setAuthor(String aAuthor){
        this.author = aAuthor;
    }
    
    public String getGuid(){
        return guid;
    }
    
    public void setGuid(String aGuid){
        this.guid = aGuid;
    }
    
    public Date getPubDate(){
        return pubdate;
    }
    
    public String getPubDate(SimpleDateFormat sformat){
        return sformat.format(pubdate);
    }
    
    public void setPubDate(String aPubDate){
        try {
            this.pubdate = formatRSS.parse(aPubDate);
        } catch (ParseException ex) {
            Logger.getLogger(FeedMessageView.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    public void setPubDate(Date aPubDate){
        this.pubdate = aPubDate;
    }
    
    
    @Override
    public String toString(){
        return "FeedMessage [title=" + title + ", description=" + description
                + ", link=" + link + ", author=" + author + ", guid=" + guid
                + ", pubDate=" + pubdate + "]";
    }
    
    public static ArrayList<FeedMessageView> GetListOfFeeds(Connection dbCon, int count, int feed_id){
        Statement stmt = null;
        
        ArrayList<FeedMessageView> lst = new ArrayList<>();     
        
        try{
            StringBuilder str = new StringBuilder();
            
            str
               .append("SELECT DISTINCT ")
                    .append("f.`link` as feed_link, ")
                    .append("f.`title` as feed_title, ")
                    .append("m.`link` as link, ")
                    .append("m.`title` as title, ")
                    .append("m.`description` as description, ")
                    .append("`author`, ")
                    .append("`guid`, ")
                    .append("`date` ")
                    .append("FROM `message` as m ")
                    .append("join `feed` as f on m.`feed_id` = f.`id` ")
                    .append("WHERE ").append(feed_id).append(" < 0 OR feed_id = ").append(feed_id).append(" ")
                    .append("ORDER BY `date` DESC ")
                    .append("LIMIT ").append(count).append(";");
                    
            stmt = dbCon.createStatement();
            ResultSet rs = stmt.executeQuery(str.toString());
            while (rs.next()) {
                FeedMessageView msg = new FeedMessageView();
                msg.setFeedTitle(rs.getString("feed_title"));
                msg.setFeedLink(rs.getString("feed_link"));
                msg.setTitle(rs.getString("title"));
                msg.setDescription(rs.getString("description"));
                msg.setLink(rs.getString("link"));
                msg.setAuthor(rs.getString("author"));
                msg.setGuid(rs.getString("guid"));
                msg.setPubDate(formatDB.parse(rs.getString("date")));
                
                lst.add(msg);
            }
        }
        catch(Exception ex){            
        }
        
        try {
            stmt.close();
        }
        catch(Exception ex) {
        }
        
        return lst;
    }
}