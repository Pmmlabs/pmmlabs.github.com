/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RSSModel.View;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Павел
 */
public class FeedView {
    
    Integer id;
    String title;
    String rss;
    
    public String getTitle(){
        return title;
    }
    
    public void setTitle(String aTitle){
        this.title = aTitle;
    }
    
    public String getRSS(){
        return rss;
    }
    
    public void setRSS(String aLink){
        this.rss = aLink;
    }
    
    public Integer getID(){
        return id;
    }
    
    public void setID(Integer aID){
        this.id = aID;
    }
    
    public static ArrayList<FeedView> GetFeeds(Connection dbCon){
        Statement stmt = null;
        ArrayList<FeedView> lst = new ArrayList<>();
        
        try{
            StringBuilder str = new StringBuilder();
            
            str.append("SELECT `id`, `title`, `rss` FROM feed;");

            stmt = dbCon.createStatement();
            ResultSet rs = stmt.executeQuery(str.toString());
            while (rs.next()){
                FeedView fd = new FeedView();
                fd.setTitle(rs.getString("title"));
                fd.setRSS(rs.getString("rss"));
                fd.setID(rs.getInt("id"));
                lst.add(fd);
            }
        }
        catch(Exception ex){            
        }
        
        return lst;
    }
}
