/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RSSModel;

/*Tomcat-apache,JSP, MySQL - создание обощщенной новостной ленты с использованием канала RSS.
Задаются сайты на которых присутствует RSS, необходимо вывести 1 страницу с
перечислением где и какая новость опубликована.*/

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.HttpURLConnection;
import java.sql.Connection;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 *
 * @author Павел
 */
public class RSSFeedParser {
    
    static final String TITLE = "title";
    static final String DESCRIPTION = "description";
    static final String CHANNEL = "channel";
    static final String LANGUAGE = "language";
    static final String COPYRIGHT = "copyright";
    static final String LINK = "link";
    static final String AUTHOR = "author";
    static final String ITEM = "item";
    static final String PUB_DATE = "pubDate";
    static final String GUID = "guid";
    
    final URL url;
    
    public RSSFeedParser(String feedUrl){
        try {
            this.url = new URL(feedUrl);
        }
        catch (MalformedURLException e){
            throw new RuntimeException(e);
        }
    }
    
    public void ParseRSS(Connection dbCon, Integer feed_id){
        Feed feed = readFeed();
        ArrayList<FeedMessage> messages = readFeedMessages();
        
        //int feed_id = -1;
        if (feed != null){
            feed.Save(dbCon, feed_id);
        }
        if (feed_id > 0 && messages != null){
            Feed.DeleteMessages(dbCon, feed_id);
            for (FeedMessage message: messages){
                message.Save(dbCon, feed_id);
            }                   
        } 
    }
    
    public ArrayList<FeedMessage> readFeedMessages(){
        ArrayList<FeedMessage> msg = new ArrayList<>();
        
        try{
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                InputStream is = conn.getInputStream();

                //DocumentBuilderFactory, DocumentBuilder are used for
                //xml parsing
                DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                DocumentBuilder db = dbf.newDocumentBuilder();

                //using db (Document Builder) parse xml data and assign
                //it to Element
                Document document = db.parse(is);
                Element element = document.getDocumentElement();

                //take rss nodes to NodeList
                NodeList nodeList = element.getElementsByTagName(ITEM);
                
                if (nodeList.getLength() > 0) {
                    for (int i = 0; i < nodeList.getLength(); i++) {

                        //take each entry (corresponds to <item></item> tags in
                        //xml data

                        Element entry = (Element) nodeList.item(i);

                        Element _titleE = (Element) entry.getElementsByTagName(TITLE).item(0);
                        Element _descriptionE = (Element) entry.getElementsByTagName(DESCRIPTION).item(0);
                        Element _pubDateE = (Element) entry.getElementsByTagName(PUB_DATE).item(0);
                        Element _linkE = (Element) entry.getElementsByTagName(LINK).item(0);

                        FeedMessage rssItem = new FeedMessage();
                        
                        rssItem.setTitle(_titleE.getFirstChild().getNodeValue());
                        rssItem.setDescription(_descriptionE.getFirstChild().getNodeValue());
                        rssItem.setPubDate(_pubDateE.getFirstChild().getNodeValue());
                        rssItem.setLink(_linkE.getFirstChild().getNodeValue());

                        msg.add(rssItem);
                    }
                }
            }
        }
        catch (Exception e) {
            msg = null;
        }
        
        return msg;
    }
    
    public Feed readFeed(){
        Feed feed = new Feed();
        
        try{
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                InputStream is = conn.getInputStream();

                //DocumentBuilderFactory, DocumentBuilder are used for
                //xml parsing
                DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                DocumentBuilder db = dbf.newDocumentBuilder();

                //using db (Document Builder) parse xml data and assign
                //it to Element
                Document document = db.parse(is);
                Element element = document.getDocumentElement();

                //take rss nodes to NodeList
                NodeList nodeList = element.getElementsByTagName(CHANNEL);
                
                if (nodeList.getLength() > 0) {
                    for (int i = 0; i < nodeList.getLength(); i++) {

                        //take each entry (corresponds to <item></item> tags in
                        //xml data
                        Element entry = (Element) nodeList.item(i);

                        Element _titleE = (Element) entry.getElementsByTagName(TITLE).item(0);
                        Element _descriptionE = (Element) entry.getElementsByTagName(DESCRIPTION).item(0);
                        Element _linkE = (Element) entry.getElementsByTagName(LINK).item(0);
                        
                        Element _languageE = (Element) entry.getElementsByTagName(LANGUAGE).item(0);
                        Element _copyrightE = (Element) entry.getElementsByTagName(COPYRIGHT).item(0);
                        
                        feed.setTitle(_titleE.getFirstChild().getNodeValue());
                        feed.setDescription(_descriptionE.getFirstChild().getNodeValue());
                        feed.setLink(_linkE.getFirstChild().getNodeValue());
                        try{
                            feed.setLanguage(_languageE.getFirstChild().getNodeValue());
                        }
                        catch (Exception ex){
                        }
                        try{
                            feed.setCopyright(_copyrightE.getFirstChild().getNodeValue());
                        }
                        catch (Exception ex){
                        }
                        
                    }
                }
            }
        }
        catch (Exception e) {
            feed = null;
        }
        
        return feed;
    }   
    
}
