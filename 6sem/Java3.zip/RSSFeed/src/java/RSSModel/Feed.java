/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RSSModel;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Павел
 */
public class Feed {
    
    String title;
    String link;
    String description;
    String language;
    String copyright;
    // final String pubDate;
    
    final List<FeedMessage> entries = new ArrayList<FeedMessage>();
    
    public Feed(String aTitle,String aLink,String aDescription,String aLanguage,
            String aCopyright){
        this.title = aTitle;
        this.link = aLink;
        this.description = aDescription;
        this.language = aLanguage;
        this.copyright = aCopyright;
    }
    
    public Feed(){
        this.title = "";
        this.link = "";
        this.description = "";
        this.language = "";
        this.copyright = "";
    }
    
    public List<FeedMessage> getMessage(){
        return entries;
    }
    
    public String getTitle(){
        return title;
    }
    
    public void setTitle(String aTitle){
        this.title = aTitle;
    }
    
    public String getLink(){
        return link;
    }
    
    public void setLink(String aLink){
        this.link = aLink;
    }
    
    public String getDescription(){
        return description;
    }
    
    public void setDescription(String aDes){
        this.description = aDes;
    }
    
    public String getLanguage(){
        return language;
    }
    
    public void setLanguage(String aLan){
        this.language = aLan;
    }
    
    public String getCopyright(){
        return copyright;
    }
    
    public void setCopyright(String aCopyright){
        this.copyright = aCopyright;
    }
    
    @Override
    public String toString(){
        return "Feed [copyright=" + copyright + ", description=" + description
                + ", language=" + language + ", link=" + link + ", title=" + title + "]";
    }
    
    public void Save(Connection dbCon, Integer id){

        Statement stmt = null;
        try {
            StringBuilder str = new StringBuilder();
            
            str
               .append("UPDATE `feed` SET ")
               .append("`link` = ").append("'").append(link).append("',")
               .append("`title` = ").append("'").append(title).append("',")
               .append("`description` = ").append("'").append(description).append("',")
               .append("`language` = ").append("'").append(language).append("',")
               .append("`copyright` = ").append("'").append(copyright).append("'")
               .append(" WHERE `id` = ").append("'").append(id).append("'");
            
            stmt = dbCon.createStatement();
            stmt.executeUpdate(str.toString());
        }
        catch(Exception ex){            
        }
        
        try {
            stmt.close();
        }
        catch(Exception ex) {
        }
        
    }
    
    public static void DeleteMessages(Connection dbCon, Integer feed_id){
        Statement stmt = null;
        try {
            StringBuilder str = new StringBuilder();
            
            str
               .append("DELETE FROM `message` WHERE `feed_id` = ").append(feed_id);
            
            stmt = dbCon.createStatement();
            stmt.executeUpdate(str.toString());
        }
        catch(Exception ex){            
        }
        
        try {
            stmt.close();
        }
        catch(Exception ex) {
        }
    }
            
}
