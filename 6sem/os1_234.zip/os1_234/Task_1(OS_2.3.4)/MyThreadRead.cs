﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Task_1_OS_2._3._4_
{
    class MyThreadRead
    {
        Queue<int> buffer;
        Random r = new Random();
        private int _actionCount = 3;

        public MyThreadRead(int _num, Queue<int> _buffer)
        {
            buffer = _buffer;

            Console.WriteLine("[Create] Создан потребитель " + _num.ToString());
            Thread thr = new Thread(new ThreadStart(monitor));
            thr.Name = _num.ToString();
            thr.Start();
        }

        public int getActionCount()//читает значение счетчика
        {
            return _actionCount;
        }

        public void setActionCount(int value)//устанавливает счетчик
        {
            _actionCount = value;
        }

        void monitor()
        {
            int actionCount = 0;

            while (actionCount != _actionCount)
            {

                Console.WriteLine("[Lock] Потребитель " + Thread.CurrentThread.Name.ToString() + " ставит блокировку.");
                System.Threading.Monitor.Enter(buffer); // Ставим блокировку.

                try
                {
                    Console.WriteLine("[Read] Потребитель " + Thread.CurrentThread.Name.ToString() + " читает.");
                    if (buffer.Count > 0)
                    {
                        int numb = buffer.Dequeue(); // Чтение из буфера. 
                        Console.WriteLine("[Read] Потребитель " + Thread.CurrentThread.Name.ToString() + " прочитал из буфера: " + numb.ToString());
                    }
                    else
                        Console.WriteLine("[Read] Потребитель " + Thread.CurrentThread.Name.ToString() + " не можете прочитать из буфера. Буфер пуст.");

                }
                finally
                {
                    Console.WriteLine("[Unlock] Потребитель " + Thread.CurrentThread.Name.ToString() + " снимает блокировку.");
                    System.Threading.Monitor.Exit(buffer); // Снимаем блокировку.
                }


                string cb = ""; // Содержимое буфера

                foreach (Object obj in buffer) // Печать содержимого буфера в строку.
                    cb = cb + " " + obj.ToString();
                if (cb != "")
                    Console.WriteLine("[Buffer] Содержимое буфера:" + cb); // Вывод на экран содержимого буфера
                else
                    Console.WriteLine("[Buffer] Содержимое буфера: Буфер пуст.");
                actionCount++;
            }
        }
    }
}
