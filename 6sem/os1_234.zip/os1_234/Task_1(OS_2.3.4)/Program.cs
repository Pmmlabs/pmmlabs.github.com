﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Task_1_OS_2._3._4_
{
    class Program
    {
        static Queue<int> buffer = new Queue<int>(); // Буфер-очередь.
        public static bool flag = true;

        static void Main(string[] args)
        {
            int n = 0;
            try
            {
                Console.Write("Введите кол-во операций для одного потока: ");
                n = Int32.Parse(Console.ReadLine());
                if (n <= 0)
                    throw new Exception("Установлено стандартное значение: 3.");
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Установлено стандартное значение: 3.");
            }

            Random rnd = new Random();
            int sleepTime = 0; // Время для задержки потока.
            int threadNumber = 1; // Порядковый номер текущего потока.
            ControlThread control = new ControlThread(ConsoleKey.Escape);
            

            while (flag)
            {
                sleepTime = rnd.Next(500, 2000);
                Thread.Sleep(sleepTime);
                if (rnd.Next(2) == 0)
                {
                    MyThreadWrite thread = new MyThreadWrite(threadNumber, buffer);
                    if (n > 0)
                        thread.setActionCount(n);
                    threadNumber++;
                }
                else
                {
                    MyThreadRead thread = new MyThreadRead(threadNumber, buffer);
                    if (n > 0)
                        thread.setActionCount(n);
                    threadNumber++;
                }

            }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Новые потоки не создаются.\nОжидание завершения работы потоков, созданных ранее.");
            Console.ResetColor();
            Thread.Sleep(20);
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("Для завершения приложения нажмите Enter.");
            Console.ReadLine();
        }
    }
}
