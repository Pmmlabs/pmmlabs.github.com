﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Task_1_OS_2._3._4_
{
    class MyThreadWrite
    {
          
        Queue<int> buffer;
        Random r = new Random();
        private int _actionCount = 3;

        public int getActionCount()
        {
            return _actionCount;
        }

        public void setActionCount(int value)
        {
            _actionCount = value;
        }

        public MyThreadWrite(int _num, Queue<int> _buffer)
        {            
            buffer = _buffer;
            Console.WriteLine("[Create] Создан поставщик " + _num.ToString());
            Thread thr = new Thread(new ThreadStart(monitor));
            thr.Name = _num.ToString();
            thr.Start();
        }

        void monitor()
        {
            int actionCount = 0;

            while (actionCount != _actionCount)
            {

                Console.WriteLine("[Lock] Поставщик " + Thread.CurrentThread.Name.ToString() + " ставит блокировку.");
                System.Threading.Monitor.Enter(buffer); // Ставим блокировку.
                
                try
                {
                    Console.WriteLine("[Write] Поставщик " + Thread.CurrentThread.Name.ToString() + " пишет.");

                    int numb = Int32.Parse(Thread.CurrentThread.Name);
                    buffer.Enqueue(numb); // Запись в буфер. 
                    Console.WriteLine("[Write] Поставщик " + Thread.CurrentThread.Name.ToString() + " записал в буфер: " + numb.ToString());
                }
                finally
                {
                    Console.WriteLine("[Unlock] Поставщик " + Thread.CurrentThread.Name.ToString() + " снимает блокировку.");
                    System.Threading.Monitor.Exit(buffer); // Снимаем блокировку.
                }


                string cb = ""; // Содержимое буфера

                foreach (Object obj in buffer) // Печать содержимого буфера в строку.
                    cb = cb + " " + obj.ToString();
                if (cb != "")
                    Console.WriteLine("[Buffer] Содержимое буфера:" + cb); // Вывод на экран содержимого буфера
                else
                    Console.WriteLine("[Buffer] Содержимое буфера: Буфер пуст.");
                actionCount++;
            }
        }
    }
}
