﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Task_1_OS_2._3._4_
{
    class ControlThread
    {
        private ConsoleKey ck;
        public ControlThread(ConsoleKey x)
        {
            ck = x;
            Thread thr = new Thread(new ThreadStart(ctrl));
            thr.Start();
        }

        void ctrl()
        {
            ConsoleKeyInfo key;
            while (true)
            {
                key = Console.ReadKey(true);

                if (key.Key == ck)
                {
                    Program.flag = false;
                    break;
                }
            }
        }
    }
}
