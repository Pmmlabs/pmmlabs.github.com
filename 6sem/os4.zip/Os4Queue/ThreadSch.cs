﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using QueueLibrary;

namespace Os4Queue
{
    class ThreadSch
    {
        private TextBox tbLog;
        private PriorityQueue<SThread> threadQueue;
        private int timeslice = 0;
        private int maxThreads = 0;//кол-во максимальных потоков
        public Thread scheduler = null;

        public ThreadSch(TextBox _tbLog)
        {
            threadQueue = new PriorityQueue<SThread>();
            tbLog = _tbLog;
            scheduler = new Thread(new ThreadStart(threadScheduler));//планировщик
            scheduler.Name = "sch";
        }

        public int MaxThreads
        {
            get { return maxThreads; }
            set { maxThreads = value; }
        }

        public int Timeslice
        {
            get { return timeslice; }
            set { timeslice = value; }
        }

        public void Start()//запускаем
        {
            scheduler.Start();
        }

        public void Resume()// перезапуск, если поток был приостановлен
        {
            scheduler.Resume();
        }

        public void Suspend()//приостанавливаем
        {
            scheduler.Suspend();
        }
        
        private void threadScheduler()//планировщик
        {
            Random r = new Random(0);
            int threadNumber = 1;
            int iterations = 0;
                        
            while (FormMain.flag)
            {
                iterations++;
                while (threadQueue.Count < maxThreads)
                {
                    SThread sThread = new SThread(threadNumber, tbLog, r.Next(100, 1000), r.Next(0, 5));//создаются потоки
                    threadQueue.Enqueue(sThread);//эти потоки добавляем в очередь
                    tbLog.Invoke(new Action<string>((lb) => tbLog.AppendText(lb)), "Создан поток " + threadNumber + " с приоритетом [" + sThread.Priority + "]\r\n");
                    threadNumber++;
                }
                if (threadQueue.Count > 0)
                {
                    var thread = threadQueue.Dequeue();// вытаскиваем поток из очереди

                    Monitor.Enter(thread);//блокируем поток
                    try
                    {
                        int workTime = thread.Worktime;//получаем время работы потока
                        thread.Resume();//запускаем поток
                        if (workTime < timeslice)//сравниваем время работы с квантом времени
                            thread.thread.Join();//блокируем вызывающий поток до завершения потока
                        else
                        {
                            Thread.Sleep(timeslice); 
                            thread.Suspend();//приостанавливаем поток
                        }
                        if (thread.Worktime > 0)
                            threadQueue.Enqueue(thread);//добавляем в очередь
                    }
                    finally
                    {
                        Monitor.Exit(thread);//снимаем блокировку
                    }
                }
               if (iterations % 10 == 0)
               {
                    PriorityQueue<SThread> newQueque = new PriorityQueue<SThread>();
                    while (threadQueue.Count > 0)
                    {
                        var thread = threadQueue.Dequeue();
                        if (thread.thread.ThreadState == ThreadState.Unstarted && thread.Priority > 0)
                        {
                            thread.Priority--;
                            tbLog.Invoke(new Action<string>((lb) => tbLog.AppendText(lb)), "Приоритет потока " + thread.thread.Name + " повышен!\r\n");
                        }
                        newQueque.Enqueue(thread);
                    }
                    threadQueue = newQueque;
                }
            }
            }
        }
    }

