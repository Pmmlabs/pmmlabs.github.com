﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueueLibrary
{
    /// <summary>
    /// Исключение вызываемое при пустой очереди.
    /// </summary>
    public class QueueIsEmptyException : Exception
    {
        public QueueIsEmptyException() : base("Очередь пуста!") { }
    }
}
