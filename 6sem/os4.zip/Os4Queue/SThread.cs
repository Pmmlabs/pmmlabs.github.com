﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.CompilerServices;

namespace Os4Queue
{
    class SThread : IComparable
    {
        private TextBox tbLog = null;
        public Thread thread = null;
        private int priority = 0;
        private int workTime = 0;
        private string[] priorityName = new string[] { "Высокий", "Выше среднего", "Средний", "Ниже среднего", "Низкий" };
        private readonly object syncLock = new object();

        public SThread(int threadNumber, TextBox _tbLog, int _workTime, int _priority)//создание потока
        {
            tbLog = _tbLog;
            workTime = _workTime;
            priority = _priority;
            thread = new Thread(new ThreadStart(mainThread));
            thread.Name = threadNumber.ToString();

        }

        /// <summary>
        /// Возвращает разность приоритетов потоков.
        /// Результат равен 0, если приоритеты одинаковы;
        /// Результат положителен, если другой поток имеет меньший приоритет (текущий поток важнее)
        /// Результат отрицателен, если другой поток важнее
        /// </summary>
        /// <param name="obj">другая поток</param>
        /// <returns></returns>
        public int CompareTo(object obj)
        {
            if (obj is SThread)
                return (obj as SThread).priority - this.priority;
            else return -1;
        }

        public int Worktime// время работы потока
        {
            get { return workTime; }
            set { workTime = value; }
        }

        public int Priority// приоритет потока
        {
            get { return priority; }
            set { priority = value; }
        }

        public void Resume()// перезапуск потока
        {
            Monitor.Enter(thread);
            try
            {
                if (thread.ThreadState == ThreadState.Unstarted)
                    thread.Start();
                if (thread.ThreadState != ThreadState.Running)
                    thread.Resume();
            }
            finally
            {
                Monitor.Exit(thread);
            }
        }

        public void Suspend()//приостанавливаем
        {
            Monitor.Enter(thread);
            try
            {
                if (thread.ThreadState != ThreadState.Stopped && thread.ThreadState != ThreadState.Suspended)
                    thread.Suspend();
            }
            finally
            {
                Monitor.Exit(thread);//снимаем блокировку
            }
        }

        private void mainThread()
        {
            if (tbLog.InvokeRequired)
                tbLog.Invoke(new Action<string>((lb) => tbLog.AppendText(lb)), "Поток " + thread.Name + " [" + priorityName[priority] + "] запущен. Время работы: " + workTime + " ms\r\n");
            while (workTime > 0)
            {
                Thread.Sleep(50);//приостанавливаем работу потока
                workTime = (workTime - 100 > 0) ? workTime - 100 : 0;
                if (workTime > 0)
                {
                    if (tbLog.InvokeRequired)
                        tbLog.Invoke(new Action<string>((lb) => tbLog.AppendText(lb)), "Поток " + thread.Name + " работает. Осталось " + workTime + "\r\n");
                }
                else
                {
                    if (tbLog.InvokeRequired)
                        tbLog.Invoke(new Action<string>((lb) => tbLog.AppendText(lb)), "Поток " + thread.Name + " завершился!\r\n");
                }
            }
        }
    }
}
