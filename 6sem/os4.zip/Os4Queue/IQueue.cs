﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueueLibrary
{
    /// <summary>
    /// Базовый интерфейс
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IQueue<T> : IEnumerable<T>
    {
        /// <summary>
        /// Число элементов
        /// </summary>
        int Count
        {
            get;
        }
        /// <summary>
        /// Проверка на пустоту
        /// </summary>
        bool IsEmpty
        {
            get;
        }
        /// <summary>
        /// Добавить элемент в очередь
        /// </summary>
        /// <param name="elem"></param>
        void Enqueue(T elem);
        /// <summary>
        /// Очистить очередь
        /// </summary>
        void Clear();
        /// <summary>
        /// Удалить элемент из очереди
        /// </summary>
        /// <returns></returns>
        T Dequeue();
        /// <summary>
        /// Достать элемент из очереди
        /// </summary>
        /// <returns></returns>
        T Peek();
    }
}
