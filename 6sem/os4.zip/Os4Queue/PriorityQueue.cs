﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace QueueLibrary
{
    /// <summary>
    /// PriorityQueue.
    /// Очередь с приоритетом, структура данных — упорядоченный список
    /// </summary>
    /// <typeparam name="T">Тип элементов очереди.</typeparam>
    public class PriorityQueue<T> : IQueue<T> where T : IComparable
    {       
        private class Node<T>
        {
            public T Element;
            public Node<T> Next;
            public Node(T elem)
            {
                Element = elem;
                Next = null;
            }
        }

        private static object o = new object();

        private Node<T> _head = null;

        int _count = 0;

        /// <summary>
        /// Только для чтения. Позволяет узнать кол-во элементов в очереди.
        /// </summary>
        public int Count
        {
            get { return _count; }
        }

        /// <summary>
        /// Только для чтения. Позволяет проверить на пустоту очередь.
        /// </summary>
        public bool IsEmpty
        {
            get { return _count == 0; }
        }

        /// <summary>
        /// Инициализирует новый экземпляр класса
        /// </summary>
        public PriorityQueue()
        {
            _head = null;
        }

        /// <summary>
        /// Позволяет добавить элемент в очередь.
        /// </summary>
        /// <param name="elem">Добавляемый элемент.</param>
        public void Enqueue(T elem)
        {
            Monitor.Enter(o);//блокируем, чтобы никто не мог обратиться
            try
            {
                if (_head == null)
                    _head = new Node<T>(elem);
                else
                {
                    Node<T> addElem = new Node<T>(elem);
                    if (_head.Element.CompareTo(elem) > 0)//сравниваем
                    {
                        var tmp = _head;
                        while (tmp.Next != null && tmp.Element.CompareTo(elem) > 0)
                            tmp = tmp.Next;
                        addElem.Next = tmp.Next;//добавляем элемент
                        tmp.Next = addElem;
                    }
                    else
                    {
                        addElem.Next = _head;
                        _head = addElem;
                    }
                }
                _count++;
            }
            finally
            {
                Monitor.Exit(o);//снимаем блокировку
            }
        }

        /// <summary>
        /// Позволяет очистить очередь.
        /// </summary>
        public void Clear()
        {
            _count = 0;
            _head = null;
        }

        /// <summary>
        /// Позволяет удалить элемент из очереди.
        /// </summary>
        /// <returns>Удаленный элемент. </returns>
        public T Dequeue()
        {
            Monitor.Enter(o);//блокируем
            try
            {
                if (_head == null)
                    throw new QueueIsEmptyException();
                _count--;// уменьшаем кол-во
                var x = _head.Element;
                _head = _head.Next;
                return x;
            }
            finally
            {
                Monitor.Exit(o);
            }
        }

        /// <summary>
        /// Позволяет взять элемент из очереди.
        /// </summary>
        /// <returns>Взятый элемент.</returns>
        public T Peek()
        {
            if (_head == null)
                throw new QueueIsEmptyException();
            return _head.Element;
        }

        public IEnumerator<T> GetEnumerator()//перебор
        {
            for (Node<T> tmp = _head; tmp != null; tmp = tmp.Next)
                yield return tmp.Element;
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
