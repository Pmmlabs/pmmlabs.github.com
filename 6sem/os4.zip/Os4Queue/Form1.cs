﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using QueueLibrary;

namespace Os4Queue
{
    public partial class FormMain : Form
    {

        ThreadSch sch = null;
        public static bool flag = true;

        public FormMain()
        {
            InitializeComponent();
        }

        private void BtnPlay_Click(object sender, EventArgs e)
        {
            BtnPlay.Enabled = false;
            if (sch == null)
            {
                TB.Clear();
                sch = new ThreadSch(TB);
                sch.MaxThreads = 5;
                sch.Timeslice = 150;
                sch.Start();
            }
            else
                sch.Resume();
            BtnStop.Enabled = true;
        }

        private void BtnStop_Click(object sender, EventArgs e)
        {
            BtnStop.Enabled = false;
            sch.Suspend();
            BtnPlay.Enabled = true;
        }

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            flag = false;
        }
    }
}
