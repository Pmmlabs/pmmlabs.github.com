import javax.swing.*;
public class MainClass {
	public static void main(String[] args){
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
                             try{
				createAndShowGUI();
                             }catch(Exception e) {e.printStackTrace();};
	        }
	    });
	}
	    
	private static void createAndShowGUI() {
		MainFrame frame = new MainFrame();
        frame.setVisible(true);
	    }  

}
