﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.Data.Common;

namespace Sharp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.artistsTableAdapter.Fill(this.avDataSet.artists);
            FillResult();
        }
        private void FillResult()
        {
            try
            {
                String connectionString = "Data Source=C1R011V06;Initial Catalog=av;Persist Security Info=True;User ID=student;Password=student";
                SqlConnection connect = new SqlConnection(connectionString);
                connect.Open();
                SqlCommand comm = new SqlCommand(
                    "SELECT f.title as Название, f.year as 'Год выпуска', a.name as Имя, " +
                    "a.surname as 'Фамилия' FROM films f INNER JOIN relation r ON f.id=r.id_film " +
                    "INNER JOIN artists a ON a.id=r.id_artist", connect);
                SqlDataReader r = comm.ExecuteReader();
                ArrayList a = new ArrayList();
                foreach (DbDataRecord Record in r)
                    a.Add(Record);
                r.Close();
                dataGridView2.DataSource = a;
                dataGridView2.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка чтения!");
                return;
            }
        }
        private void сохранитьИзмененияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FillResult();
        }
        private void dataGridView1_CellValidated(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                artistsTableAdapter.Update(avDataSet);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка сохранения!");
                return;
            }
            FillResult();
        }
    }
}
