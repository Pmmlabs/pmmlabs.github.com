﻿using System;
using System.Globalization;
using System.Windows.Forms;

namespace VM2
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
            var size = new int[] { 10, 30, 50 };
            var diap = new double[] { 2.0, 50.0};
            var eps = new double[] { 1e-5, 1e-8};
            double zn1, zn2, zn3, zn5;
            int zn4;
            dgvResult.Rows.Add(12);
            for (int i = 0; i < 12; i++)
            {
                dgvResult[0, i].Value = (i + 1).ToString(); // номер
                dgvResult[1, i].Value = size[i / 4].ToString(); // размерность
                dgvResult[2, i].Value = diap[(i / 2) % 2].ToString(); //диапазон
                //curTable[2, i].Value = "[-" + data[i / 3].ToString() + ";" + data[i / 3].ToString() + "]"; // диапазон
                dgvResult[3, i].Value = eps[i % 2].ToString(); //точность
                Tester.testMethod(10, diap[(i / 2) % 2], size[i / 4], eps[i % 2], 1000, out zn1, out zn2, out zn3, out zn4, out zn5);
                dgvResult[4, i].Value = zn1.ToString("E2");
                dgvResult[5, i].Value = zn2.ToString("E2");
                dgvResult[6, i].Value = zn3.ToString("E2"); //String.Format("{0:0.####}", zn5);//
                dgvResult[7, i].Value = zn4.ToString();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
