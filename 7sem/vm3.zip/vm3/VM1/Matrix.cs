﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VM2
{
    class Matrix
    {
        public int n,m;
        public double[][] values;

        public Matrix()
        {
            n=0;
        }

        public Matrix(int an, int am)
        {
            n = an;
            m = am;
            values = new double[n][];
            for (int i = 0; i < n; i++)
            {
                values[i] = new double[m];
            }
        }

        public Matrix(int an)
        {
            n=an;
            m = an;
            values=new double[n][];
            for (int i = 0; i < n; i++)
            {
                values[i] = new double[n];
            }
        }

        public Matrix mulKoef(double k)
        {
            Matrix result = new Matrix(n, m);
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                    result.values[i][j] = values[i][j] * k;
            }
            return result;
        }

        public Matrix transpon()
        {
            Matrix result = new Matrix(m, n);
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    result.values[j][i]=values[i][j];
                }
            }
            return result;
        }

        public Vector toVect()
        {
            if (m != 1)
                return null;

            Vector result = new Vector(n);
            for (int i = 0; i < n; i++)
            {
                result[i] = this.values[i][0];
            }
            return result;
        }

        public static Matrix OneMatr(int n)
        {
            Matrix result = new Matrix(n);
            for (int i = 0; i < n; i++)
            {
                result.values[i][i] = 1;
            }
            return result;
        }

        public Matrix summ(Matrix m2, double koef)
        {
            if (m2.m != m || m2.n != n)
                return null;

            Matrix result = new Matrix(n, m);
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    result.values[i][j] = values[i][j] + koef * m2.values[i][j];
                }
            }
            return result;
        }

        public Vector getColumn(int num)
        {
            if (num >= m)
                return null;

            Vector result = new Vector(n);
            for (int i = 0; i < n; i++)
            {
                result[i] = values[i][num];
            }
            return result;
        }

        public static Matrix genGilbertMatrix(int an)
        {
            Matrix result = new Matrix(an);
            for (int i = 0; i < an; i++)
            {
                for (int j = 0; j < an; j++)
                {
                    result.values[i][j]=(double)1/(i+j+1);
                }
            }

            return result;
        }

        public void genWellObusl(double diap)
        {
            Random rn=new Random();
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    values[i][j] = rn.NextDouble() * diap * 2 - diap;
                }
            }
        }

        public void genBadObusl(double diap, double pow)
        {
            double mnozh = 1;
            for (int i = 0; i < pow; i++)
            {
                mnozh *= 10;
            }

            Matrix L = new Matrix(n);
            Matrix U = new Matrix(n);
            Random rn=new Random();
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    L.values[i][j] = rn.NextDouble() * diap * 2 - diap;
                    U.values[j][i] = rn.NextDouble() * diap * 2 - diap;
                }
            }

            for (int i = 0; i < n; i++)
            {
                L.values[i][i] /= mnozh;
                U.values[i][i] /= mnozh;
            }

            Matrix result=L.multiply(U);
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    this.values[i][j] = result.values[i][j];
                }
            }
        }

        public Matrix multiply(Matrix m2)
        {
            if (m2.n != m)
                return null;

            Matrix result = new Matrix(n,m2.m);
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m2.m; j++)
                {
                    result.values[i][j] = 0;
                    for (int k = 0; k < m; k++)
                    {
                        result.values[i][j] += this.values[i][k] * m2.values[k][j];
                    }
                }
            }
            return result;
        }

        public Vector calcF(Vector X)
        {
            if (this.n != X.len)
                return null;

            Vector result = new Vector(X.len);
            for (int i = 0; i < n; i++)
            {
                result[i] = 0;
                for (int j = 0; j < n; j++)
                {
                    result[i] += values[i][j] * X[j];
                }
            }

            return result;
        }
    }
}
