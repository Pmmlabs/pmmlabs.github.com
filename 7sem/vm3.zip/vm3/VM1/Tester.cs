﻿using System;

namespace VM2
{
    class Tester
    {
        static readonly Random rn = new Random();

        static Vector X, F;
        static Matrix A;

        //генерируем матрицу и ее собственные векторы и значения
        static Matrix generateA(int size, double range, out Vector lamb, out Matrix H, out int max1, out int max2, out int max3)
        {
            Matrix result = new Matrix(size);
            Matrix L = new Matrix(size);
            lamb = new Vector(size);
            Vector W = new Vector(size);
            int bufr = (int)Math.Round(range);
            if (bufr <= 2)
                bufr = size;
            for (int i = 0; i < size; i++)
            {
                lamb[i] = bufr - i; //rn.NextDouble() * 2 * range;// -range;//
                if (i % 2 == 0)
                    lamb[i] = -lamb[i];
                W[i] = rn.NextDouble() * 2 * range;// -range;
            }
            max1 = 0;
            max2 = 1;
            max3 = 2;
            for (int i = 1; i < size; i++)
                if (Math.Abs(lamb[i]) >= Math.Abs(lamb[max1])) max1 = i;
            for (int i = 1; i < size; i++)
                if (Math.Abs(lamb[i]) >= Math.Abs(lamb[max2]) && i != max1) max2 = i;
            for (int i = 1; i < size; i++)
                if (Math.Abs(lamb[i]) >= Math.Abs(lamb[max3]) && i != max1 && i != max2) max3 = i;

            for (int i = 0; i < size; i++)
            {
                L.values[i][i] = lamb[i];
            }
            W.Normalize();
            Matrix Wmat = W.toMatr();
            H = Matrix.OneMatr(size).summ(Wmat.multiply(Wmat.transpon()), -2);
            result = (H.multiply(L)).multiply(H.transpon());
            return result;
        }

        static int solveMethod(int size, Matrix A, double lam1, Vector x1, double lam2, Vector x2, double epslam, double epsx, int maxIter, out double lam3, out Vector x3, out int kolIter, out double r)
        {
            lam3 = 0;
            x3 = null;
            kolIter = 0;
            r = 0;
            try
            {
                Matrix x1mat = x1.toMatr();
                A = A.summ(x1mat.multiply(x1mat.transpon()), -lam1);
                Matrix x2mat = x2.toMatr();
                A = A.summ(x2mat.multiply(x2mat.transpon()), -lam2);
                kolIter = 1;
                Vector x = new Vector(size);
                for (int i = 0; i < size; i++)
                {
                    x[i] = 200 * rn.NextDouble() - 100;
                }
                Vector nu = null, nupred;
                double sig = 0, sigpred;
                nupred = x.NormalizeToVec();
                x = A.multiply(nupred.toMatr()).toVect();
                sigpred = nupred.toMatr().transpon().multiply(x.toMatr()).values[0][0];

                bool isPresice = false;
                while (kolIter < maxIter && !isPresice)
                {
                    kolIter++;
                    nu = x.NormalizeToVec();
                    x = A.multiply(nu.toMatr()).toVect();
                    sig = nu.toMatr().transpon().multiply(x.toMatr()).values[0][0];

                    isPresice = true;
                    if (Math.Abs(sig - sigpred) >= epslam)
                        isPresice = false;
                    if (Math.Abs(1 - Math.Abs(nu.findCosAngle(nupred))) >= epsx)
                        isPresice = false;

                    nupred = nu;
                    sigpred = sig;
                }

                lam3 = sig;
                x3 = nu;
                Matrix x3mat = x3.toMatr();
                r = A.multiply(x3mat).summ(x3mat.mulKoef(lam3), -1).toVect().findEps(new Vector(size));
            }
            catch (Exception e)
            {
                return -1;
            }
            return 0;
        }

        //процедура тестирования метода
        public static void testMethod(int kolTests, double range, int kolEquation, double eps, int maxIter, out double lamepsavg, out double xavg, out double ravg, out int kolIteravg, out double avglam)
        {
            Matrix A;
            Matrix H = null;
            Vector lamb = null;
            double lam3 = 0;
            Vector x3 = null;
            int kolIter = 0;
            double r = 0;
            ravg = 0;
            lamepsavg = 0;
            kolIteravg = 0;
            avglam = 0;
            xavg = 0;
            bool noErr = false;
            Vector outX = new Vector();
            int max1, max2, max3;
            max3 = 2;
            for (int i = 0; i < kolTests; i++)
            {
                noErr = false;
                while (!noErr)
                {
                    A = generateA(kolEquation, range, out lamb, out H, out max1, out max2, out max3);
                    noErr = solveMethod(kolEquation, A, lamb[max1], H.getColumn(max1), lamb[max2], H.getColumn(max2), eps, eps, maxIter, out lam3, out x3, out kolIter, out r) == 0;
                }
                avglam += lam3;
                kolIteravg += kolIter;
                ravg += r;
                lamepsavg += Math.Abs((lamb[max3] - lam3) / lamb[max3]);
                xavg += (1 - Math.Abs(H.getColumn(max3).findCosAngle(x3)));
            }

            avglam /= kolTests;
            kolIteravg /= kolTests;
            ravg /= kolTests;
            lamepsavg /= kolTests;
            xavg /= kolTests;
        }
    }
}
