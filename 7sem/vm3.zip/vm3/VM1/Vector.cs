﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VM2
{
    class Vector
    {
        public int len;
        double[] values;

        public double this[int i]
        {
            get
            {
                return values[i];
            }

            set
            {
                values[i] = value;
            }
        }

        public Vector()
        {
            len=0;
        }

        public Vector(int alen)
        {
            len=alen;
            values=new double[len];
        }

        public static Vector genOneVect(int alen)
        {
            Vector result = new Vector();
            result.len = alen;
            result.values = new double[alen];
            for (int i = 0; i < alen; i++)
            {
                result[i] = 1;
            }
            return result;
        }

        public double findLen()
        {
            double lenvect = 0;
            for (int i = 0; i < len; i++)
            {
                lenvect += (values[i] * values[i]);
            }
            lenvect = Math.Sqrt(lenvect);
            return lenvect;
        }

        public Vector NormalizeToVec()
        {
            Vector result = new Vector(len);
            double lenvect = this.findLen();
            for (int i = 0; i < len; i++)
            {
                result.values[i] = values[i]/lenvect;
            }
            return result;
        }

        public void Normalize()
        {
            double lenvect=this.findLen();
            for (int i = 0; i < len; i++)
            {
                values[i] /= lenvect;
            }
        }

        public double findEps(Vector v2)
        {
            double result = 0;
            if (len != v2.len)
                return -1;

            for (int i = 0; i < len; i++)
            {
                result = Math.Max(result, Math.Abs(values[i] - v2.values[i]));
            }
            return result;
        }

        public double findCosAngle(Vector v2)
        {
            double result = 0;
            if (len != v2.len)
                return -1;

            double l1 = this.findLen();
            double l2 = v2.findLen();
            for (int i = 0; i < len; i++)
            {
                result += values[i] * v2.values[i];
            }
            result /= l1;
            result /= l2;
            return result;
        }

        public Matrix toMatr()
        {
            Matrix result = new Matrix(len, 1);
            for (int i = 0; i < len; i++)
            {
                result.values[i][0] = values[i];
            }
            return result;
        }

        public void genValues(double maxVal)
        {
            Random rn=new Random();
            for (int i = 0; i < len; i++)
            {
                values[i] = rn.NextDouble()*maxVal*2 - maxVal;
            }
        }
    }
}
