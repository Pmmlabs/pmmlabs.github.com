﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Sharp1
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }
        [Serializable]
        public class Planet
        {
            public String title;
            public int sputnik;
            public double radius;
        }
        public abstract class Planets
        {
            protected List<Planet> L = new List<Planet>();
            public List<Planet> getPlanets { get { return L; } }
            public abstract void Load(String fname);
            public abstract void Save(String fname);
            public void Print(DataGridView _d)
            {
                if (L.Count != 0)
                {
                    _d.Rows.Clear();
                    _d.Rows.Add(L.Count);
                    int i = -1;
                    foreach (Planet pl in L)
                    {
                        _d.Rows[++i].Cells[0].Value = pl.title;
                        _d.Rows[i].Cells[1].Value = pl.sputnik;
                        _d.Rows[i].Cells[2].Value = pl.radius;
                    }
                }
            }

            public void Calc()
            {
                for (int i = 0; i < L.Count; i++)
                {
                    L[i].radius /= 2;
                }
            }
        }
        Planets p = null;
        public class BinaryPlanets : Planets
        {
            public BinaryPlanets() { }
            public BinaryPlanets(Planets _p)
            {
                this.L = _p.getPlanets;
            }
            public override void Load(string fname)
            {
                using (FileStream fs = new FileStream(fname, FileMode.Open))
                {
                    try
                    {
                        BinaryFormatter formatter = new BinaryFormatter();
                        L = (List<Planet>)formatter.Deserialize(fs);
                    }
                    catch (SerializationException e)
                    {
                        MessageBox.Show("Ошибка загрузки: " + e.Message);
                    }
                    finally
                    {
                        fs.Close();
                    }
                }
            }
            public override void Save(string fname)
            {
                using (FileStream fs = new FileStream(fname, FileMode.Create))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    try
                    {
                        formatter.Serialize(fs, L);
                    }
                    catch (SerializationException e)
                    {
                        MessageBox.Show("Ошибка сохранения: " + e.Message);
                    }
                    finally
                    {
                        fs.Close();
                    }
                }
            }
        }
        public class TextPlanets : Planets
        {
            public TextPlanets() { }
            public TextPlanets(Planets _p)
            {
                this.L = _p.getPlanets;
            }
            public override void Load(string fname)
            {
                using (StreamReader file = new StreamReader(fname))
                {
                    while (!file.EndOfStream)
                    {
                        Planet pl = new Planet();
                        string[] pieces = file.ReadLine().Split(new string[] { " " }, StringSplitOptions.None);
                        pl.title = pieces[0];
                        pl.sputnik = Convert.ToInt32(pieces[1]);
                        pl.radius = Convert.ToDouble(pieces[2]);
                        L.Add(pl);
                    }
                }
            }
            public override void Save(string fname)
            {
                StreamWriter file = new StreamWriter(fname, true);
                foreach (Planet pl in L)
                {
                    file.WriteLine(pl.title + " " + pl.sputnik.ToString() + " " + pl.radius.ToString());
                }
                file.Close();
            }
        }
        public class XmlPlanets : Planets
        {
            public XmlPlanets() { }
            public XmlPlanets(Planets _p)
            {
                this.L = _p.getPlanets;
            }
            public override void Load(string fname)
            {
                XmlSerializer serializer = new XmlSerializer(typeof(List<Planet>));
                FileStream fs = new FileStream(fname, FileMode.Open);
                L = (List<Planet>)serializer.Deserialize(fs);
            }
            public override void Save(string fname)
            {
                XmlSerializer serializer = new XmlSerializer(typeof(List<Planet>));
                TextWriter writer = new StreamWriter(fname);
                serializer.Serialize(writer, L);
                writer.Close();
            }
        }
        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openD.ShowDialog();
        }
        private void сохранитьКакToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (p != null && p.getPlanets.Count > 0) saveD.ShowDialog();
        }
        private void openD_FileOk(object sender, CancelEventArgs e)
        {
            String filename = openD.FileName;
            if (filename != "" && File.Exists(filename))
            {
                FileInfo fi = new FileInfo(filename);
                switch (fi.Extension)
                {
                    case ".dat": p = new BinaryPlanets(); break;
                    case ".txt": p = new TextPlanets(); break;
                    case ".xml": p = new XmlPlanets(); break;
                    default: MessageBox.Show("Файл не является ни бинарным, ни текстовым, ни XML"); return;
                }
                p.Load(filename);
                p.Print(dGV);
            }
            else MessageBox.Show("Неверное имя файла!");
        }

        private void saveD_FileOk(object sender, CancelEventArgs e)
        {
            Planets p1 = null;
            String filename = saveD.FileName;
            if (filename != "")
            {
                FileInfo fi = new FileInfo(filename);
                switch (fi.Extension)
                {
                    case ".dat": p1 = new BinaryPlanets(p); break;
                    case ".txt": p1 = new TextPlanets(p); break;
                    case ".xml": p1 = new XmlPlanets(p); break;
                    default: MessageBox.Show("Файл не является ни бинарным, ни текстовым, ни XML"); return;
                }
                p1.Save(filename);
            }
            else MessageBox.Show("Неверное имя файла!");
        }

        private void уменьшитьРадиусПланетВ2РазаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            p.Calc();
            p.Print(dGV);
        }
    }
}