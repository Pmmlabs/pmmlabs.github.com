﻿namespace Sharp1
{
    partial class FormMain
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.открытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.уменьшитьРадиусПланетВ2РазаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьКакToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dGV = new System.Windows.Forms.DataGridView();
            this.Название = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Спутников = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Радиус = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.openD = new System.Windows.Forms.OpenFileDialog();
            this.saveD = new System.Windows.Forms.SaveFileDialog();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGV)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытьToolStripMenuItem,
            this.уменьшитьРадиусПланетВ2РазаToolStripMenuItem,
            this.сохранитьКакToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(592, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // открытьToolStripMenuItem
            // 
            this.открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
            this.открытьToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.открытьToolStripMenuItem.Text = "Открыть";
            this.открытьToolStripMenuItem.Click += new System.EventHandler(this.открытьToolStripMenuItem_Click);
            // 
            // уменьшитьРадиусПланетВ2РазаToolStripMenuItem
            // 
            this.уменьшитьРадиусПланетВ2РазаToolStripMenuItem.Name = "уменьшитьРадиусПланетВ2РазаToolStripMenuItem";
            this.уменьшитьРадиусПланетВ2РазаToolStripMenuItem.Size = new System.Drawing.Size(210, 20);
            this.уменьшитьРадиусПланетВ2РазаToolStripMenuItem.Text = "Уменьшить радиус планет в 2 раза";
            this.уменьшитьРадиусПланетВ2РазаToolStripMenuItem.Click += new System.EventHandler(this.уменьшитьРадиусПланетВ2РазаToolStripMenuItem_Click);
            // 
            // сохранитьКакToolStripMenuItem
            // 
            this.сохранитьКакToolStripMenuItem.Name = "сохранитьКакToolStripMenuItem";
            this.сохранитьКакToolStripMenuItem.Size = new System.Drawing.Size(98, 20);
            this.сохранитьКакToolStripMenuItem.Text = "Сохранить как";
            this.сохранитьКакToolStripMenuItem.Click += new System.EventHandler(this.сохранитьКакToolStripMenuItem_Click);
            // 
            // dGV
            // 
            this.dGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Название,
            this.Спутников,
            this.Радиус});
            this.dGV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGV.Location = new System.Drawing.Point(0, 24);
            this.dGV.Name = "dGV";
            this.dGV.Size = new System.Drawing.Size(592, 238);
            this.dGV.TabIndex = 1;
            // 
            // Название
            // 
            this.Название.HeaderText = "Название";
            this.Название.Name = "Название";
            this.Название.ReadOnly = true;
            this.Название.Width = 300;
            // 
            // Спутников
            // 
            this.Спутников.HeaderText = "Спутников";
            this.Спутников.Name = "Спутников";
            this.Спутников.ReadOnly = true;
            // 
            // Радиус
            // 
            this.Радиус.HeaderText = "Радиус";
            this.Радиус.Name = "Радиус";
            this.Радиус.ReadOnly = true;
            // 
            // openD
            // 
            this.openD.FileName = "openFileDialog1";
            this.openD.Filter = "Бинарные файлы|*.dat|Текстовые файлы|*.txt|XML файлы|*.xml";
            this.openD.FileOk += new System.ComponentModel.CancelEventHandler(this.openD_FileOk);
            // 
            // saveD
            // 
            this.saveD.Filter = "Бинарные файлы|*.dat|Текстовые файлы|*.txt|XML файлы|*.xml";
            this.saveD.FileOk += new System.ComponentModel.CancelEventHandler(this.saveD_FileOk);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(592, 262);
            this.Controls.Add(this.dGV);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormMain";
            this.Text = "C#-1. Планеты.";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem уменьшитьРадиусПланетВ2РазаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьКакToolStripMenuItem;
        private System.Windows.Forms.DataGridView dGV;
        private System.Windows.Forms.OpenFileDialog openD;
        private System.Windows.Forms.SaveFileDialog saveD;
        private System.Windows.Forms.DataGridViewTextBoxColumn Название;
        private System.Windows.Forms.DataGridViewTextBoxColumn Спутников;
        private System.Windows.Forms.DataGridViewTextBoxColumn Радиус;
    }
}

