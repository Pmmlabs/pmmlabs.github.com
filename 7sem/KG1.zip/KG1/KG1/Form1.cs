﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace KG1
{
    public partial class FormMain : Form
    {
        Line mainLine;
        public FormMain()
        {
            InitializeComponent();
        }
        class Line
        {
            public int x0, y0, x1, y1;
            public Line(int _x0, int _y0, int _x1, int _y1)
            {
                if (_x1 < _x0)
                {
                    x0 = _x1;
                    x1 = _x0;
                    y0 = _y1;
                    y1 = _y0;
                }
                else
                {
                    x0 = _x0;
                    x1 = _x1;
                    y0 = _y0;
                    y1 = _y1;
                }
            }
        }

        float t0, t1;
        bool checkPQ(int p, int q)
        {
            if (p == 0) // прямая параллельна отсекающей стороне окна
            {
                if (q < 0) return false;            // отрезок не виден
            }
            else
            {
                float r = (float)q / p; // r - точка пересечения с гранью окна
                if (p < 0)
                {
                    if (r > t1) return false;
                    else if (r > t0) t0 = r;
                }
                else
                {
                    if (r < t0) return false;
                    else if (r < t1) t1 = r;
                }
            }
            return true;
        }

        private bool Clip(Line line, Line window) // двумерное отсечение линии line окном window
        {
            int dx = line.x1 - line.x0, dy = line.y1 - line.y0;
            t0 = 0; t1 = 1;
            if (checkPQ(-dx, line.x0 - window.x0) &&
                checkPQ(dx, window.x1 - line.x0) &&
                checkPQ(-dy, line.y0 - window.y0) &&
                checkPQ(dy, window.y1 - line.y0))
            {
                if (t1 < 1)
                {
                    line.x1 = (int)(line.x0 + t1 * dx);
                    line.y1 = (int)(line.y0 + t1 * dy);
                }
                if (t0 > 0)
                {
                    line.x0 = (int)(line.x0 + t0 * dx);
                    line.y0 = (int)(line.y0 + t0 * dy);
                }
                return true;
            }
            return false;
        }

        private void DrawLine(PictureBox pb, Line line) // рисование линии line на pb
        {
            var bm = new Bitmap(600, 600);
            int dx = line.x1 - line.x0;
            int dy = line.y1 - line.y0;
            if (line.x1 - line.x0 > line.y1 - line.y0) // ширина больше высоты
            {
                bool positive = line.x0 < line.x1; // идем от x0 к x1 ?
                for (int i = (positive ? line.x0 : line.x1); i <= (positive ? line.x1 : line.x0); i += (positive ? 1 : -1))
                    bm.SetPixel(i, (i - line.x0) * dy / dx + line.y0, Color.Black);
            }
            else // высота больше ширины
            {
                bool positive = line.y0 < line.y1; // идем от y0 к y1 ?
                for (int i = (positive ? line.y0 : line.y1); i <= (positive ? line.y1 : line.y0); i += (positive ? 1 : -1))
                    bm.SetPixel((i - line.y0) * dx / dy + line.x0, i, Color.Black);
            }
            pb.Image = bm;
        }

        private void buttonBuild_Click(object sender, EventArgs e)
        {
            mainLine = new Line(Convert.ToInt32(tbLineX0.Text),
                                Convert.ToInt32(tbLineY0.Text),
                                Convert.ToInt32(tbLineX1.Text),
                                Convert.ToInt32(tbLineY1.Text));
            DrawLine(pictureBox1, mainLine);
        }

        private void buttonClip_Click(object sender, EventArgs e)
        {
            if (!Clip(mainLine, new Line(Convert.ToInt32(tbWindowX0.Text),
                                         Convert.ToInt32(tbWindowY0.Text),
                                         Convert.ToInt32(tbWindowX1.Text),
                                         Convert.ToInt32(tbWindowY1.Text)))) MessageBox.Show("Линия невидима!");
            else DrawLine(pictureBox1, mainLine);
        }
    }
}