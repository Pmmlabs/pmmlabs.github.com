﻿namespace KG1
{
    partial class FormMain
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbWindowX1 = new System.Windows.Forms.TextBox();
            this.tbWindowX0 = new System.Windows.Forms.TextBox();
            this.tbWindowY0 = new System.Windows.Forms.TextBox();
            this.tbWindowY1 = new System.Windows.Forms.TextBox();
            this.buttonClip = new System.Windows.Forms.Button();
            this.tbLineX1 = new System.Windows.Forms.TextBox();
            this.tbLineX0 = new System.Windows.Forms.TextBox();
            this.tbLineY0 = new System.Windows.Forms.TextBox();
            this.tbLineY1 = new System.Windows.Forms.TextBox();
            this.buttonBuild = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(884, 582);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tbWindowX1);
            this.panel1.Controls.Add(this.tbWindowX0);
            this.panel1.Controls.Add(this.tbWindowY0);
            this.panel1.Controls.Add(this.tbWindowY1);
            this.panel1.Controls.Add(this.buttonClip);
            this.panel1.Controls.Add(this.tbLineX1);
            this.panel1.Controls.Add(this.tbLineX0);
            this.panel1.Controls.Add(this.tbLineY0);
            this.panel1.Controls.Add(this.tbLineY1);
            this.panel1.Controls.Add(this.buttonBuild);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(684, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 582);
            this.panel1.TabIndex = 1;
            // 
            // tbWindowX1
            // 
            this.tbWindowX1.Location = new System.Drawing.Point(140, 161);
            this.tbWindowX1.Name = "tbWindowX1";
            this.tbWindowX1.Size = new System.Drawing.Size(50, 20);
            this.tbWindowX1.TabIndex = 13;
            this.tbWindowX1.Text = "500";
            // 
            // tbWindowX0
            // 
            this.tbWindowX0.Location = new System.Drawing.Point(75, 161);
            this.tbWindowX0.Name = "tbWindowX0";
            this.tbWindowX0.Size = new System.Drawing.Size(50, 20);
            this.tbWindowX0.TabIndex = 12;
            this.tbWindowX0.Text = "100";
            // 
            // tbWindowY0
            // 
            this.tbWindowY0.Location = new System.Drawing.Point(19, 192);
            this.tbWindowY0.Name = "tbWindowY0";
            this.tbWindowY0.Size = new System.Drawing.Size(50, 20);
            this.tbWindowY0.TabIndex = 11;
            this.tbWindowY0.Text = "100";
            // 
            // tbWindowY1
            // 
            this.tbWindowY1.Location = new System.Drawing.Point(19, 223);
            this.tbWindowY1.Name = "tbWindowY1";
            this.tbWindowY1.Size = new System.Drawing.Size(50, 20);
            this.tbWindowY1.TabIndex = 10;
            this.tbWindowY1.Text = "500";
            // 
            // buttonClip
            // 
            this.buttonClip.Location = new System.Drawing.Point(69, 264);
            this.buttonClip.Name = "buttonClip";
            this.buttonClip.Size = new System.Drawing.Size(75, 23);
            this.buttonClip.TabIndex = 9;
            this.buttonClip.Text = "Отсечь";
            this.buttonClip.UseVisualStyleBackColor = true;
            this.buttonClip.Click += new System.EventHandler(this.buttonClip_Click);
            // 
            // tbLineX1
            // 
            this.tbLineX1.Location = new System.Drawing.Point(85, 88);
            this.tbLineX1.Name = "tbLineX1";
            this.tbLineX1.Size = new System.Drawing.Size(50, 20);
            this.tbLineX1.TabIndex = 4;
            this.tbLineX1.Text = "599";
            // 
            // tbLineX0
            // 
            this.tbLineX0.Location = new System.Drawing.Point(19, 51);
            this.tbLineX0.Name = "tbLineX0";
            this.tbLineX0.Size = new System.Drawing.Size(50, 20);
            this.tbLineX0.TabIndex = 3;
            this.tbLineX0.Text = "0";
            // 
            // tbLineY0
            // 
            this.tbLineY0.Location = new System.Drawing.Point(75, 51);
            this.tbLineY0.Name = "tbLineY0";
            this.tbLineY0.Size = new System.Drawing.Size(50, 20);
            this.tbLineY0.TabIndex = 2;
            this.tbLineY0.Text = "0";
            // 
            // tbLineY1
            // 
            this.tbLineY1.Location = new System.Drawing.Point(140, 88);
            this.tbLineY1.Name = "tbLineY1";
            this.tbLineY1.Size = new System.Drawing.Size(50, 20);
            this.tbLineY1.TabIndex = 1;
            this.tbLineY1.Text = "599";
            // 
            // buttonBuild
            // 
            this.buttonBuild.Location = new System.Drawing.Point(63, 124);
            this.buttonBuild.Name = "buttonBuild";
            this.buttonBuild.Size = new System.Drawing.Size(75, 23);
            this.buttonBuild.TabIndex = 0;
            this.buttonBuild.Text = "Построить";
            this.buttonBuild.UseVisualStyleBackColor = true;
            this.buttonBuild.Click += new System.EventHandler(this.buttonBuild_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 582);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "FormMain";
            this.Text = "Алгоритм двумерного отсечения Лианга-Барски";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonBuild;
        private System.Windows.Forms.TextBox tbLineX1;
        private System.Windows.Forms.TextBox tbLineX0;
        private System.Windows.Forms.TextBox tbLineY0;
        private System.Windows.Forms.TextBox tbLineY1;
        private System.Windows.Forms.Button buttonClip;
        private System.Windows.Forms.TextBox tbWindowX1;
        private System.Windows.Forms.TextBox tbWindowX0;
        private System.Windows.Forms.TextBox tbWindowY0;
        private System.Windows.Forms.TextBox tbWindowY1;
    }
}

