﻿using System;
using System.IO;
using System.Windows.Forms;

namespace vm5
{
    public partial class Form1 : Form
    {
        static readonly Random rn = new Random();
        public Form1()
        {
            InitializeComponent();
        }
        private double f1(double x) // вторая производная для х в квадрате
        {
            return 2;
        }
        private double f2(double x) // вторая производная для корня из х
        {
            return -1 / (4 * Math.Pow(x, 1.5));
        }

        private double f3(double x) // for -2+ex
        {
            return 0;// Math.Exp(x);
        }

        private double f4(double x) // for x kub
        {
            return 6 * x;
        }
        private double f5(double x)
        {
            return x;
        }
        private double f6(double x)
        {
            return 2*x;
        }
        private double f(double x)
        {
            return f6(x);
        }

        private double p(double x)
        {
          //  return -1;
            return 0;
            //return 1;
        }

        private double q(double x)
        {
            //return 0;
            //return 0;
            return x;
        }
        private void buttonBrowse_Click(object sender, EventArgs e)
        {
            if (DialogResult.OK == openFileDialog1.ShowDialog()) textBox1.Text = openFileDialog1.FileName;
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            var reader = new StreamReader(textBox1.Text);
            textBoxSrc.Text = reader.ReadToEnd();
            reader.Close();

            textBoxRez.Text = "\r\nX\t\tY\t\tY'";
            if (Solve(textBox1.Text, "", "rez.txt") != 0) MessageBox.Show("Ошибка входных данных");
        }
        void Invert(ref double[] x)
        {
            int n = x.Length;
            for (int i = 0; i < n / 2; i++)
            {
                double t = x[i];
                x[i] = x[n - 1 - i];
                x[n - i - 1] = t;
            }
        }
        double[] Func(double x, double[] y)
        {
            return new[] { p(x) * y[0] + y[1], -y[0] * q(x), y[0] * f(x) };
        }
        private void Koshi(ref double[] u, ref double[] v, ref double[] w, double a, double b, double g, double[] x)
        {

            int n = x.Length;
            double[] yCurr = new[] { a, -b, g };
            double xCurr = x[0];
            u[0] = a;
            v[0] = -b;
            w[0] = g;
            for (int i = 1; i < n; i++)
            {
                double h = x[i] - x[i - 1];
                double[] f1 = Func(xCurr, yCurr); // f(x0,y0)
                double[] k1 = new[] { h * f1[0], h * f1[1], h * f1[2] }; // hf(x0,y0)
                double[] yCurrK1 = new[] { yCurr[0] + k1[0], yCurr[1] + k1[1], yCurr[2] + k1[2] }; // y0+k1
                double[] f2 = Func(xCurr + h, yCurrK1); // f(x0+h,y0+k1)
                for (int j = 0; j < 3; j++)
                    yCurr[j] = yCurr[j] + 0.5 * (k1[j] + h * f2[j]);
                xCurr = x[i];
                u[i] = yCurr[0];
                v[i] = yCurr[1];
                w[i] = yCurr[2];
            }
        }

        private double[] LinearSystem(double a, double b, double c, double d, double e, double f)
        {
            /*  a b c
             *  d e f
             */
            double y = (c * d / a - f) / (b * d / a - e);
            double x = c / a - b * y / a;
            return new[] { x, y };
        }

        double FuncExact(double x)
        {
            return -2 + Math.Exp(x);
        }

        private int Solve(string data, string f, string rez)
        {
            if (File.Exists(data))
            {
                double a1, b1, g1, a2, b2, g2;
                var reader = new StreamReader(textBox1.Text);
                string[] str = reader.ReadLine().Replace('.', ',').Split(' ');
                try
                {
                    a1 = Convert.ToDouble(str[0]);
                    b1 = Convert.ToDouble(str[1]);
                    g1 = Convert.ToDouble(str[2]);
                    a2 = Convert.ToDouble(str[3]);
                    b2 = Convert.ToDouble(str[4]);
                    g2 = Convert.ToDouble(str[5]);
                }
                catch (Exception)
                {
                    return 1;
                }
                str = reader.ReadLine().Replace('.', ',').Split(' ');
                int m;
                try
                {
                    m = Convert.ToInt32(str[2]);
                }
                catch (Exception)
                {

                    return 1;
                }
                double[] x = new double[m + 2];
                try
                {
                    x[0] = Convert.ToDouble(str[0]); //A
                    x[m + 1] = Convert.ToDouble(str[1]); // B
                }
                catch (Exception)
                {
                    return 1;
                }

                for (int i = 1; i <= m; i++)
                {
                    str = reader.ReadLine().Split(' ');
                    x[i] = Convert.ToDouble(str[0].Replace('.', ','));
                }
                reader.Close();

                //проверка входных данных
                if ((x[0] >= x[m + 1]) || (m <= 0) || (a1 * a1 + b1 * b1 <= 0) || (a2 * a2 + b2 * b2 <= 0)) return 1;
                double[] u = new double[m + 2];
                double[] v = new double[m + 2];
                double[] w = new double[m + 2];
                double[] alpha = new double[m + 2];
                double[] beta = new double[m + 2];
                double[] gamma = new double[m + 2];
                Koshi(ref u, ref v, ref w, a1, b1, g1, x);
                Invert(ref x);
                Koshi(ref alpha, ref beta, ref gamma, a2, b2, g2, x);
                Invert(ref alpha);
                Invert(ref beta);
                Invert(ref gamma);
                Invert(ref x);
                double[] yShtrih = new double[m + 2];
                double[] y = new double[m + 2];
                double eps;
                for (int i = 0; i < m + 2; i++)
                {
                    double[] solution = (u[i] * (-beta[i]) + alpha[i] * v[i] != 0 ? LinearSystem(u[i], -v[i], w[i], alpha[i], -beta[i], gamma[i]) : new[] { 0.0, 0.0 });
                    yShtrih[i] = solution[0];
                    y[i] = solution[1];
                    eps = Math.Abs(y[i] - FuncExact(x[i]));
                    AddToTextBox(x[i], y[i], yShtrih[i], eps);
                }
                /* StreamWriter sw = new StreamWriter(rez);
                sw.WriteLine(textBoxRez.Text);
                sw.Close();*/
                return 0;
            }
            return 1;
        }
        private void AddToTextBox(double _xCurr, double _yCurr, double _m, double eps)
        {
            textBoxRez.Text += "\r\n" + _xCurr.ToString("0.####") + "\t\t" + _yCurr.ToString("0.###") + "\t\t" + _m.ToString("0.###") + "\t\t" + eps.ToString("0.######"); ;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            openFileDialog1.InitialDirectory = Application.StartupPath;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int M = Convert.ToInt32(textBoxM.Text);
            if (textBoxSrc.Lines.Length > 0)
            {
                string temp = textBoxSrc.Lines[0];
                textBoxSrc.Clear();
                textBoxSrc.Text += temp + (char)(13) + (char)(10);
            }
            double A = Convert.ToDouble(textBoxA.Text.Replace('.', ','));
            double B = Convert.ToDouble(textBoxB.Text.Replace('.', ','));

            textBoxSrc.Text += A.ToString() + " " + B.ToString() + " " + M.ToString() + (char)(13) + (char)(10);
            double H = (B - A) / M;
            for (int i = 0; i < M; i++)
            {
                A += H;
                textBoxSrc.Text += A.ToString() + (char)(13) + (char)(10);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                StreamWriter sw = new StreamWriter(textBox1.Text);
                sw.WriteLine(textBoxSrc.Text);
                sw.Close();
            }
            else
            {
                if (DialogResult.Cancel != saveFileDialog1.ShowDialog())
                {
                    textBox1.Text = saveFileDialog1.FileName;
                    button2.PerformClick();
                }
            }
        }
    }
}
