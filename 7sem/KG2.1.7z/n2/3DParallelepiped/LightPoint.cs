﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3DParallelepiped
{
    class LightPoint
    {

        public Vertex pos;
        public double intR, intG, intB;
        public double k1, k2, k3;

        public LightPoint(Vertex apos, double aintR, double aintG, double aintB, double ak1, double ak2, double ak3)
        {
            pos = apos;
            intR = aintR;
            intG = aintG;
            intB = aintB;
            k1 = ak1;
            k2 = ak2;
            k3 = ak3;
        }

        public LightPoint(Vertex apos)
        {
            pos = apos;
            intR = 1;
            intG = 1;
            intB = 1;
            k1 = 1;
            k2 = 0;
            k3 = 0;
        }

        public double calcIntensity(Vertex v)
        {
            Vertex buf = v.substract(pos);
            double len=buf.length;
            return 1.0/(k1+k2*len+k3*len*len);
        }
    }
}
