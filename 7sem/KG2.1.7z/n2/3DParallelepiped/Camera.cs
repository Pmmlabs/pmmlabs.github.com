﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3DParallelepiped
{
    class Camera
    {
        Vertex fpos; //позиция камеры
        Vertex fdirection;  //направление камеры
        double fangle; //угол обзора камеры в радианах
        public Matrix toRotate;

        public Camera(Vertex apos, Vertex adirection, double aangle)
        {
            fpos = apos;
            fdirection = adirection;
            if (direction.length == 0)
            {
                direction.applyMatrix(Matrix.getShiftMatr(0, 0, 1)); //если вектор направления нулевой, то мы его в сторону оси z направляем
            }
            fangle = (aangle / 360) * 2 * Math.PI; //переводим угол обзора из градусов в радианы
            calcMatrixToRotate();
        }

        public double angle
        {
            get { return fangle; }
        }

        public Vertex pos
        {
            get { return fpos; }
        }

        public Vertex direction
        {
            get { return fdirection; }
        }

        /// <summary>
        /// Процедура высчитывает матрицу преобразования координатных осей так, чтобы ось Z смотрела в направлении камеры
        /// </summary>
        void calcMatrixToRotate()
        {
            //берем проекцию на ось XOY, поворачиваем так, чтобы ось Y смотрела в ту же сторону
            //далее поворачиваем по оси X так, чтобы Z совпала с направлением камеры
            //матрица=переместили,повернули, повернули
            Matrix shift = Matrix.getShiftMatr(-pos.getX(), -pos.getY(), -pos.getZ());
            Vertex proj = new Vertex(direction.getX(), direction.getY(), 0);
            double ang = proj.findAngle(new Vertex(0, 1, 0));
            if (proj.getX() < 0)
                ang = -ang;
            Matrix rotZ = Matrix.getRorateZMatr(ang); //так как поворот идет против часовой стрелки
            Matrix rotX = Matrix.getRorateXMatr(direction.findAngle(new Vertex(0, 0, 1))); //а это матрица поворота, чтобы Z совпало с направлением камеры
            toRotate = shift.mulMatrs(rotZ.mulMatrs(rotX));
        }
    }
}
