﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace _3DParallelepiped
{
    class Polygon
    {

        Vertex fv0, fv1, fv2;
        public Color color;

        public Polygon(Vertex av0, Vertex av1, Vertex av2, Color aColor)
        {
            fv0 = av0;
            fv1 = av1;
            fv2 = av2;
            color = aColor;
        }

        public Vertex v0
        {
            get { return fv0; }
        }

        public Vertex v1
        {
            get { return fv1; }
        }

        public Vertex v2
        {
            get { return fv2; }
        }

        /// <summary>
        /// возвращает вектор нормали для плоскости
        /// </summary>
        public Vertex normal
        {
            get { return v1.substract(v0).getVectorMult(v2.substract(v0)); }
        }

        public Vertex normalCam
        {
            get { return v1.Vcam.substract(v0.Vcam).getVectorMult(v2.Vcam.substract(v0.Vcam)); }
        }
    }
}
