﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _3DParallelepiped
{
    public partial class FormMain : Form
    {
        private Color brush = Color.Green;

        public FormMain()
        {
            InitializeComponent();
        }

        private void butGo_Click(object sender, EventArgs e)
        {
            Viewport vp = new Viewport(pictureBoxView.Height, pictureBoxView.Width);
            vp.brush = brush;
            Vertex buf = new Vertex(textBoxBoxSize.Text);
            vp.addBox(buf.getX(), buf.getY(), buf.getZ());
            vp.addCamera(new Camera(new Vertex(textBoxCamPos.Text), new Vertex(textBoxCamDir.Text).substract(new Vertex(textBoxCamPos.Text)), (double)upDownAngle.Value));
            vp.addLight(new LightPoint(new Vertex(textBoxLights.Text)));

            vp.Render();
            pictureBoxView.Image = vp.pic;
        }

        private void btnColor_Click(object sender, EventArgs e)
        {
            colorDialog.ShowDialog();
            brush = colorDialog.Color;
            butGo_Click(sender, e);
        }

        private void FormMain_Paint(object sender, PaintEventArgs e)
        {
            butGo_Click(sender, e);
        }
    }
}
