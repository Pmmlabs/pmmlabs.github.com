﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace CGLab1
{
    class Method
    {
        public static int limit = 128 * 128;
        public delegate void Progress(int i);
        public event Progress OnProgress;
        public delegate void Amount(int i);
        public event Amount OnAmount;
        public delegate void Done(Image img);
        public event Done OnDone;

        public void Sobel(Image img)
        {
            Bitmap b = new Bitmap(img);
            int width = b.Width;
            int height = b.Height;
            OnAmount(height);
            Bitmap res = new Bitmap(width, height);
            int[,] gx = new int[,] { { -1, 0, 1 }, { -2, 0, 2 }, { -1, 0, 1 } };
            int[,] gy = new int[,] { { 1, 2, 1 }, { 0, 0, 0 }, { -1, -2, -1 } };

            int[,] allPixR = new int[width, height];
            int[,] allPixG = new int[width, height];
            int[,] allPixB = new int[width, height];

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    allPixR[i, j] = b.GetPixel(i, j).R;
                    allPixG[i, j] = b.GetPixel(i, j).G;
                    allPixB[i, j] = b.GetPixel(i, j).B;
                }
            }

            int dxR, dyR;
            int dxG, dyG;
            int dxB, dyB;
            int rc, gc, bc;
            for (int j = 1; j < b.Height - 1; j++)
            {
                OnProgress(j);
                for (int i = 1; i < b.Width - 1; i++)
                {
                    dxR = 0; dyR = 0;
                    dxG = 0; dyG = 0;
                    dxB = 0; dyB = 0;
                    rc = 0; gc = 0; bc = 0;

                    for (int wi = -1; wi < 2; wi++)
                    {
                        for (int hw = -1; hw < 2; hw++)
                        {
                            rc = allPixR[i + hw, j + wi];
                            dxR += gx[wi + 1, hw + 1] * rc;
                            dyR += gy[wi + 1, hw + 1] * rc;

                            gc = allPixG[i + hw, j + wi];
                            dxG += gx[wi + 1, hw + 1] * gc;
                            dyG += gy[wi + 1, hw + 1] * gc;

                            bc = allPixB[i + hw, j + wi];
                            dxB += gx[wi + 1, hw + 1] * bc;
                            dyB += gy[wi + 1, hw + 1] * bc;
                        }
                    }
                    if (dxR * dxR + dyR * dyR > limit || dxG * dxG + dyG * dyG > limit || dxB * dxB + dyB * dyB > limit)
                        res.SetPixel(i, j, Color.Black);
                    else
                        res.SetPixel(i, j, Color.White);
                }
            }
            OnDone(res);
        }
    }
}
