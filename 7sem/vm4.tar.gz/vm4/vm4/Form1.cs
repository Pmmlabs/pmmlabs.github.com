﻿using System;
using System.IO;
using System.Windows.Forms;

namespace vm4
{
    public partial class Form1 : Form
    {
        private double A, B, C, Yc, hmin, h, pogrNext, pogrCurr, pogrPred, epsDivK, eps, finPoint, HMinVal, HMaxVal, absPogr, yCurr, yNext, xCurr, xNext;
        private int m, countInaccurPoints;
        public Form1()
        {
            InitializeComponent();
            openFileDialog1.InitialDirectory = Application.StartupPath;
        }

        private void buttonBrowse_Click(object sender, EventArgs e)
        {
            if (DialogResult.OK == openFileDialog1.ShowDialog()) textBox1.Text = openFileDialog1.FileName;
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            if (File.Exists(textBox1.Text))
            {
                if (textBoxSrc.Text.Length > 1)
                {
                    StreamWriter sw = new StreamWriter(textBox1.Text);
                    sw.WriteLine(textBoxSrc.Text);
                    sw.Close();
                }
                else
                {
                    var reader = new StreamReader(textBox1.Text);
                    textBoxSrc.Text = reader.ReadToEnd();
                    reader.Close();
                }
                textBoxRez.Text = "\r\nX\t\tY\t\tВерных знаков";
                Solve(textBox1.Text, "", "rez.txt");
            }
        }
        //вычисление машинного эпсилон
        private static double GetEpsilon()
        {
            double R = 1;
            while ((1 + R) > 1)
                R /= 2;
            return (R * 2);
        }

        //вычисление функции
        double Func(double x, double y)
        {
            return Math.Exp(x);//90 * x * x * x-y*y;// *x;
        }

        //вычисление формулы 4го порядка
        private double CountRGFourth(double x0, double y0, double step)
        {
            /*double k1 = step * Func(x0, y0);
            double k2 = step * Func(x0 + h / 2, y0 + k1 / 2);
            double k3 = step * Func(x0 + h / 2, y0 + k2 / 2);
            double k4 = step * Func(x0 + h, y0 + k3);
            return y0 + (double)1 / 6 * (k1 + 2 * k2 + 2 * k3 + k4);*/
            double k1 = step * Func(x0, y0);
            double k2 = step * Func(x0 + step / 3, y0 + k1 / 3);
            double k3 = step * Func(x0 + step / 3, y0 + k1 / 6 + k2/6);
            double k4 = step * Func(x0 + step / 2, y0 + k1 / 8 - 3 * k3 / 8);
            double k5 = step*Func(x0 + step, y0 + k1/2 - 3*k3/2 + 2*k4);
            double rez=y0 + (k1 + 4 * k4 + k5) / 6;
            return rez;
        }
        //вычисление формулы 3го порядка (10 стр)
        private double CountRGThird(double x0, double y0, double step)
        {
            /*double k1 = step * Func(x0, y0);
            double k2 = step * Func(x0 + h / 3, y0 + k1 / 3);
            double k3 = step * Func(x0 + 2 * h / 3, y0 + 2 * k2 / 3);
            return y0 + (double)1 / 4 * (k1 + 3 * k3); */
            double k1 = step * Func(x0, y0);
            double k2 = step * Func(x0 + step / 3, y0 + k1 / 3);
            double k3 = step * Func(x0 + step / 3, y0 + k1 / 6 + k2 / 6);
            double k4 = step * Func(x0 + step / 2, y0 + k1 / 8 - 3 * k3 / 8);
            double k5 = step * Func(x0 + step, y0 + k1 / 2 - 3 * k3 / 2 + 2 * k4);
            return y0 + (k1 + 3 * k3 + 4 * k4 + 2 * k5) / 10;
        }

        private double CountE(double x0, double y0, double step)
        {
            double k1 = step * Func(x0, y0);
            double k2 = step * Func(x0 + step / 3, y0 + k1 / 3);
            double k3 = step * Func(x0 + step / 3, y0 + k1 / 6 + k2 / 6);
            double k4 = step * Func(x0 + step / 2, y0 + k1 / 8 - 3 * k3 / 8);
            double k5 = step * Func(x0 + step, y0 + k1 / 2 - 3 * k3 / 2 + 2 * k4);
            return (2 * k1 - 9 * k3 + 8 * k4 - k5) / 30;
        }

        //признак конца
        //проверяет, что точка point находится за отрезком просмотра
        private bool IsEnd(double finPoint, double point, double h)
        {
            if (h > 0)
            {
                if (point + h > finPoint) return true;
            }
            else if (point + h < finPoint)
                return true;
            return false;
        }

        private int Solve(string data, string f, string rez)
        {
            if (File.Exists(data))
            {
                var reader = new StreamReader(textBox1.Text);
                string[] str = reader.ReadLine().Split(' ');
                A = Convert.ToDouble(str[0].Replace('.', ','));
                B = Convert.ToDouble(str[1].Replace('.', ','));
                C = Convert.ToDouble(str[2].Replace('.', ','));
                Yc = Convert.ToDouble(str[3].Replace('.', ','));
                Yc = Math.Exp(2);
                str = reader.ReadLine().Split(' ');
                h = Convert.ToDouble(str[0].Replace('.', ','));
                m = Convert.ToInt32(str[1]);
                double hmin = Convert.ToDouble(str[2].Replace('.', ','));
                reader.Close();
                //проверка входных данных
                if ((A >= B) || (hmin <= 10 * GetEpsilon()) || (m <= 0) || (Math.Abs(h) > Math.Abs(A - B))) return 1;
                if (C == A)
                {
                    xCurr = A;
                    finPoint = B;
                }
                else if (C == B)
                {
                    xCurr = B;
                    finPoint = A;
                    h = -h;
                    hmin = -hmin;
                }
                else return 1;
                bool OKModif;
                yCurr = Yc;
                HMinVal = h;
                HMaxVal = h;
                pogrCurr = 0;
                countInaccurPoints = 0;
                eps = 0.5 * Math.Pow(10, 1 - m);
                epsDivK = eps / 16;
                absPogr = 0;
                double epsMethod = 0;
                AddToTextBox(xCurr, yCurr, 100,0,0);
                //пока не дошли до конца отрезка интегрирования
                while (!IsEnd(finPoint, xCurr, h))
                {
                    xNext = xCurr + h;
                    yNext = CountRGThird(xCurr, yCurr, h);
                    pogrNext = Math.Abs(CountRGFourth(xCurr, yCurr, h) - yNext) / Math.Abs(yNext);
                    //absPogr = Math.Abs(CountRGFourth(xCurr, yCurr, h) - yNext);
                    absPogr = Math.Abs(Math.Exp(xCurr) - yNext);
                    epsMethod = CountE(xCurr, yCurr, h);
                    pogrPred = pogrNext + 1;
                    OKModif = false;
                    //если локальная погрешность больше eps
                    if (pogrNext > eps)
                    {
                        //делим шаг пополам
                        while ((pogrNext > eps) && (Math.Abs(h) > Math.Abs(hmin)) /*&& (pogrNext < pogrPred)*/)
                        {
                            h /= 2;
                            if (Math.Abs(h) < Math.Abs(hmin))
                                h = hmin; //предпринимаем попытку нахождения решения с шагом hmin
                            xNext = xCurr + h;
                            yNext = CountRGThird(xCurr, yCurr, h);
                            pogrPred = pogrNext;
                            pogrNext = Math.Abs(CountRGFourth(xCurr, yCurr, h) - yNext) / Math.Abs(yNext);
                            //absPogr = Math.Abs(CountRGFourth(xCurr, yCurr, h) - yNext);
                            absPogr = Math.Abs(Math.Exp(xCurr) - yNext);
                            epsMethod = CountE(xCurr, yCurr, h);
                        }
                        //значение шага стало равным hmin, дальнейшее его уменьшение недопустимо; или процесс последовательного деления шага пополам прекращен, т. к. с уменьшением шага погрешность приближенного решения перестала уменьшаться
                        if (((h == hmin) && (Math.Abs(pogrNext) > eps)) || (pogrNext >= pogrPred))
                            countInaccurPoints++; //точность не достигнута

                        if (pogrNext > pogrPred) pogrNext = pogrPred;
                        OKModif = true; //делили шаг на 2
                        if (Math.Abs(h) < Math.Abs(HMinVal)) HMinVal = h;
                    }

                    if (Math.Abs(h) > Math.Abs(HMaxVal)) HMaxVal = h;
                    //вычисление количества верных знаков
                    if (pogrNext != 0)
                        m = (int)(1 - Math.Log10(2 * pogrNext));
                    else
                        m = 100; //все верные

                    AddToTextBox(xNext, yNext, m, absPogr, epsMethod); //,pogrCurr,absPogr);

                    //проверяем, меняли ли шаг
                    //если не меняли
                    if (!OKModif)
                        //проверяем на eps/k
                        //если локальная погрешность меньше eps/k
                        if (Math.Abs(pogrNext) < epsDivK) h *= 2; //увеличиваем шаг в 2 раза

                    //переходим в следующую точку
                    xCurr = xNext;
                    yCurr = yNext;
                    //pogrCurr = pogrNext;

                    while ((Math.Abs(h)>Math.Abs(hmin)) && (IsEnd(finPoint,xCurr,h)))
                    {
                        h /= 2;
                        if (Math.Abs(h) < Math.Abs(hmin))
                            h = hmin;
                    }
                } //while
                textBoxRez.Text += "\r\nIcod: " + countInaccurPoints.ToString() + "; H min: " + HMinVal.ToString() + "; H max: " + HMaxVal.ToString();
                return countInaccurPoints;
                /* StreamWriter sw = new StreamWriter(rez);
                sw.WriteLine(textBoxRez.Text);
                sw.Close();*/
            }
            return 1;
        }

        private void AddToTextBox(double _xCurr, double _yCurr, int _m, double absPogr, double epsMethod)
        {
            textBoxRez.Text += "\r\n" + _xCurr.ToString("0.####") + "\t\t" + _yCurr.ToString("0.######") + "\t\t" + _m.ToString() + "\t\t" + absPogr.ToString("0.######") + "\t\t" + epsMethod.ToString("0.######");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
