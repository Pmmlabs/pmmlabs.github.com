﻿using System.Globalization;
using System.Windows.Forms;

namespace VM1
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
            var data = new[] { 10, 100, 1000 };
            float zn1, zn2;
            dgvResult.Rows.Add(9);
            for (int i = 0; i < 9; i++)
            {
                dgvResult[0, i].Value = (i + 1).ToString(); // номер
                dgvResult[1, i].Value = data[i % 3].ToString(); // размерность
                dgvResult[2, i].Value = "[-" + data[i / 3].ToString() + ";" + data[i / 3].ToString() + "]"; // диапазон
                Tester.test(20, data[i / 3], data[i % 3], out zn1, out zn2);
                dgvResult[3, i].Value = zn1.ToString();
                dgvResult[4, i].Value = zn2.ToString();
            }
        }
    }
}
