﻿using System;

namespace VM1
{
    class Tester
    {
        static readonly Random rn = new Random();
        static float[] a, b, c, p, q, f;
        static float[] x;

        static void GenerateMas(int kolEquation, float range)
        {
            a = new float[kolEquation - 1];
            b = new float[kolEquation];
            c = new float[kolEquation - 1];
            p = new float[kolEquation];
            q = new float[kolEquation];
            x = new float[kolEquation];
            for (int i = 0; i < kolEquation - 1; i++)
            {
                a[i] = (float) rn.NextDouble() * 2 * range - range;
                b[i] = ((float) rn.NextDouble() * 2 * range - range);
                c[i] = (float) rn.NextDouble() * 2 * range - range;
            }

            b[kolEquation - 1] = (float) rn.NextDouble() * 2 * range - range;

            for (int i = 3; i < kolEquation; i++)
            {
                p[i] = (float) rn.NextDouble() * 2 * range - range;
                q[i] = (float) rn.NextDouble() * 2 * range - range;
            }
            p[2] = (float) rn.NextDouble() * 2 * range - range;
            p[0] = b[0];
            p[1] = c[0];
            q[0] = a[0];
            q[1] = b[1];
            q[2] = c[1];
        }

        static float[] GenerateX(int kolEquation, float range)
        {
            float[] x = new float[kolEquation];
            for (int i = 0; i < kolEquation - 1; i++)
            {
                x[i] = (float) rn.NextDouble() * 2 * range - range;
            }
            return x;
        }

        static float[] GenerateX1(int kolEquation)
        {
            float[] x = new float[kolEquation];
            for (int i = 0; i < kolEquation ; i++)
            {
                x[i] = 1;
            }
            return x;
        }

        static void GenerateF(float[] _x)
        {
            int N = b.Length;
            f = new float[N];
            for (int i = 0; i < N; i++)
            {
                f[0] += p[i]*_x[i];
                f[1] += q[i]*_x[i];
            }

            for (int i = 2; i < N; i++)
            {
                f[i] = a[i - 1]*_x[i-1] + b[i]*_x[i];
                if (i < N - 1)
                    f[i] += c[i]*_x[i+1];
            }
        }

        static int FindAnswer_1stage()
        {
            int N = b.Length;
            float chis;
            for (int i = N - 1; i > 1; i--)
            {
                try
                {
                    if (i < N - 1)
                    {
                        chis = -c[i];
                        b[i] += a[i] * chis;
                        c[i] = 0;
                        f[i] += f[i + 1] * chis;
                    }
                    chis = 1 / b[i];
                    a[i - 1] *= chis;
                    b[i] = 1;
                    f[i] *= chis;

                    chis = -p[i];
                    p[i] = 0;
                    p[i - 1] += a[i - 1] * chis;
                    f[0] += f[i] * chis;

                    chis = -q[i];
                    q[i] = 0;
                    q[i - 1] += a[i - 1] * chis;
                    f[1] += f[i] * chis;
                }
                catch (DivideByZeroException)
                {
                    return i + 1;
                }
            }
            c[0] = p[1];
            b[1] = q[1];
            c[1] = q[2];
            return 0;
        }

        static int FindAnswer_2stage()
        {
            float chis;
            try
            {
                chis = -c[0] / b[1];
                b[0] += a[0] * chis;
                c[0] = 0;
                f[0] += f[1] * chis;

                chis = 1 / b[0];
                b[0] = 1;
                f[0] *= chis;
            }
            catch (DivideByZeroException)
            {
                return 1;
            }

            try
            {
                chis = -a[0];
                a[0] = 0;
                f[1] += chis * f[0];

                chis = 1 / b[1];
                b[1] = 1;
                f[1] *= chis;
            }
            catch (DivideByZeroException)
            {
                return 2;
            }
            return 0;
        }
        
        static int FindAnswer_3stage()
        {
            int N = b.Length;
            for (int i = 2; i < N; i++)
            {
                try
                {
                    f[i] -= (a[i - 1] * f[i - 1]);
                    a[i - 1] = 0;
                }
                catch (DivideByZeroException)
                {
                    return i + 1;
                }
            }

            for (int i = 0; i < N; i++)
            {
                x[i] = f[i];
            }
            return 0;
        }

        public static int SolveSystem(float[] _a, float[] _b, float[] _c, float[] _p, float[] _q, float[] _f, out float[] _x, out float avgMark)
        {
            avgMark = 0;
            int N = x.Length;
            float[] bufa=new float[N];
            float[] bufb=new float[N];
            float[] bufc=new float[N];
            float[] bufp=new float[N];
            float[] bufq = new float[N];
            _a.CopyTo(bufa,0);
            _b.CopyTo(bufb, 0);
            _c.CopyTo(bufc, 0);
            _p.CopyTo(bufp, 0);
            _q.CopyTo(bufq, 0);
            a = _a;
            b = _b;
            c = _c;
            p = _p;
            q = _q;
            f = _f;
            int result = FindAnswer_1stage() + FindAnswer_2stage() + FindAnswer_3stage();
            _x = new float[N];
            x.CopyTo(_x, 0);
            if (result > 0)
                return result;

            a = bufa;
            b = bufb;
            c = bufc;
            p = bufp;
            q = bufq;
            x=GenerateX1(b.Length);
            GenerateF(x);
            result = FindAnswer_1stage() + FindAnswer_2stage() + FindAnswer_3stage();
            if (result > 0)
                return result;
            
            
            for (int i = 0; i < N; i++)
            {
                avgMark=Math.Max(avgMark,Math.Abs(x[i]-1));
            }

            return 0;
        }

        /// <summary />
        /// <param name="kolTests">количество систем, которые надо решить</param>
        /// <param name="range">диапазон значений</param>
        /// <param name="kolEquation">количество уравнений</param>
        /// <param name="epsAvg">средняя относительная погрешность</param>
        /// <param name="avgMark">среднее значение оценки точности</param>
        public static void test(int kolTests, float range, int kolEquation, out float epsAvg, out float avgMark)
        {
            range=Math.Abs(range);
            float[] epsAvgs = new float[kolTests];
            float[] avgMarks=new float[kolTests];
            float[] curX=new float[kolEquation];
            float[] solvedX=new float[kolEquation];
            bool noErr = false;
            float curEps = 0;

            for (int i = 0; i < kolTests; i++)
            {
                avgMarks[i]=0;
                while (!noErr)
                {
                    GenerateMas(kolEquation, range);
                    curX=GenerateX(kolEquation, range);
                    GenerateF(curX);
                    noErr = SolveSystem(a,b,c,p,q,f,out solvedX, out avgMarks[i]) == 0; //если все функции выдали нули, значит ошибки не было
                }
                epsAvgs[i] = 0;
                for (int j = 0; j < kolEquation; j++)
                {
                    epsAvgs[i] = Math.Max(Math.Abs(curX[j] - solvedX[j]), epsAvgs[i]);
                }
            }

            //а теперь считаем средние значения оценок
            epsAvg = 0;
            avgMark = 0;
            for (int i = 0; i < kolTests; i++)
            {
                epsAvg += epsAvgs[i];
                avgMark += avgMarks[i];
            }
            epsAvg /= kolTests;
            avgMark /= kolTests;
        }
 
    }
}
