﻿namespace SolveSystemWithSparseMatrix
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TableMain = new System.Windows.Forms.DataGridView();
            this.NTest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SystemSize = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Diapason = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sred = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Toch = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ButRefresh = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.TableMain)).BeginInit();
            this.SuspendLayout();
            // 
            // TableMain
            // 
            this.TableMain.AllowUserToAddRows = false;
            this.TableMain.AllowUserToDeleteRows = false;
            this.TableMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TableMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TableMain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TableMain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NTest,
            this.SystemSize,
            this.Diapason,
            this.Sred,
            this.Toch});
            this.TableMain.GridColor = System.Drawing.SystemColors.Control;
            this.TableMain.Location = new System.Drawing.Point(12, 25);
            this.TableMain.Name = "TableMain";
            this.TableMain.ReadOnly = true;
            this.TableMain.Size = new System.Drawing.Size(867, 289);
            this.TableMain.TabIndex = 0;
            // 
            // NTest
            // 
            this.NTest.HeaderText = "№ Теста";
            this.NTest.Name = "NTest";
            this.NTest.ReadOnly = true;
            // 
            // SystemSize
            // 
            this.SystemSize.HeaderText = "Размерность системы";
            this.SystemSize.Name = "SystemSize";
            this.SystemSize.ReadOnly = true;
            // 
            // Diapason
            // 
            this.Diapason.HeaderText = "Диапазон значений элементов матрицы";
            this.Diapason.Name = "Diapason";
            this.Diapason.ReadOnly = true;
            // 
            // Sred
            // 
            this.Sred.HeaderText = "Средняя относительная погрешность системы";
            this.Sred.Name = "Sred";
            this.Sred.ReadOnly = true;
            // 
            // Toch
            // 
            this.Toch.HeaderText = "Среднее значение оценки точности";
            this.Toch.Name = "Toch";
            this.Toch.ReadOnly = true;
            // 
            // ButRefresh
            // 
            this.ButRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ButRefresh.Location = new System.Drawing.Point(12, 323);
            this.ButRefresh.Name = "ButRefresh";
            this.ButRefresh.Size = new System.Drawing.Size(108, 27);
            this.ButRefresh.TabIndex = 1;
            this.ButRefresh.Text = "Обновить";
            this.ButRefresh.UseVisualStyleBackColor = true;
            this.ButRefresh.Click += new System.EventHandler(this.ButRefresh_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(891, 362);
            this.Controls.Add(this.TableMain);
            this.Controls.Add(this.ButRefresh);
            this.Name = "Form1";
            this.Text = "Решение систем линейных уравнений с разреженными матрицами специального вида";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TableMain)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView TableMain;
        private System.Windows.Forms.DataGridViewTextBoxColumn NTest;
        private System.Windows.Forms.DataGridViewTextBoxColumn SystemSize;
        private System.Windows.Forms.DataGridViewTextBoxColumn Diapason;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sred;
        private System.Windows.Forms.DataGridViewTextBoxColumn Toch;
        private System.Windows.Forms.Button ButRefresh;
    }
}

