﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
//

namespace SolveSystemWithSparseMatrix
{
    /// <summary> Система уравнений </summary>
    class SystemsOfEquations
    {

        RandomValue e; //Генератор случайных чисел
        /// <summary> Вектора a b c p q представляют разреженную матрицу</summary>
        double[] a, b, c, p, q,
            f, //Вектор правой части уравнения
            f1, //Вектор правой части для единичного ветора
            x, //Численное решение системы
            _x,//точное решение
            _x1,
            x1;

        int n, //Размер матрицы 
            diapason; //Диапазон значений

        static int k;
        //static double[] ; ////единичный вектор

        public SystemsOfEquations(int n, int diapason)
        {
            this.n = n;
            this.diapason = diapason;

            //Инициализация генератора случайныйх чисел
            e = new RandomValue(n); //n -> diapason
            CreateMatrix();
            CreateVector_X();
            CreateVectorF(_x, f);
            CreateVectorX1();
            CreateVectorF(_x1, f1);
        }

        public void Solve()
        {
            Step1();
            Step2();
            Step3();
            Step4();
        }

        //Вычисление относительной погрешности
        public double avgEps(double[] x, double[] _x)
        { //
            double result = Math.Abs((x[0] - _x[0]) / _x[0]);
            double tmp;
            for (int i = 1; i < n; i++)
                if ((tmp = Math.Abs((x[i] - _x[i]) / _x[i])) > result)
                    result = tmp;

            return result;
        }

        /// <summary> Генерация матрицы</summary>
        /// <param name="n"> Размерность системы </param>
        /// <param name="diapason"> Диапазон [-diapason ; +diapason] </param>
        void CreateMatrix()
        {
            a = new double[n];
            b = new double[n];
            c = new double[n];
            p = new double[n];
            q = new double[n];
            x = new double[n];

            for (int i = 0; i < n; i++)
            {
                a[i] = e.NextDouble();
                b[i] = e.NextDouble();
                c[i] = e.NextDouble();
                p[i] = e.NextDouble();
                q[i] = e.NextDouble();
            }

            f = new double[n];
            f1 = new double[n];
            x1 = new double[n];
            _x1 = new double[n];

            a[0] = 0;
            c[n - 1] = 0;

            if (k != 0)
                p[k - 1] = a[k]; 
            
            p[k] = b[k]; 
            p[k + 1] = c[k];
            q[k] = a[k + 1];
            q[k + 1] = b[k + 1];
         

            if (k != n-2)
                q[k + 2] = c[k + 1];
        }

        /// <summary> Создание вектора _х Точного решения </summary>
        void CreateVector_X()
        {
            _x = new double[n];
            for (int i = 0; i < n; i++)
                //_x[i] = e.NextDouble();
                _x[i] = 1.0;
        }

        //Задать вектор точного решения
        void SetVector_X(double[] _x)
        {
            this._x = _x;
            //CreateVectorF(_);
        }

        /// <summary> Создание вектора f (Правой части A*_x = f) </summary>
        void CreateVectorF(double[] _x,double[] f)
        {
            f[0] = b[0] * _x[0] + c[0] * _x[1];
            for (int i = 1; i < k; i++)
                f[i] = a[i] * _x[i - 1] + b[i] * _x[i] + c[i] * _x[i + 1];

            f[k] = 0;
            f[k + 1] = 0;
            for (int i = 0; i < n; i++)
            {
                f[k] += p[i] * _x[i];
                f[k + 1] += q[i] * _x[i];
            }

            for (int i = k + 2; i < n - 1; i++)
                f[i] = a[i] * _x[i - 1] + b[i] * _x[i] + c[i] * _x[i + 1];
            f[n - 1] = a[n - 1] * _x[n - 2] + b[n - 1] * _x[n - 1];
        }

        /// <summary>  Создание единичного вектора </summary>
        void CreateVectorX1()
        {
            _x1 = new double[n];
            for (int i = 0; i < n; i++)
                _x1[i] = 1.0;
        }

        /// <summary> 
        /// Уравнения с 0 по (k – 1) приводятся к двучленному виду с одновременным исключением неизвестных x1, x2 ,…, xk−1, из k-го и k+1 -го уравнений.
        /// </summary>
        void Step1()
        {
            double R;
            for (int i = 0; i < k; i++)
            { //!!!!!!!!!
                //iю строку делим на b[i] 
                R = 1 / b[i];
                b[i] = 1;
                c[i] = R * c[i];
                f[i] = R * f[i];
                f1[i] = R * f1[i]; //!!!!

                //Избавляемся от a[i+1]
                if (i + 1 != k)
                {
                    R = a[i + 1];
                    a[i + 1] = 0;
                    b[i + 1] = b[i + 1] - R * c[i];
                    f[i + 1] = f[i + 1] - R * f[i];
                    f1[i + 1] = f1[i + 1] - R * f1[i]; //!!!
                }

                //Избавляемся от p[i]
                R = p[i];
                p[i] = 0;
                p[i + 1] = p[i + 1] - R * c[i];
                f[k] = f[k] - R * f[i];
                f1[k] = f1[k] - R * f1[i];

                //Избавляемся от q[i]
                R = q[i];
                q[i] = 0;
                q[i + 1] = q[i + 1] - R * c[i];
                f[k + 1] = f[k + 1] - R * f[i];
                f1[k + 1] = f1[k + 1] - R * f1[i];
            }
        }

        /// <summary> 
        /// Уравнения с n по (k + 2) приводятся к двучленному виду с одновременным исключением неизвестных xn , xn−1,…, xk+2 из k-го и k+1-го уравнений.
        /// </summary>
        void Step2() {
            double R;
            for (int i = n - 1; i >= k + 2; i--)
            {
                //Делим iю строку на b[i]
                R = 1 / b[i];
                b[i] = 1;
                a[i] = a[i] * R;
                f[i] = f[i] * R;
                f1[i] = f1[i] * R;

                if (i - 1 != k + 1)
                {
                    R = c[i - 1];
                    c[i - 1] = 0;
                    b[i - 1] = b[i - 1] - R * a[i];
                    f[i - 1] = f[i - 1] - R * f[i];
                    f1[i - 1] = f1[i - 1] - R * f1[i];
                }


                R = q[i];
                q[i] = 0;
                q[i - 1] = q[i - 1] - R * a[i];
                f[k + 1] = f[k + 1] - R * f[i];
                f1[k + 1] = f1[k + 1] - R * f1[i];

                R = p[i];
                p[i] = 0;
                p[i - 1] = p[i - 1] - R * a[i]; ///
                f[k] = f[k] - R * f[i];
                f1[k] = f1[k] - R * f1[i];
            }
        }

        /// <summary>
        /// На этом шаге преобразуются уравнения k и k+1, которые содержат только слагаемые xk и xk+1 .
        /// </summary>
        void Step3()
        {
            double R;

            R = 1 / p[k];
            p[k] = 1;
            p[k + 1] = R * p[k + 1];
            f[k] = R * f[k];
            f1[k] = R * f1[k];


            R = q[k];
            q[k] = 0;
            q[k + 1] = q[k + 1] - R * p[k + 1];
            f[k + 1] = f[k + 1] - R * f[k];
            f1[k + 1] = f1[k + 1] - R * f1[k];

            R = 1 / q[k + 1];
            q[k + 1] = 1;
            f[k + 1] = R * f[k + 1];
            f1[k + 1] = R * f1[k + 1];
        }

        /// <summary>
        /// Определение неизвестных
        /// </summary>
        void Step4()
        {
            if (k != 0)
                a[k] = p[k - 1];
            b[k] = p[k];
         
            c[k] = p[k + 1];

            a[k + 1] = q[k];
            b[k + 1] = q[k + 1];
            if (k!= n-2)
                c[k + 1] = q[k + 2];

            //определение неизвестных x1 … xk+1
            x[k + 1] = f[k + 1];
            x1[k + 1] = f1[k + 1];
            for (int i = k; i >= 0; i--)
            {
                x[i] = f[i] - c[i] * x[i + 1];
                x1[i] = f1[i] - c[i] * x1[i + 1];
            }

            //определение неизвестных xk+2 … xn
            for (int i = k + 2; i < n; i++)
            {
                x[i] = f[i] - a[i] * x[i - 1];
                x1[i] = f1[i] - a[i] * x1[i - 1];
            }
        }

        //Решить систему для единичного вектора
        public void SolveForIdentityVector()
        {
            for (int i = 0; i < n; i++)
                _x[i] = 1.0;
            CreateVectorF(_x, f);
            Solve();
        }

        /// <summary> Решение заданной системы </summary>
        /// <param name="testCount"> Количество решаемых систем </param>
        /// <param name="diapason"> Диапазон значений </param>
        /// <param name="k"> Номер строки k </param>
        /// <param name="n"> Размерность системы </param>
        /// <param name="epsAvg"> Выходной параметр - Средняя относительная погрешность системы </param>
        /// <param name="markAvg"> Выходной параметр - Среднее значение оценки точности </param>
        public static void TestSystem(int testCount, int diapason, int k, int n, out double epsAvg, out double markAvg)
        {
            SystemsOfEquations.k = n-2;

            double[] epsAvgVector = new double[testCount];
            double[] markAvgVector = new double[testCount];
            SystemsOfEquations system = new SystemsOfEquations(n, diapason);
            for (int i = 0; i < testCount; i++)
            {
                //system.CreateMatrix();
                Thread.Sleep(1);
                system = new SystemsOfEquations(n, diapason);
                system.Solve();
                epsAvgVector[i] = system.avgEps(system._x, system.x);

                //system.SolveForIdentityVector();
                markAvgVector[i] = system.avgEps(system._x1, system.x1);
            }

            double epsAvgSum = 0;
            double markAvgSum = 0;
            for (int i = 0; i < testCount; i++)
            {
                epsAvgSum += epsAvgVector[i];
                markAvgSum += markAvgVector[i];
            }

            epsAvg = epsAvgSum / testCount;
            markAvg = markAvgSum / testCount;
        }
    }

    /// <summary> Класс, возвражающий случайное значение из заданного диапазона </summary>
    class RandomValue : Random
    {
        int _diapason;

        public RandomValue(int diapason)
            : base()
        {
            _diapason = diapason;
        }

        public override double NextDouble()
        {
            double tmp = (tmp = _diapason * (base.NextDouble() * 2 - 1)) == 0.0 ? double.Epsilon : tmp;
            return tmp;
        }
    }
}