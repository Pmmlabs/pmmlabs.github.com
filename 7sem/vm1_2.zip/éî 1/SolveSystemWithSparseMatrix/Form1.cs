﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SolveSystemWithSparseMatrix
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
            //ButRefresh.Dock = DockStyle.Bottom;
            Loadin();
        }

        public void Loadin() {
            int []diapasons = new int[3] { 10, 100, 1000};
            int []sizes     = new int[3] { 10, 100, 1000 };
            double epsAvg, markAvg;
            
            TableMain.Rows.Clear();
            TableMain.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill ;
            //TableMain.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
            for (int i = 0; i < 3; i ++ ) {
                for (int j = 0; j < 3; j++) {
                    SystemsOfEquations.TestSystem(10, diapasons[j], 4, sizes[i], out epsAvg, out markAvg);
                    TableMain.Rows.Add();
                    TableMain[0, i * 3 + j].Value = i * 3 + j +1 ;
                    TableMain[1, i * 3 + j].Value = sizes[i].ToString();
                    TableMain[2, i * 3 + j].Value = String.Format("[-{0} +{0}]", diapasons[j].ToString());
                    TableMain[3, i * 3 + j].Value = epsAvg.ToString();
                    TableMain[4, i * 3 + j].Value = markAvg.ToString();
                }
            }       
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void ButRefresh_Click(object sender, EventArgs e) {
            Loadin();
        }
    }
}
