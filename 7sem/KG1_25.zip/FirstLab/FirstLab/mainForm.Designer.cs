﻿namespace FirstLab
{
    partial class mainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbPlot = new System.Windows.Forms.PictureBox();
            this.btPerform = new System.Windows.Forms.Button();
            this.lbScale = new System.Windows.Forms.Label();
            this.nudScale = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.pbPlot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudScale)).BeginInit();
            this.SuspendLayout();
            // 
            // pbPlot
            // 
            this.pbPlot.Location = new System.Drawing.Point(12, 12);
            this.pbPlot.Name = "pbPlot";
            this.pbPlot.Size = new System.Drawing.Size(467, 467);
            this.pbPlot.TabIndex = 0;
            this.pbPlot.TabStop = false;
            // 
            // btPerform
            // 
            this.btPerform.Location = new System.Drawing.Point(387, 485);
            this.btPerform.Name = "btPerform";
            this.btPerform.Size = new System.Drawing.Size(91, 33);
            this.btPerform.TabIndex = 1;
            this.btPerform.Text = "Plot";
            this.btPerform.UseVisualStyleBackColor = true;
            this.btPerform.Click += new System.EventHandler(this.btPerform_Click);
            // 
            // lbScale
            // 
            this.lbScale.AutoSize = true;
            this.lbScale.Location = new System.Drawing.Point(12, 485);
            this.lbScale.Name = "lbScale";
            this.lbScale.Size = new System.Drawing.Size(40, 13);
            this.lbScale.TabIndex = 3;
            this.lbScale.Text = "Scale: ";
            // 
            // nudScale
            // 
            this.nudScale.Location = new System.Drawing.Point(135, 484);
            this.nudScale.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nudScale.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nudScale.Name = "nudScale";
            this.nudScale.Size = new System.Drawing.Size(120, 20);
            this.nudScale.TabIndex = 4;
            this.nudScale.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nudScale.ValueChanged += new System.EventHandler(this.nudScale_ValueChanged);
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(490, 530);
            this.Controls.Add(this.nudScale);
            this.Controls.Add(this.lbScale);
            this.Controls.Add(this.btPerform);
            this.Controls.Add(this.pbPlot);
            this.Name = "mainForm";
            this.Text = "FirstLab";
            ((System.ComponentModel.ISupportInitialize)(this.pbPlot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudScale)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbPlot;
        private System.Windows.Forms.Button btPerform;
        private System.Windows.Forms.Label lbScale;
        private System.Windows.Forms.NumericUpDown nudScale;
    }
}

