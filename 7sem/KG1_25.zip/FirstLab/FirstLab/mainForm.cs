﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FirstLab
{
    public partial class mainForm : Form
    {
        Graphics gr;
        double scale = 5;
        public mainForm()
        {
            InitializeComponent();
            lbScale.Text = "Scale: " + scale.ToString();
        }

        private void btPerform_Click(object sender, EventArgs e)
        {
            gr = new Graphics(pbPlot.Width, pbPlot.Height, scale, Color.Black, Color.Red);
            pbPlot.Image = gr.Plot(x => 25 * Math.Sin(x));
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            lbScale.Text = "Scale: " + scale.ToString();
        }

        private void SetScale()
        {
            scale = (double)nudScale.Value;
            lbScale.Text = "Scale: " + scale.ToString("F3");
        }

        private void cbReverse_CheckedChanged(object sender, EventArgs e)
        {
            SetScale();
        }

        private void nudScale_ValueChanged(object sender, EventArgs e)
        {
            SetScale();
        }
    }
}
