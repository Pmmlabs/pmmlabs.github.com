﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstLab
{
    class Graphics
    {
        int width; //ширина канвы
        int height; //высота
        double scale; //масштаб
        Color axisColor, plotColor; //цвета (оси и графика)
        Bitmap bitmap; //изображение, на котором рисуем
        int startX, startY; //начало координат

        public Graphics(int width, int height, double scale, Color axisColor, Color plotColor)
        {
            this.width = width;
            this.height = height;
            this.scale = scale;
            this.axisColor = axisColor;
            this.plotColor = plotColor;
            bitmap = new Bitmap(width, height);
            startX = width / 2; //начало координат находится на середине изображения
            startY = height / 2;
        }

        //отрисовываем пиксель с проверкой выхода за границы изображения
        //если вышел - считаем, что был установлен на край 
        //(чтобы приблизительно отрисовать линию до следующей точки)
        private bool DrawPixel(int x, ref int y)
        {
            if (y < 0)
            {
                y = 0;
            }
            else if (y >= height)
            {
                y = height - 1;
            }
            else
            {
                bitmap.SetPixel(x, y, plotColor);
                return true;
            }
            return false;
        }

        //отрисовка оси X
        private void DrawAxisX()
        {
            //отрисовка оси
            for(int i = 0; i < width; ++i)
            {
                bitmap.SetPixel(i, startY, axisColor);
            }

            //отрисовка засечек (на интервале в 1)
            for(int i = (int)scale; i < startX; i += (int)scale)
            {
                for(int j = startY - 4; j <= startY + 4; ++j)
                {
                    bitmap.SetPixel(startX + i, j, axisColor);
                    bitmap.SetPixel(startX - i, j, axisColor);
                }
            }
        }

        //отрисовка оси Y
        private void DrawAxisY()
        {
            for (int i = 0; i < height; ++i)
            {
                bitmap.SetPixel(startX, i, axisColor);
            }

            for (int i = (int)scale; i < startY; i += (int)scale)
            {
                for (int j = startX - 4; j <= startX + 4; ++j)
                {
                    bitmap.SetPixel(j, startY + i, axisColor);
                    bitmap.SetPixel(j, startY - i, axisColor);
                }
            }
        }


        public Bitmap Plot(Func<double, double> func)
        {
            DrawAxisX();
            DrawAxisY();

            //аргумент функции смещаем (тк начало координат не в нуле)
            //затем масштабируем аргумент (делим)
            //получаем значение функции, потом масштабируем назад (умножаем)
            //затем снова смещаем
            int yOld = startY - (int)(func((0 - startX) / scale) * scale);

            DrawPixel(0, ref yOld);

            for(int i = 1; i < width; ++i)
            {
                //аналогично первому значению высчитываем остальные
                int yNew = startY - (int)Math.Round(func((i - startX) / scale) * scale);
                //если получилось нарисовать (значение функции не вышло за границы изображения)
                if (DrawPixel(i, ref yNew)) 
                {
                    //то среди предыдущего и текущего значения определяем большее и меньшее
                    int yMax = Math.Max(yOld, yNew);
                    int yMin = Math.Min(yOld, yNew);

                    //чертим вертикальную линию так, 
                    //чтобы она касалась одного из значений сверху (или снизу),
                    //а другого справа (или слева)
                    for (int j = yMin; j <= yMax; ++j)
                    {
                        bitmap.SetPixel(i - 1, j, plotColor);
                    }

                    yOld = yNew;
                }
            }
            return bitmap;
        }
    }
}
