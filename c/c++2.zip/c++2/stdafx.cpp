// stdafx.cpp : source file that includes just the standard includes
// c++2.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"
#include <string>
#include <iostream>
using namespace std;
void prompt(string s)
{
	cout<<s;
}

