#include "Fractionn.h"


Fractionn::Fractionn(void)
{
}


Fractionn::~Fractionn(void)
{
}
