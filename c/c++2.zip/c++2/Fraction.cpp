#include "Fraction.h"

int intpow (int ar, unsigned int p)
{
	if(!p) return 1;
	else return ar*intpow(ar,p-1);
}

int poryadok(unsigned short int * divpart1, unsigned short int * divpart2)
{
	int k1=1,k2=1;
	int tempDivPart1=*divpart1;
	int tempDivPart2=*divpart2;
	while (tempDivPart1 / 10 != 0 ) 
	{ 
		tempDivPart1=tempDivPart1/10;
		k1++;
	}
	while (tempDivPart2 / 10 != 0 ) 
	{ 
		tempDivPart1=tempDivPart1/10;
		k2++;
	}
	if (k1>k2)
	{

		*divpart2*=intpow(10,(k1-k2));
		k2=k1;
	}
	else if (k2>k1) 
	{
		*divpart1*=intpow(10,(k2-k1));
		k1=k2;
	}
	return k1;

}