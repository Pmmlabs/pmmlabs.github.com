#pragma once
class Pair
{
protected:
	 unsigned short int a;
     unsigned short int b;
	 long int x;
public:
	Pair(void);
	~Pair(void);
	unsigned short int getA()
	{
		return a;
	}
	unsigned short int getB()
	{
		return b;
	}
	long int getX()
	{
		return x;
	}
     virtual void input() = 0;
	 virtual void output() = 0;
     virtual void add(Pair *p) = 0;
     virtual void sub(Pair *p) = 0;
     virtual void mul(Pair *p) = 0;
	
     virtual void equ(Pair *p) = 0;
};

