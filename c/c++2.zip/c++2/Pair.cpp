#include "Pair.h"


Pair::Pair(void)
{
}


Pair::~Pair(void)
{
}
