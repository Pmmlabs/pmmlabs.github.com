// c++1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "TPoint.h"
#include <string>
#include <sstream>
using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{ 
	TPoint p;
	int k;
	do {
		cout<<"--Menu:\n"
			<<"1.Read\n"
			<<"2.Display\n"
			<<"3.ToString\n"
			<<"4.Move\n"
			<<"5.Distance\n"
			<<"6.DistanceToCenter\n"
			<<"7.ToPolar\n"
			<<"8.Equal\n"
			<<"0.Exit\n"
			<<"Your choise: ";
		cin>>k;
		switch(k)
		{
		case 1:		p.Read();		break;
		case 2:		p.Display();	break;
		case 3:		cout<<p.ToString()<<endl;	break;
		case 4:		
			{
				int dx,dy;
				cout<<"Enter dx: ";
				cin>>dx;
				cout<<"Enter dy: ";
				cin>>dy;
				p.Move(dx,dy);
			} break;
		case 5:
			{
			TPoint p2;
			p2.Read();
			cout<<"Distance to point: "<<p.Distance(p2)<<endl;
			} break;
		case 6: cout<<"Distance to center: "<<p.DistanceToCenter()<<endl; break;
		case 7: p.ToPolar(); break;
		case 8: 
			{
			TPoint p2;
			p2.Read();
			if (p.Equal(p2)) cout<<"they equals!"<<endl;
			else cout<<"they not equals"<<endl;
			} break;
		case 0: cout<<"Now exit"; break;
		default:	cout<<"error inputing,try again"<<endl;
		}
	} while (k!=0);
	return 0;
}

