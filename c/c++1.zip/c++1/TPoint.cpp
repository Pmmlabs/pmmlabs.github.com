#include "TPoint.h"
#include <string>
#include <sstream>
//#include <cmath>

TPoint::TPoint(void)
{
	Init();
}


TPoint::~TPoint(void)
{
}

void TPoint::Read()
{
	cout<<"X: ";
	cin>>x;
	cout<<endl;
	cout<<"Y: ";
	cin>>y;
	cout<<endl;
}

string TPoint::ToString()
{
	stringstream s;
	string str;
   	s << "x="<< x << ";y="<< y<<endl;
	s>>str;
	return str;
}

double TPoint::Distance(TPoint _point)
{
	double r=(x-_point.GetX())*(x-_point.GetX())+(y-_point.GetY())*(y-_point.GetY());
	return sqrt (r);
}

double TPoint::DistanceToCenter()
{
	double r=x*x+y*y;
	return sqrt (r);
}

void TPoint::ToPolar()
{
	cout<< "r= "<<DistanceToCenter()<<endl;
	double xf=static_cast<double>(x);
	double yf=static_cast<double>(y);
	double f=atan2(yf,xf);
	cout<< "f= "<<f; 
}
bool TPoint::Equal(TPoint _point)
{
	return x==_point.GetX() && y==_point.GetY();
}