#pragma once
#include <iostream>
using namespace std;
class TPoint
{
private: int x,y;
public:
	TPoint(void);
	~TPoint(void);
	void Init() { x=0; y=0; }
	void Read(); 
	void Display() {cout<<"x: "<<GetX()<<", y: "<<GetY()<<endl;}
	string ToString();
	void SetX(int _x) {x=_x;}
	void SetY(int _y) {y=_y;}
	void SetPoint(int _x,int _y) {x=_x;y=_y;}
	int GetX() {return x;}
	int GetY() {return y;}
	void Move(int _dx,int _dy) {x+=_dx;y+=_dy;}
	double Distance(TPoint _point);
	double DistanceToCenter();
	void ToPolar();
	bool Equal(TPoint _point);
};

