// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"
#include <stdio.h>
#include <tchar.h>
typedef 	struct 
	{
		int day;
		int month;
		int year;
	}TBirthday;
typedef struct 
	{
		int postcode;
		char country[255];
		char state[255];
		char city[255];
		char street[255];
		int house;
		int kvartira;
	}TAddres;
typedef struct 
{
	char name[255];
	char secondname[255];
	int ismale;
	char nation[255];
	char religion[255];
	int height;
	int weight;
    TBirthday birthday;
	int phone;
	TAddres addres;
}THuman;
int input_birthday(TBirthday * abirthday);
int input_addres(TAddres * aaddres);
THuman input_human();
int print_human(THuman * ahuman);
int input_mas(THuman ** Mas);
int print_mas(int n,THuman * Mas);
int add_rec(THuman * Mas, int* n);
int mas_to_file(int n,THuman * Mas);
int file_to_mas(THuman ** Mas);
int search(int n,THuman * Mas);