// number3.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#define maxN 255

int _tmain(int argc, _TCHAR* argv[])
{
	char s[maxN],a[maxN];
	int k=0,i;
	scanf("%s",&s);
	for (i=0;i<maxN;i++) 
		if (((s[i]>='A') && (s[i]<='I')) || ((s[i]>='a') && (s[i]<='i'))) 
		{
			if (((s[i]>='a') && (s[i]<='i')))
				a[k]=s[i]-('a'-'A');
			else a[k]=s[i];
			k++;
		}
		a[k]='\0';
		i=k=0;
		char x;
		while (a[i]!='\0')
		{
			k=i;
			x=a[i];
			for (int j=i+1;a[j]!='\0';j++)
			{
				if (a[j]<x)
				{
					k=j;
					x=a[k];
				}
			}
			a[k]=a[i];
			a[i]=x;
			i++;
		}
		printf("%s\n",a);
		return 0;
}

