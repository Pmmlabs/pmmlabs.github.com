﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5task3
{
    delegate bool CheckDelegate<K, V>(IEntry<K, V> source);
    delegate void ActionDelegate<K, V>(IEntry<K, V> source);
    delegate IMap<K, V> MapConstructorDelegate<K, V>();
    class MapUtils
    {
        public static bool Exists<K, V>(IMap<K, V> sourcemap, CheckDelegate<K, V> del)
        {
            foreach (IEntry<K, V> i in sourcemap)
            {
                if (del(i)) return true;
            }
            return false;
        }
        public static IMap<K, V> FindAll<K, V>(IMap<K, V> sourcemap, CheckDelegate<K, V> checkdel, MapConstructorDelegate<K, V> constdel)
        {
            IMap<K, V> temp = constdel();
            foreach (IEntry<K, V> i in sourcemap)
            {
                if (checkdel(i)) temp.Put(i.Key, i.Value);
            }
            return temp;
        }
        public static void ForEach<K, V>(IMap<K, V> sourcemap, ActionDelegate<K, V> del)
        {
            foreach (IEntry<K, V> i in sourcemap) del(i);
        }
        public static bool CheckForAll<K, V>(IMap<K, V> sourcemap, CheckDelegate<K, V> del)
        {
            if (sourcemap.isEmpty) return false;
            else
            {
                bool OK = true;
                foreach (IEntry<K, V> i in sourcemap)
                {
                    OK = OK && del(i);
                }
                return OK;
            }
        }

        public static MapConstructorDelegate<K, V> ArrayMapConstructor<K, V>()
        {
            return new MapConstructorDelegate<K, V>(Activator.CreateInstance<ArrayMap<K, V>>);
        }
        public static MapConstructorDelegate<K, V> LinkedMapConstructor<K, V>()
        {
            return new MapConstructorDelegate<K, V>(Activator.CreateInstance<LinkedMap<K, V>>);
        }
        public static MapConstructorDelegate<K, V> HashMapConstructor<K, V>()
        {
            return new MapConstructorDelegate<K, V>(Activator.CreateInstance<HashMap<K, V>>);
        }
    }
}
