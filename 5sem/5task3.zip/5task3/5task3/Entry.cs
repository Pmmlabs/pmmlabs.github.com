﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5task3
{
    class Entry<K, V> : IEntry<K, V>
    {
        K key;
        V val;
        public K Key
        {
            get
            { 
                return key;
            }
            set
            {
                key = value;
            }
        }
        public V Value
        {
            get
            {
                return val;
            }
            set
            {
                val = value;
            }
        }
    }
}
