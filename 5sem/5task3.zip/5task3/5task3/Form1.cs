﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;

namespace _5task3
{
    public partial class FormMain : Form
    {
        IMap<int, string> a;
        public FormMain()
        {
            InitializeComponent(); 
            cbBase.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (cbBase.SelectedIndex == 0)
            {
                 a = new ArrayMap<int, string>();
            }
            else if (cbBase.SelectedIndex == 1)
            {
                 a = new LinkedMap<int, string>();
            }
            else if (cbBase.SelectedIndex == 2)
            {
                a = new HashMap<int, string>();
            }
            else if (cbBase.SelectedIndex == 3)
            {
                if (a != null) a = new UnmutableMap<int, string>(a);
                else a = new UnmutableMap<int, string>();
            }
            MainPanel.Visible = true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (tAddKey.Text != "" && tAddValue.Text != "")
                try
                {
                    a.Put(Convert.ToInt32(tAddKey.Text), tAddValue.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                a.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (tCheckKey.Text != "" && a.ContainsKey(Convert.ToInt32(tCheckKey.Text)))
                    MessageBox.Show("Такой ключ присутствует в множестве");
                else MessageBox.Show("Такой ключ отсутствует в множестве");
            }
            catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
            if (tCheckValue.Text != "" && a.ContainsValue(tCheckValue.Text))
                MessageBox.Show("Такое значение присутствует в множестве");
            else MessageBox.Show("Такое значение отсутствует в множестве");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                if (tRemove.Text != "") a.Remove(Convert.ToInt32(tRemove.Text));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                MessageBox.Show("Количество элементов: " + a.Count);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                if (a.isEmpty) MessageBox.Show("Множество пусто");
                else MessageBox.Show("Множество не пусто");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            try
            {
                if (tIndex.Text != "")
                {
                    string value = a[Convert.ToInt32(tIndex.Text)];
                    if (value != null) MessageBox.Show(value); else MessageBox.Show("Элемента с таким ключом не существует!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Элемента с таким ключом не существует!\n"+ex.Message);
            }
        }
        bool EqualStrings<K, V>(IEntry<K, V> source)
        {
            if (source.Value == null || source.Key == null) return false;
            else return source.Key.ToString().Equals(source.Value.ToString());
        }
        void ToDefault<K, V>(IEntry<K, V> source)
        {
            source.Value = default(V);
        }
        // Exists
        private void button9_Click(object sender, EventArgs e)
        {
            CheckDelegate<int, String> d = new CheckDelegate<int, String>(EqualStrings);
            if (MapUtils.Exists<int, string>(a, d)) MessageBox.Show("Элемент, удовлетворяющий условию, присутствует в множестве");
            else MessageBox.Show("Элемент, удовлетворяющий условию, отсутствует в множестве");
        }
// ForEach
        private void button10_Click(object sender, EventArgs e)
        {
            ActionDelegate<int, string> d = new ActionDelegate<int, string>(ToDefault);
            MapUtils.ForEach<int, string>(a, d);
        }
// CheckForAll
        private void button11_Click(object sender, EventArgs e)
        {
            CheckDelegate<int, String> d = new CheckDelegate<int, String>(EqualStrings);
            if (MapUtils.CheckForAll<int, string>(a, d)) MessageBox.Show("Все элементы множества удовлетворяют условию");
            else MessageBox.Show("Не все элементы множества удовлетворяют условию");
        }
// FindAll
        private void button12_Click(object sender, EventArgs e)
        {
            CheckDelegate<int, String> d = new CheckDelegate<int, String>(EqualStrings);
            IMap<int, string> b = MapUtils.FindAll<int, string>( a, d, MapUtils.LinkedMapConstructor<int,string>());
            a = b;
        }
    }
}
