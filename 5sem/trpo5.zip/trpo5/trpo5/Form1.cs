﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace trpo5
{
    public partial class Form1 : Form
    {
        bool ASC;
        int FileSize;
        string FileName = "input.txt";
        const int buffsize = 1000;
        public Form1()
        {
            InitializeComponent();
        }
        // Фукнция выгрузки чисел из файла в MemoOut
        int LoadFromFileToMemo(TextBox Memo)
        {
            Memo.Clear();
            FileStream inputStream = File.OpenRead(FileName);
            inputStream.Seek(0, SeekOrigin.Begin);
            FileSize = (int)inputStream.Length;
            byte[] buff = new byte[FileSize];
            for (int i = 0; i < FileSize; i++)
            {
                inputStream.Read(buff, i, 1);
                Memo.Text += buff[i].ToString() + " ";
            }
            inputStream.Close();
            return 0;
        }
        //---------------------------------------------------------------------------
        //сортировка массива простыми вставками
        bool InsertionSort(ref byte[] a, int N, bool RANK = true)
        {
            bool b = false;
            for (int i = 1; i < N; i++)
            {
                byte newElement = a[i];
                int location = i - 1;

                while (location >= 0 && (RANK ? a[location] > newElement : a[location] < newElement))
                {
                    a[location + 1] = a[location];
                    location--;
                    b = true;
                }
                a[location + 1] = newElement;
            }
            return b;
        }
        //---------------------------------------------------------------------------
        // Сортировка Шелла
        int ShellSort(int ClusterSize)
        {
            if (ClusterSize <= 0)
            {
                MessageBox.Show("Недопустимый размер кластера.");
                return 0;
            }
            FileStream inputStream = new FileStream(FileName, FileMode.Open, FileAccess.ReadWrite);
            int CountNum = FileSize,
                CountBlock = CountNum / ClusterSize,
                CountRest = CountNum % ClusterSize;
            byte[] array = new byte[buffsize], tempbuf = new byte[buffsize];

            if (CountRest != 0) CountBlock++;
            // Вычисление первого шага.
            int h = 1;
            while (h < CountBlock) h = 2 * h + 1;
            h /= 2;

            inputStream.Seek(0, SeekOrigin.Begin);
            if (CountNum <= 2 * ClusterSize)
            {
                inputStream.Read(array, 0, FileSize);
                InsertionSort(ref array, FileSize, ASC);
                inputStream.Seek(0, SeekOrigin.Begin);
                inputStream.Write(array, 0, FileSize);
            }
            else
            {
                while (h > 0)
                {
                    for (int i = 0; i < CountBlock / h - 1; i++)
                    {
                        inputStream.Seek(i * ClusterSize, SeekOrigin.Begin);
                        inputStream.Read(array, 0, ClusterSize);
                        inputStream.Seek((i + 1) * h * ClusterSize, SeekOrigin.Begin);
                        int kRead = ClusterSize;
                        int temp;
                        do
                        {
                            temp = inputStream.ReadByte();
                            if (temp != -1)
                            {
                                array[kRead] = Convert.ToByte(temp);
                                kRead++;
                            }
                        }
                        while (temp != -1 && kRead < 2 * ClusterSize);
                        if (InsertionSort(ref array, kRead, ASC))
                        {// записываем правую часть array 
                            inputStream.Seek((i + 1) * h * ClusterSize, SeekOrigin.Begin);
                            inputStream.Write(array, ClusterSize, kRead - ClusterSize);
                            // перекидываем левую часть array в правую tempbuf
                            for (int k = 0; k < ClusterSize; k++)
                                tempbuf[ClusterSize + k] = array[k];
                            int j = i - 1;
                            bool b = true;
                            while (j > -1 && b)
                            { //считываем в левую часть tempbuf
                                inputStream.Seek(j * ClusterSize, SeekOrigin.Begin);
                                inputStream.Read(tempbuf, 0, ClusterSize);
                                b = InsertionSort(ref tempbuf, 2 * ClusterSize, ASC);
                                if (b)
                                { // записываем правую часть tempbuf на j+1
                                    inputStream.Seek((j + 1) * ClusterSize, SeekOrigin.Begin);
                                    inputStream.Write(tempbuf, ClusterSize, ClusterSize);
                                    // перекидывам левую часть tempbuf в правую
                                    for (int k = 0; k < ClusterSize; k++)
                                        tempbuf[ClusterSize + k] = tempbuf[k];
                                }
                                j--;
                            }
                            if (j == -1 && b)// записываем правую часть tempbuf на нулевое место
                            {
                                inputStream.Seek(0 * ClusterSize, SeekOrigin.Begin);
                                inputStream.Write(tempbuf, ClusterSize, ClusterSize);
                            }
                            if (!b)
                            {
                                inputStream.Seek((j + 2) * ClusterSize, SeekOrigin.Begin);
                                inputStream.Write(tempbuf, ClusterSize, ClusterSize);
                            }
                        }
                    } 
                    h /= 2; 
                }  // end of while
            } // end of else
            inputStream.Flush();
            inputStream.Close();
            return 0;
        }
        //---------------------------------------------------------------------------
        private void button1_Click(object sender, EventArgs e)
        {
            ASC = radioButton1.Checked == true;
            LoadFromFileToMemo(MemoIn);
            ShellSort(Convert.ToInt32(textBox3.Text));
            LoadFromFileToMemo(MemoOut);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FileStream f = new FileStream(FileName, FileMode.Create, FileAccess.Write);
            MemoIn.Text.Trim();
            if (MemoIn.Text != "")
            {
                string cur;
                MemoIn.Text += " ";
                int i = 0, a = 0, b = 0;
                do
                {
                    while (MemoIn.Text[b] != ' ') b++;
                    //while (MemoIn.Text[b] == ' ') b++;
                    cur = MemoIn.Text.Substring(a, b - a).Trim();
                    if (cur != "")
                        f.WriteByte(Convert.ToByte(cur));
                    a = b;
                    i++;
                    b++;
                }
                while (b != MemoIn.Text.Length);
            }
            f.Flush();
            f.Close();
        }
    }
}
