﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            bool IsExit = false;
            LinkenEnum mLinkenEnum = new LinkenEnum();
            Console.WriteLine("Тестирование класса LinkenEnum");
            int i = 1;
            Console.WriteLine(i++ + ". Добавить элемент." + Environment.NewLine +
                              i++ + ". Добавить элемент cо значением." + Environment.NewLine +
                              i++ + ". Найти значение элемента по имени." + Environment.NewLine +
                              i++ + ". Найти имя элемента по значению." + Environment.NewLine +
                              i++ + ". Напечатать все элементы." + Environment.NewLine +
                              i++ + ". Присутствует ли элемент в перечислении(Поиск по имени)." + Environment.NewLine +
                              i++ + ". Присутствует ли элемент в перечислении(Поиск по значению)." + Environment.NewLine +
                              i++ + ". Удалить элемент по имени." + Environment.NewLine +
                              i++ + ". Удалить элемент по значению."  + Environment.NewLine +
                              i++ + ". Выход" + Environment.NewLine);
            while (!IsExit)
            {
                Console.Write("--> ");
                switch (Console.ReadLine())
                {
                    case "1": 
                        Console.Write("Введите название --> ");
                        try
                        {
                            mLinkenEnum.AddElement(Console.ReadLine());
                        }
                        catch (ArgumentException e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        catch(ExistException ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;
                    case "2":
                        string name = "";
                        Console.Write("Введите название --> ");
                        name = Console.ReadLine();
                        Console.Write("Введите значение -->");
                        try
                        {
                                mLinkenEnum.AddElement(name, Convert.ToInt32(Console.ReadLine()));
                        }
                        catch (ArgumentException e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        catch (ExistException ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        catch(Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;
                    case "3":
                        int? k = 0;
                        Console.Write("Введите имя элемента -->");
                        try
                        {
                            k = mLinkenEnum[Console.ReadLine()];
                            if (k == null)
                            {
                                Console.WriteLine("Значение элемента не определено");
                            }
                            else
                            {
                                Console.WriteLine("Значение элемента: " + k);
                            }
                        }
                        catch (ArgumentException e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        catch(NotFoundException ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;
                    case "4":
                        string m = "";
                        Console.Write("Введите значение элемента -->");
                        try
                        {
                            m = mLinkenEnum[Convert.ToInt32(Console.ReadLine())];
                            Console.WriteLine("Имя элемента: " + m);
                        }
                        catch (ArgumentException e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        catch (FormatException e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        catch (NotFoundException ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;
                    case "5":
                        List<string> names = mLinkenEnum.GetNames();
                        List<int?> values = mLinkenEnum.GetValues();

                        for (int j = 0; j < names.Count; j++)
                        {
                            Console.WriteLine(names[j] + ((values[j] != null) ? ":" + values[j].ToString() : string.Empty));
                        }
                        break;
                    case "6":
                        Console.Write("Введите имя элемента --> ");
                        try
                        {
                            Console.WriteLine(mLinkenEnum.IsBelong(Console.ReadLine()));
                        }
                        catch (ArgumentException e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        break;
                    case "7":
                        Console.Write("Введите значение элемента --> ");
                        try
                        {
                            Console.WriteLine(mLinkenEnum.IsBelong(Convert.ToInt32(Console.ReadLine())));
                        }
                        catch (ArgumentException e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        break;
                    case "8":
                        Console.Write("Введите имя элемента --> ");
                        try
                        {
                            mLinkenEnum.Remove(Console.ReadLine());
                            Console.WriteLine("Ok!");
                        }
                        catch (ArgumentException e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        catch (NotFoundException ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;
                    case "9":
                        Console.Write("Введите значение элемента --> ");
                        try
                        {

                            mLinkenEnum.Remove(Convert.ToInt32(Console.ReadLine()));
                            Console.WriteLine("Ok!");
                            //Console.WriteLine(mLinkenEnum.Remove(Convert.ToInt32(Console.ReadLine())));
                        }
                        catch (NotFoundException ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        catch(FormatException e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        break;
                    case "10":
                        IsExit = true;
                        break;
                    default:
                        Console.WriteLine("Неправильный ввод!");
                        break;
                }
            }
            Console.ReadLine();
        }
    }
}
