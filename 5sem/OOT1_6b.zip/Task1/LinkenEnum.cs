﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1
{
    class NotFoundException: Exception
    {
        public NotFoundException()
            : base("Can't find element in enum")
        {
        }
    }

    class ExistException : Exception
    {
        public ExistException()
            : base("Element already exist in enum")
        {
        }
    }

    class LinkenEnum
    {
        private class EnumElement
        {
            public string Name { get; set; }
            public int? Enumerator { get; set; }
        }

        private List<EnumElement> aEnumList;

        public LinkenEnum()
        {
            aEnumList = new List<EnumElement>();
        }

        public string ToString(string aName)
        {
            if (!string.IsNullOrEmpty(aName))
            {
                EnumElement elem = aEnumList.First(x => x.Name == aName);
                if (elem != null)
                {
                    return elem.Name + ((elem.Enumerator != null) ? ":" + elem.Enumerator.ToString() : string.Empty);
                }
                throw new NotFoundException();
            }
            throw new ArgumentException("Parameter aName is null or empty"); 
        }

        public string ToString(int aEnumerator)
        {
            EnumElement elem = aEnumList.First(x => x.Enumerator == aEnumerator);
            if (elem != null)
            {
                return elem.Name + ":" + elem.Enumerator.ToString();
            }
            throw new NotFoundException();
        }

        public void AddElement(string aName)
        {
            if (!string.IsNullOrEmpty(aName))
            {
                if (aEnumList.FirstOrDefault(x => x.Name == aName) != null)
                {
                    throw new ExistException();
                }
                aEnumList.Add(new EnumElement
                {
                    Name = aName,
                    Enumerator = null
                });
            }
            else
            {
                throw new ArgumentException("Parameter aName is null or empty");
            }
        }

        public void AddElement(string aName, int aEnumerator)
        {
            if (!string.IsNullOrEmpty(aName))
            {
                if (aEnumList.FirstOrDefault(x => x.Name == aName) != null)
                {
                    throw new ExistException();
                }
                aEnumList.Add(new EnumElement
                {
                    Name = aName,
                    Enumerator = aEnumerator
                }); 
            }
            else
            {
                throw new ArgumentException("Parameter aName is null or empty");
            }
        }

        public bool IsBelong(string aName)
        {
            if (!string.IsNullOrEmpty(aName))
            {
                return aEnumList.FirstOrDefault(x => x.Name == aName) != null;
            }
            throw new ArgumentException("Parameter aName is null or empty");
        }

        public bool IsBelong(int aEnumerator)
        {
            return aEnumList.FirstOrDefault(x => x.Enumerator == aEnumerator) != null;
        }

        public void Remove(string aName)
        {
            if (!string.IsNullOrEmpty(aName))
            {
                if (!IsBelong(aName))
                {
                    throw new NotFoundException();
                }
                aEnumList.RemoveAll(x => x.Name == aName);
            }
            else
            {
                throw new ArgumentException("Parameter aName is null or empty");
            }
        }

        public void Remove(int aEnumerator)
        {
            if (!IsBelong(aEnumerator))
            {
                throw new NotFoundException();
            }
            aEnumList.RemoveAll(x => x.Enumerator == aEnumerator);
        }

        public string this[int aEnumerator]
        {
            get
            {
                EnumElement elem = aEnumList.FirstOrDefault(s => s.Enumerator == aEnumerator);
                if (elem != null)
                {
                    return elem.Name;
                }
                throw new NotFoundException();
            }
        }

        public int? this[string aName]
        {
            get
            {
                if (!string.IsNullOrEmpty(aName))
                {
                    EnumElement elem = aEnumList.FirstOrDefault(x => x.Name == aName);
                    if (elem != null)
                    {
                        return elem.Enumerator;
                    }
                    throw new NotFoundException();
                }
                throw new ArgumentException("Parameter aName is null or empty");
            }
        }

        public List<string> GetNames()
        {
            return aEnumList.Select(x => x.Name).ToList();
        }

        /// <summary>
        ///
        /// </summary>
        /// <returns>Возвращает список содержащий все значения перечисления</returns>
        public List<int?> GetValues()
        {
            return aEnumList.Select(x => x.Enumerator).ToList();
        }
    }
}
