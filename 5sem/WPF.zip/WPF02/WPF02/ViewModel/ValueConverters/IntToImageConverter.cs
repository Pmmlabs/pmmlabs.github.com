﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Data;
using System.Globalization;
using System.Data;
using System.Windows.Media.Imaging;

namespace WPF02
{
    public class IntToImageConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is int)
            {
                int count = (int)value;

                if (count == 0)
                {
                    Uri uri = new Uri("pack://application:,,,/Images/red.jpg");
                    BitmapImage source = new BitmapImage(uri);
                    return source;
                }
                if (count > 0 && count < 10)
                {
                    Uri uri = new Uri("pack://application:,,,/Images/yellow.jpg");
                    BitmapImage source = new BitmapImage(uri);
                    return source;
                }
                if (count >= 10)
                {
                    Uri uri = new Uri("pack://application:,,,/Images/green.jpg");
                    BitmapImage source = new BitmapImage(uri);
                    return source;
                }
            }
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new System.NotImplementedException();
        }
    }
}
