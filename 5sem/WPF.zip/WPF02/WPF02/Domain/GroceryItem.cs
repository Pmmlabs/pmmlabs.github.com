﻿
using System.ComponentModel;
using System.Runtime.CompilerServices;


namespace WPF02
{
    public class GroceryItem : ObservableObject, ISequencedObject, INotifyPropertyChanged
    {
        #region Fields

        // Property variables
        private int p_SequenceNumber;
        private string p_Name = "[No name]";
        private int p_Count;

        #endregion

        #region Constructors

        /// <summary>
        /// Default constructor
        /// </summary>
        public GroceryItem()
        {
            p_Count = 0;
        }

        /// <summary>
        /// Paramterized constructor.
        /// </summary>
        /// <param name="itemName">The name of the grocery item.</param>
        public GroceryItem(string itemName)
        {
            p_Name = itemName;
            p_Count = 0;
        }

        public GroceryItem(string itemName, int count)
        {
            p_Name = itemName;
            Count = count;
        }
        #endregion

        #region Properties

        /// <summary>
        /// The sequential position of this item in a list of items.
        /// </summary>
        public int SequenceNumber
        {
            get { return p_SequenceNumber; }

            set
            {
                p_SequenceNumber = value;
                base.RaisePropertyChangedEvent("SequenceNumber");
            }
        }

        /// <summary>
        /// The name of the grocery item.
        /// </summary>
        public string Name
        {
            get { return p_Name; }

            set
            {
                p_Name = value.Trim();
                if (p_Name == "") p_Name = "[No name]";
                base.RaisePropertyChangedEvent("Text");
                NotifyPropertyChanged();
            }
        }

        public int Count
        {
            get
            {
                return p_Count;
            }
            set
            {
                if (value >= 0)
                {
                    p_Count = value;
                }
                NotifyPropertyChanged();
            }
        }

        #endregion

        #region Overrides

        /// <summary>
        /// Sets the item name as its ToString() value.
        /// </summary>
        /// <returns>The name of the item.</returns>
        public override string ToString()
        {
            return Name;
        }

        #endregion

        #region INotiyfy
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void NotifyPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion
    }
}
