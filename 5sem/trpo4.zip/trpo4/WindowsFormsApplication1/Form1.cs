﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        string SourceStr,   // исходная строка
               FindStr; // искомая подстрока
        int LenSourceStr, LenFindStr; //соответствующие длины строк
        public Form1()
        {
            InitializeComponent();
            //установка размеров
            DataTable matr = new DataTable("matrix");
            for (int i = 0; i < 3; i++)
            {
                DataRow newRow;
                newRow = matr.NewRow();
                matr.Rows.Add(newRow);
            }
            OutputTable.DataSource = matr;
            OutputTable.AllowUserToAddRows = false;
        }
        void WriteToOutputTable(int CountSr, int CountSd, int MethodNum, int rez)
        {
            // помещаем данные в таблицу
            OutputTable.Rows[MethodNum - 1].Cells[0].Value = CountSr;
            OutputTable.Rows[MethodNum - 1].Cells[1].Value = CountSd;
            OutputTable.Rows[MethodNum - 1].Cells[2].Value = rez;
        }
        // Простой поиск
        bool SimpleMethod()
        {
            int CurrentInputStr = 1, // указатель текущего сравниваемого символа в тексте
                CurrentFindStr = 1, // указатель текущего сравниваемого символа в подстроке
                StartStr = 1, // указатель на начало сравнения в тексте
                CountSr = 0, // счетчик сравнений
                CountSd = 0; // счетчик сдвигов

            while (CurrentInputStr <= LenSourceStr && CurrentFindStr <= LenFindStr)
            {
                CountSr++;
                if (SourceStr[CurrentInputStr - 1] == FindStr[CurrentFindStr - 1])
                {
                    CurrentInputStr++;
                    CurrentFindStr++;
                }
                else
                {
                    StartStr++;
                    CurrentInputStr = StartStr;
                    CurrentFindStr = 1;
                    CountSd++;
                }
            }
            if (CurrentFindStr > LenFindStr)
            {
                WriteToOutputTable(CountSr, CountSd, 1, StartStr);
                return true;
            }
            else
            {
                WriteToOutputTable(0, 0, 1, -1);
                return false;
            }
        }
        // метод Бауэра-Мура
        bool BoierMurMethod()
        {

            int CurrentInputStr, // указатель текущего сравниваемого символа в тексте
                CurrentFindStr, // указатель текущего сравниваемого символа в подстроке
                CountSr = 0, // счетчик сравнений
                CountSd = 0; // счетчик сдвигов
            int[] Sdvig = new int[256]; // массив сдвигов

            // составляем массив сдвигов
            for (int i = 0; i < 256; i++) Sdvig[i] = LenFindStr;
            for (int i = 0; i < LenFindStr; i++) Sdvig[FindStr[i]] = LenFindStr - i-1;

            CurrentInputStr = LenFindStr;
            CurrentFindStr = LenFindStr;
            while (CurrentInputStr <= LenSourceStr && CurrentFindStr > 0)
            {
                if (SourceStr[CurrentInputStr - 1] == FindStr[CurrentFindStr - 1])
                {
                    CurrentInputStr--;
                    CurrentFindStr--;
                }
                else
                {
                    if (CurrentFindStr == LenFindStr)
                        CurrentInputStr += Sdvig[SourceStr[CurrentInputStr - 1]];
                    else CurrentInputStr += LenFindStr - CurrentFindStr + 1;

                    CurrentFindStr = LenFindStr;
                    CountSd++;
                }
                CountSr++;
            }

            if (CurrentFindStr == 0)
            {
                WriteToOutputTable(CountSr, CountSd, 2, CurrentInputStr+1);
                return true;
            }
            else
            {
                WriteToOutputTable(0, 0, 2, 0);
                return false;
            }
        }
        // Метод Кнута-Морисса-Пратта
        bool KnutMethod()
        {

            int CurrentInputStr = 1, // указатель текущего сравниваемого символа в тексте
                CurrentFindStr = 1, // указатель текущего сравниваемого символа в подстроке
                CountSr = 0, // счетчик сравнений
                CountSd = 0, // счетчик сдвигов
                temp;
            int[] Fail = new int[LenFindStr+1]; 
            Fail[1] = 0;
            for (int i = 2; i <= LenFindStr; i++)
            {
                temp = Fail[i - 1];
                while ((temp > 0) && (FindStr[temp] != FindStr[i - 1])) temp = Fail[temp];
                Fail[i] = temp + 1;
            }

            while (CurrentInputStr <= LenSourceStr && CurrentFindStr <= LenFindStr)
            {
                if (CurrentFindStr == 0)
                {
                    CurrentInputStr++;
                    CurrentFindStr++;
                }
                if (SourceStr[CurrentInputStr - 1] == FindStr[CurrentFindStr - 1])
                {
                    CurrentInputStr++;
                    CurrentFindStr++;
                    CountSr++;
                }
                else
                {
                    CurrentFindStr = Fail[CurrentFindStr];
                    CountSd++;
                    CountSr++;
                }
            }

            if (CurrentFindStr > LenFindStr)
            {
                WriteToOutputTable(CountSr, CountSd, 3, CurrentInputStr - LenFindStr);
                return true;
            }
            else
            {
                WriteToOutputTable(0, 0, 3, -1);
                return false;
            }
        }
        ///////////////////////////////////////
        private void button1_Click(object sender, EventArgs e)
        {
            SourceStr = InputStr.Text;
            FindStr = SearchStr.Text;
            LenFindStr = FindStr.Length;
            LenSourceStr = SourceStr.Length;
            if (LenSourceStr < LenFindStr)
                MessageBox.Show("Длина исходной строки меньше искомой");
            else
            {

                bool a, b, c; // переменные проверки
                a = b = c = false;

                if (radioButton1.Checked) a = SimpleMethod();
                if (radioButton2.Checked) b = BoierMurMethod();
                if (radioButton3.Checked) c = KnutMethod();

                if (a || b || c) MessageBox.Show("Подстрока найдена.");
                else MessageBox.Show("Подстрока НЕ найдена.");

            }

        }
        private void OutputTable_RowHeightInfoNeeded(object sender, DataGridViewRowHeightInfoNeededEventArgs e)
        {
            e.Height = 35;
        }
    }
}
