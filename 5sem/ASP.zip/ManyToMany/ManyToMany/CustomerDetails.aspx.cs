﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ManyToMany
{
    public partial class CustomerDetails : System.Web.UI.Page
    {
        ManyToManyEntities manyToMany = new ManyToManyEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
            var name = Request.QueryString["Name"] as string;
            if (name!= null)
                lblCustomer.Text = name;

            var _custProList =  (from p in manyToMany.Products.Where(p => p.Customers.Any(c => c.CustName == name))
                                select p.ProductName);
            lsProducts.DataSource = _custProList;
            lsProducts.DataBind();
            

        }
    }
}