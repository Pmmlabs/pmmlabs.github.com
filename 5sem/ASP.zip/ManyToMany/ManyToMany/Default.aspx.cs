﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ManyToMany
{

    public partial class _Default : System.Web.UI.Page
    {
        ManyToManyEntities manyToMany = new ManyToManyEntities();
        private const string selectString = "--Select--";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //Bind Dropdown details.
                this.BindDropdownDetails(drpProd);
                this.BindDropdownDetails(FilterDropDownList);
                this.BindGridDetails();
            }
        }
        protected void btnCust_Click(object sender, EventArgs e)
        {
            //set Default value as empty for error message.
            lblMessage.Text = string.Empty;

            try
            {
                //Get ProductId from Dropdown selection.
                int ProdId = Convert.ToInt32(drpProd.SelectedValue);               
                var name = txtCus.Text.Trim();
                Customer c = manyToMany.Customers.FirstOrDefault(customer => customer.CustName == name);
                //Get Prodct 
                Product p = manyToMany.Products.SingleOrDefault(x => x.ProductId == ProdId);
                //Set Customer Name property
                if (c == null)
                {
                    c = new Customer();
                    c.CustName = name;
                    manyToMany.Customers.AddObject(c);
                    manyToMany.SaveChanges();
                }

                //Add Product details to customer
                c.Products.Add(p);
                
                //Call SaveChanges method. Saving the records in DB will occur only when you call the SaveChanges Method.
                manyToMany.SaveChanges();
                this.BindDropdownDetails(drpProd);
                this.BindDropdownDetails(FilterDropDownList);
                lblMessage.Text = "Customer Added successfully";
                lblMessage.ForeColor = System.Drawing.Color.Green;
                lblMessage.Font.Bold = true;
                this.BindGridDetails();
                txtCus.Text = string.Empty;
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message;
            }
        }
        protected void btnProd_Click(object sender, EventArgs e)
        {
            //set Default value as empty for error message.
            lblMessage.Text = string.Empty;
            try
            {
                Product p = new Product();
                //Set the ProductName property from textbox.
                p.ProductName = txtProd.Text.Trim();
                manyToMany.Products.AddObject(p);
                manyToMany.SaveChanges(); 
                this.BindDropdownDetails(drpProd);
                this.BindDropdownDetails(FilterDropDownList);
                lblMessage.Text = "Product Added successfully";
                lblMessage.ForeColor = System.Drawing.Color.Green;
                lblMessage.Font.Bold = true;
                txtProd.Text = string.Empty;
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message;
            }
        }
        protected void grdDetails_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grdDetails.EditIndex = e.NewEditIndex;
            this.BindGridDetails();
        }
        protected void grdDetails_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int CustId = Convert.ToInt32(((Label)grdDetails.Rows[e.RowIndex].FindControl("lblCusId")).Text);
            //int ProdId = Convert.ToInt32(((Label)grdDetails.Rows[e.RowIndex].FindControl("lblPId")).Text);
            
            Customer cus = (from c in manyToMany.Customers where c.CustomerId == CustId select c).FirstOrDefault();
            cus.CustName = ((TextBox)grdDetails.Rows[e.RowIndex].FindControl("txtName")).Text;
            manyToMany.Customers.ApplyCurrentValues(cus);            

            manyToMany.SaveChanges();

            grdDetails.EditIndex = -1;
            this.BindGridDetails();
        }
        protected void grdDetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int CustId = Convert.ToInt32(((Label)grdDetails.Rows[e.RowIndex].FindControl("lblCusId")).Text);

            Customer cus = (from c in manyToMany.Customers where c.CustomerId == CustId select c).First();
            var prod = (from p in manyToMany.Products.Where(p => p.Customers.Any(c => c.CustomerId == cus.CustomerId)) select p);
            cus.Products.Attach(prod);
            manyToMany.Customers.DeleteObject(cus);
            manyToMany.SaveChanges();
            this.BindGridDetails();
        }
        protected void grdDetails_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grdDetails.EditIndex = -1;
            this.BindGridDetails();
        }

        #region Binding Dropdowns & GridView

        private void BindGridDetails()
        {
            int filterId;
            int.TryParse(FilterDropDownList.SelectedValue,out  filterId);
            var _custProList = (FilterDropDownList.SelectedValue == "") 
                                ?
                                (from c in manyToMany.Customers.Where(f => f.Products.Any())
                                select new { c.CustomerId, c.CustName})
                                :
                                (from c in manyToMany.Customers.Where(f => f.Products.Any(p => p.ProductId == filterId))
                                from p in manyToMany.Products.Where(g => g.ProductId == filterId)
                                select new { c.CustomerId, c.CustName });
            grdDetails.DataSource = _custProList;
            grdDetails.DataBind();
            
        }
        private void BindDropdownDetails(DropDownList ddl)
        {
            //set Default value as empty for error message.
            lblMessage.Text = string.Empty;

            try
            {
                ddl.Items.Clear();
                ddl.Items.Add(new ListItem(selectString, ""));
                ddl.DataTextField = "ProductName";
                ddl.DataValueField = "ProductId";
                ddl.DataSource = manyToMany.Products;
                ddl.DataBind();
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message;
            }
        }

        #endregion

        protected void grdDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {

                LinkButton lnk1 = (LinkButton)e.Row.Cells[e.Row.Cells.Count - 1].Controls[2];
                if(lnk1.Text=="Delete")
                lnk1.Attributes.Add("onclick", "if(window.confirm('Are you sure,You want to delete?'))return true;else return false;");   
            }
        }

        protected void FilterDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.BindGridDetails();
        }

        protected void FilterDropDownList_TextChanged(object sender, EventArgs e)
        {
            this.BindGridDetails();
        }

        protected void lbName_Click(object sender, EventArgs e)
        {
            var name = (sender as LinkButton).Text;
            Response.Redirect("CustomerDetails.aspx?Name=" + name);
        }
    }
}
