﻿namespace proizvodstvo2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bCreate = new System.Windows.Forms.Button();
            this.bDelete = new System.Windows.Forms.Button();
            this.BCreatePostavchik = new System.Windows.Forms.Button();
            this.bCreateMagaz = new System.Windows.Forms.Button();
            this.bRefresh = new System.Windows.Forms.Button();
            this.tInfo = new System.Windows.Forms.TextBox();
            this.bBuySyrjo = new System.Windows.Forms.Button();
            this.bProcess = new System.Windows.Forms.Button();
            this.bSell = new System.Windows.Forms.Button();
            this.tCountMagaz = new System.Windows.Forms.TextBox();
            this.tCountCeh = new System.Windows.Forms.TextBox();
            this.TimerMain = new System.Windows.Forms.Timer(this.components);
            this.bAuto = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bCreate
            // 
            this.bCreate.Location = new System.Drawing.Point(12, 12);
            this.bCreate.Name = "bCreate";
            this.bCreate.Size = new System.Drawing.Size(203, 36);
            this.bCreate.TabIndex = 0;
            this.bCreate.Text = "Создать завод с количеством цехов:";
            this.bCreate.UseVisualStyleBackColor = true;
            this.bCreate.Click += new System.EventHandler(this.bCreate_Click);
            // 
            // bDelete
            // 
            this.bDelete.Location = new System.Drawing.Point(12, 152);
            this.bDelete.Name = "bDelete";
            this.bDelete.Size = new System.Drawing.Size(100, 34);
            this.bDelete.TabIndex = 1;
            this.bDelete.Text = "Удалить завод";
            this.bDelete.UseVisualStyleBackColor = true;
            this.bDelete.Click += new System.EventHandler(this.bDelete_Click);
            // 
            // BCreatePostavchik
            // 
            this.BCreatePostavchik.Location = new System.Drawing.Point(12, 96);
            this.BCreatePostavchik.Name = "BCreatePostavchik";
            this.BCreatePostavchik.Size = new System.Drawing.Size(100, 36);
            this.BCreatePostavchik.TabIndex = 2;
            this.BCreatePostavchik.Text = "Создать поставщика";
            this.BCreatePostavchik.UseVisualStyleBackColor = true;
            this.BCreatePostavchik.Click += new System.EventHandler(this.BCreatePostavchik_Click);
            // 
            // bCreateMagaz
            // 
            this.bCreateMagaz.Location = new System.Drawing.Point(12, 54);
            this.bCreateMagaz.Name = "bCreateMagaz";
            this.bCreateMagaz.Size = new System.Drawing.Size(203, 36);
            this.bCreateMagaz.TabIndex = 3;
            this.bCreateMagaz.Text = "Создать следующее количество магазинов:";
            this.bCreateMagaz.UseVisualStyleBackColor = true;
            this.bCreateMagaz.Click += new System.EventHandler(this.bCreateMagaz_Click);
            // 
            // bRefresh
            // 
            this.bRefresh.Location = new System.Drawing.Point(419, 21);
            this.bRefresh.Name = "bRefresh";
            this.bRefresh.Size = new System.Drawing.Size(118, 62);
            this.bRefresh.TabIndex = 4;
            this.bRefresh.Text = "Обновить";
            this.bRefresh.UseVisualStyleBackColor = true;
            this.bRefresh.Click += new System.EventHandler(this.bRefresh_Click);
            // 
            // tInfo
            // 
            this.tInfo.Location = new System.Drawing.Point(118, 96);
            this.tInfo.Multiline = true;
            this.tInfo.Name = "tInfo";
            this.tInfo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tInfo.Size = new System.Drawing.Size(419, 269);
            this.tInfo.TabIndex = 6;
            // 
            // bBuySyrjo
            // 
            this.bBuySyrjo.Location = new System.Drawing.Point(12, 210);
            this.bBuySyrjo.Name = "bBuySyrjo";
            this.bBuySyrjo.Size = new System.Drawing.Size(100, 36);
            this.bBuySyrjo.TabIndex = 7;
            this.bBuySyrjo.Text = "Купить сырье";
            this.bBuySyrjo.UseVisualStyleBackColor = true;
            this.bBuySyrjo.Click += new System.EventHandler(this.bBuySyrjo_Click);
            // 
            // bProcess
            // 
            this.bProcess.Location = new System.Drawing.Point(12, 273);
            this.bProcess.Name = "bProcess";
            this.bProcess.Size = new System.Drawing.Size(100, 36);
            this.bProcess.TabIndex = 8;
            this.bProcess.Text = "Обработать сырье";
            this.bProcess.UseVisualStyleBackColor = true;
            this.bProcess.Click += new System.EventHandler(this.bProcess_Click);
            // 
            // bSell
            // 
            this.bSell.Location = new System.Drawing.Point(12, 329);
            this.bSell.Name = "bSell";
            this.bSell.Size = new System.Drawing.Size(100, 36);
            this.bSell.TabIndex = 9;
            this.bSell.Text = "Продать товар";
            this.bSell.UseVisualStyleBackColor = true;
            this.bSell.Click += new System.EventHandler(this.bSell_Click);
            // 
            // tCountMagaz
            // 
            this.tCountMagaz.Location = new System.Drawing.Point(221, 63);
            this.tCountMagaz.Name = "tCountMagaz";
            this.tCountMagaz.Size = new System.Drawing.Size(56, 20);
            this.tCountMagaz.TabIndex = 10;
            this.tCountMagaz.Text = "1";
            // 
            // tCountCeh
            // 
            this.tCountCeh.Location = new System.Drawing.Point(221, 21);
            this.tCountCeh.Name = "tCountCeh";
            this.tCountCeh.Size = new System.Drawing.Size(56, 20);
            this.tCountCeh.TabIndex = 11;
            this.tCountCeh.Text = "1";
            // 
            // TimerMain
            // 
            this.TimerMain.Interval = 5000;
            this.TimerMain.Tick += new System.EventHandler(this.TimerMain_Tick);
            // 
            // bAuto
            // 
            this.bAuto.Location = new System.Drawing.Point(314, 21);
            this.bAuto.Name = "bAuto";
            this.bAuto.Size = new System.Drawing.Size(99, 62);
            this.bAuto.TabIndex = 12;
            this.bAuto.Text = "Авто";
            this.bAuto.UseVisualStyleBackColor = true;
            this.bAuto.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(549, 377);
            this.Controls.Add(this.bAuto);
            this.Controls.Add(this.tCountCeh);
            this.Controls.Add(this.tCountMagaz);
            this.Controls.Add(this.bSell);
            this.Controls.Add(this.bProcess);
            this.Controls.Add(this.bBuySyrjo);
            this.Controls.Add(this.tInfo);
            this.Controls.Add(this.bRefresh);
            this.Controls.Add(this.bCreateMagaz);
            this.Controls.Add(this.BCreatePostavchik);
            this.Controls.Add(this.bDelete);
            this.Controls.Add(this.bCreate);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bCreate;
        private System.Windows.Forms.Button bDelete;
        private System.Windows.Forms.Button BCreatePostavchik;
        private System.Windows.Forms.Button bCreateMagaz;
        private System.Windows.Forms.Button bRefresh;
        private System.Windows.Forms.TextBox tInfo;
        private System.Windows.Forms.Button bBuySyrjo;
        private System.Windows.Forms.Button bProcess;
        private System.Windows.Forms.Button bSell;
        private System.Windows.Forms.TextBox tCountMagaz;
        private System.Windows.Forms.TextBox tCountCeh;
        private System.Windows.Forms.Timer TimerMain;
        private System.Windows.Forms.Button bAuto;
    }
}

