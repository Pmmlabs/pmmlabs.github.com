﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace proizvodstvo2
{
    public class Firma
    {
        protected int Money;
        protected int Price;
        public int GetPrice
        {
            get { return Price; }
        }
        public int InfoAboutMoney
        {
            get { return Money; }
        }
    }
}
