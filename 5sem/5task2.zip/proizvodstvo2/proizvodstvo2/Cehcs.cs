﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace proizvodstvo2
{
    class Ceh // ЦЕХ (составная часть завода)
    {
        private const int CountWorkers = 3;
        Worker[] Workers = new Worker[CountWorkers];
        Tovar MyTovar = new Tovar();
        public Ceh()
        {
            for (int i = 0; i < CountWorkers; i++)
                Workers[i] = new Worker();
        }
        public Tovar Process(Syrjo aSyrjo,int aZarplata)
        {
            char s = aSyrjo.GetValue;
            for (int i = 0; i < CountWorkers; i++)
                MyTovar.Name += Workers[i].Process(s,aZarplata / CountWorkers);
            return MyTovar;
        }
    }
}
