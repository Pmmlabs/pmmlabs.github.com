﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace proizvodstvo2
{
    public class Tovar // ТОВАР (то,что производит завод)
    {
        string name = "";
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public static Tovar operator +(Tovar src1, Tovar src2)
        {
            Tovar tmp = src1;
            tmp.Name += src2.Name;
            return tmp;
        }
        public int Count
        {
            get { return Name.Length; }
        }
    }
}
