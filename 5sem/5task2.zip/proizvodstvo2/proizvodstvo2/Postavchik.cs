﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace proizvodstvo2
{
    public class Postavchik : Firma // ПОСТАВЩИК - источник сырья для завода
    {
        Syrjo MySyrjo;
        public Postavchik()
        {
            Price = 200;
            Money = 0;
        }
        public Syrjo GetSyrjo(ref int aMoney)
        {
            if (aMoney >= Price)
            {
                Money += aMoney / Price * Price;
                MySyrjo = new Syrjo((int)(aMoney / Price));
                aMoney = aMoney % Price;
                return MySyrjo;
            }
            else
            {
                Console.WriteLine("Недостаточно денег для покупки сырья");
                return null;
            }
        }
    }
}
