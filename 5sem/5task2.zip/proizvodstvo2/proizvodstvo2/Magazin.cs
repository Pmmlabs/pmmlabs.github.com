﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace proizvodstvo2
{
    public class Magazin : Firma
    {
        Tovar MagazTovar;
        public Magazin()
        {
            Price = 400;
            Money = 10000;
        }
       
        public int GiveTovar(ref Tovar aTovar)
        {
            int cena;
            if (aTovar.Name.Length * Price > Money)
            {
                cena = Money;
                aTovar.Name.Remove(cena / Price);
            }
            else
            {
                cena = aTovar.Name.Length * Price;
                aTovar.Name = "";
            }
            Money -= cena;
            if (Money == 0) Money = 10000;
            return cena;
        }
    }
}
