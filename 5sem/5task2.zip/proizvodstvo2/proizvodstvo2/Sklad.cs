﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace proizvodstvo2
{
    class Sklad
    {
        Tovar MyTovar = new Tovar();
        Syrjo MySyrjo = new Syrjo();
        public static Sklad operator +(Sklad src1, Tovar src2)
        {
            Sklad tmp = src1;
            tmp.MyTovar += src2;
            return tmp;
        }
        public static Sklad operator +(Sklad src1, Syrjo src2)
        {
            Sklad tmp = src1;
            tmp.MySyrjo += src2;
            return tmp;
        }
        public Tovar GetTovar
        {
            get { return MyTovar; }
        }
        public Syrjo GetSyrjo
        {
            get { return MySyrjo; }
        }
    }
}
