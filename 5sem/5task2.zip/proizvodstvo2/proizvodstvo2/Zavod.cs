﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace proizvodstvo2
{
    public class Zavod //ЗАВОД
    {
        int Money;
        Syrjo MySyrjo = new Syrjo();
        const int Zarplata = 500;
        Ceh[] Ceha;
        Sklad MySklad = new Sklad();
        public Zavod(int CountCehov)
        {
            Money = 202;
            Ceha= new Ceh[CountCehov];
            for (int i = 0; i < CountCehov; i++)
                Ceha[i] = new Ceh();
        }
        public bool BuySyrjo(Postavchik aPostavchik)
        {
            if (aPostavchik != null && Money >= aPostavchik.GetPrice)
            {
                MySyrjo += aPostavchik.GetSyrjo(ref Money);
                return true;
            }
            else return false;
        }
        public bool Proccess()
        {
            if (MySyrjo.Count == 0) return false;
            else
            {
                for (int i = 0; MySyrjo.Count > 0; i++)
                {
                    Money -= Zarplata;
                    MySklad += Ceha[i % Ceha.Count()].Process(MySyrjo.GetPart(), Zarplata);
                }
                return true;
            }
        }
        public bool Sell(Magazin M)
        {
            if (MySklad.GetTovar.Count == 0) return false;
            else
            {
                Tovar t = MySklad.GetTovar;
                Money += M.GiveTovar(ref t);
                return true;
            }
        }
        public string Info
        {
            get { return "Деньги: " + Money + "р.; Сырьё: " + MySyrjo.Count + " шт.;Товар: " + MySklad.GetTovar.Count; }
        }
    }
}
