﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace proizvodstvo2
{
    public class Syrjo //СЫРЬЁ
    {
        private int count;
        string soderjimoe;
        public Syrjo()
        {
            count = 0;
            soderjimoe = "";
        }
        public Syrjo(int aCount)
        {
            count = aCount;
            Random r = new Random();
            soderjimoe = "";
            for (int i = 0; i < aCount; i++)
                soderjimoe += (char)((int)('A') + r.Next(50));
        }
        public int Count
        {
            get { return count; }
        }
        public char GetValue
        {
            get { return soderjimoe[0]; }
        }
        public Syrjo GetPart()
        {
            if (count > 0)
            {
                Syrjo tmp = new Syrjo();
                tmp.count = 1;
                tmp.soderjimoe = (soderjimoe[soderjimoe.Length - 1]).ToString();
                count -= 1;
                soderjimoe.Remove(soderjimoe.Length - 1);
                return tmp;
            }
            else
            {
                Console.WriteLine("Сырье кончилось");
                return null;
            }
        }
        public static Syrjo operator +(Syrjo src1, Syrjo src2)
        {
            Syrjo tmp = src1;
            tmp.count += src2.count;
            tmp.soderjimoe += src2.soderjimoe;
            return tmp;
        }
    }
}
