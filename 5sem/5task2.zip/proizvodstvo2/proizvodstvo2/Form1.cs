﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace proizvodstvo2
{
    
    public partial class Form1 : Form
    {
        Manager MainManager = new Manager();
        public Form1()
        {
            InitializeComponent();
        }
        private void RefreshInfo()
        {
            tInfo.Text += MainManager.GetInfo();
            tInfo.Focus();
            tInfo.SelectionStart = tInfo.Text.Length;
            tInfo.ScrollToCaret();
        }
        private void bCreate_Click(object sender, EventArgs e)
        {
            MainManager.CreateZavod(Convert.ToInt32(tCountCeh.Text));
        }

        private void bDelete_Click(object sender, EventArgs e)
        {

        }

        private void BCreatePostavchik_Click(object sender, EventArgs e)
        {
            MainManager.CreatePostavchik();
        }

        private void bCreateMagaz_Click(object sender, EventArgs e)
        {
            MainManager.CreateMagazin(Convert.ToInt32(tCountMagaz.Text));
        }

        private void bRefresh_Click(object sender, EventArgs e)
        {
            RefreshInfo();  
        }

        private void bBuySyrjo_Click(object sender, EventArgs e)
        {
            if (!MainManager.Buy()) tInfo.Text += "Купить сырье не удалось.\r\n\r\n";
            RefreshInfo();
        }

        private void bProcess_Click(object sender, EventArgs e)
        {
            if (!MainManager.Process()) tInfo.Text += "Обработать сырье не удалось.\r\n\r\n";
            RefreshInfo();
        }

        private void bSell_Click(object sender, EventArgs e)
        {
            if (!MainManager.Sell()) tInfo.Text += "Продать сырье не удалось.\r\n\r\n";
            RefreshInfo();
        }
        private void TimerMain_Tick(object sender, EventArgs e)
        {
            bCreate.PerformClick();
            bCreateMagaz.PerformClick();
            BCreatePostavchik.PerformClick();
            bBuySyrjo.PerformClick();
            bProcess.PerformClick();
            bSell.PerformClick();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TimerMain.Enabled = !TimerMain.Enabled;
        }
    }
}
