﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace proizvodstvo2
{
    public class Manager
    {
        Zavod z;
        Postavchik p;
        Magazin[] m;
        public Manager()
        {
        }
        public void CreateZavod(int aCountOfCehov)
        {
            if (z==null) z = new Zavod(aCountOfCehov);
        }
        public void CreatePostavchik()
        {
            if (p==null) p = new Postavchik();
        }
        public void CreateMagazin(int count)
        {
           if (m==null) m = new Magazin[count];
            for (int i = 0; i < count; i++)
                if (m[i]==null) m[i] = new Magazin();
        }
        public string GetInfo()
        {
            string tmp = "";
            if (z != null) tmp += "Завод: " + z.Info + " \r\n";
             else tmp += "Завод не создан\r\n";
            if (p != null) tmp += "Деньги поставщика: " + p.InfoAboutMoney + " р.\r\n";
             else tmp += "Поставщик не создан\r\n";
            if (m != null)
             for (int i=0;i<m.Length;i++)
              tmp += "Деньги магазина №"+(i+1)+" : " + m[i].InfoAboutMoney + " р.\r\n";
             else tmp += "Ни одного магазина еще не создано.\r\n";
            return tmp+"\r\n";
        }
        public bool Buy()
        {
            return z!=null && z.BuySyrjo(p) ;
        }
        public bool Process()
        {
            return z!=null && z.Proccess();
        }
        public bool Sell()
        {
            Random r = new Random();
            return z != null && m!=null && z.Sell(m[r.Next(m.Length)]);
        }
    }
}
