﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace proizvodstvo2
{
    class Worker // Рабочий - часть цеха
    {
        string name;
        int Money = 0;
        public Worker()
        {
            string name = "";
            
        }
        public char Process(char c,int zarplata)
        {
            Money += zarplata;
            return (char)((int)c + 1);
        }
    }
}
