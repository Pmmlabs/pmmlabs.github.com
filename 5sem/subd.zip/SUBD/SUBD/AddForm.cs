﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OracleClient;
using System.Collections;

namespace SUBD
{
    public partial class AddForm : Form
    {
        public AddForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void AddForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.ARTIST' table. You can move, or remove it, as needed.
            this.aRTISTTableAdapter.Fill(this.dataSet1.ARTIST);
            // TODO: This line of code loads data into the 'dataSet1.ARENS' table. You can move, or remove it, as needed.
            this.aRENSTableAdapter.Fill(this.dataSet1.ARENS);
            // TODO: This line of code loads data into the 'dataSet1.JOURNAL' table. You can move, or remove it, as needed.
            this.jOURNALTableAdapter.Fill(this.dataSet1.JOURNAL);
           
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String ConnectionString = "Data Source=STARTDB.AMM.VSU.RU;User ID=STUDENT;Password=STUDENT;Unicode=True";
            OracleConnection connect = new OracleConnection(ConnectionString);
            connect.Open();
            OracleDataReader SqlDataReaderCircus;
            try
            {
                OracleCommand SqlCommand = connect.CreateCommand();
                SqlCommand.CommandText = "INSERT INTO JOURNAL VALUES (TO_DATE('" + textBox1.Text + "','DD.MM.YYYY'),TO_DATE('" + textBox2.Text + "','DD.MM.YYYY'),SEQ_CIRCUS.NEXTVAL," + (comboBox2.SelectedIndex+1) + "," + (comboBox2.SelectedIndex+1) + ")";
                SqlDataReaderCircus = SqlCommand.ExecuteReader();
                SqlDataReaderCircus.Close();
                connect.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "Некорректный запрос!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            this.Close();
        }
    }
}
