﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace SUBD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
     
        private void Form1_Load(object sender, EventArgs e)
        { 
       }
           

        private void площадкиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Arens a = new Arens();
            a.Show();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void запросыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FQuery f = new FQuery();
            f.Show();
        }

        private void артистыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Artists b = new Artists();
            b.Show();
        }

        private void журналВыходаАртистовНаРаботуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Journal c = new Journal();
            c.Show();
        }

        private void категорииАртистовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Categories d = new Categories();
            d.Show();
        }

        private void отчет1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }   
    }
}
