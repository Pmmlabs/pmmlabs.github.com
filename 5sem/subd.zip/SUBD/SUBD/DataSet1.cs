﻿namespace SUBD {
    
    
    public partial class DataSet1 {
        partial class ARENSDataTable
        {
        }
    }
}
