﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.Data.Common;
using System.Data.OracleClient;

namespace SUBD
{
    public partial class FQuery : Form
    {
        public FQuery()
        {
            InitializeComponent();
        }

        private void выйтиИзПроектаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void вернутьсяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void вывестиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            queryTxt.Text = "SELECT A.NAME Имя, A.SURNAME Фамилия FROM ARTIST A JOIN JOURNAL J ON A.ID_ARTIST = J.ID_ARTIST JOIN ARENS AR ON J.ID_ARENA = AR.ID_ARENA WHERE to_char(AR.ARENA_TITLE) = 'На Цв. Бульваре' AND J.DATE_BEGIN = TO_DATE('09.11.2011','DD.MM.YYYY')";
            выполнитьЗапросToolStripMenuItem.PerformClick();
        }
        
        private void выполнитьЗапросToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String ConnectionString = "Data Source=STARTDB.AMM.VSU.RU;User ID=STUDENT;Password=STUDENT;Unicode=True";
            OracleConnection connect = new OracleConnection(ConnectionString);
            connect.Open();

            OracleDataReader SqlDataReaderCircus;
            dGV.Refresh();
            if (queryTxt.Text == "")
            {
                MessageBox.Show("Введите или выберите запрос!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                OracleCommand SqlCommand = connect.CreateCommand();
                SqlCommand.CommandText = queryTxt.Text.ToString() ;
                SqlDataReaderCircus = SqlCommand.ExecuteReader();
                ArrayList AL = new ArrayList(0);
                foreach (DbDataRecord Record in SqlDataReaderCircus)
                    AL.Add(Record);
                SqlDataReaderCircus.Close();
                dGV.DataSource = AL;
                connect.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message+"Некорректный запрос!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

        }

        private void очиститьОкноToolStripMenuItem_Click(object sender, EventArgs e)
        {
            queryTxt.Text = "";
            ArrayList AL = new ArrayList(0);
            dGV.DataSource = AL;
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            queryTxt.Text = "SELECT DISTINCT to_char(A.Name) Имя , to_char(A.SURNAME) Фамилия , J1.DATE_BEGIN, J1.DATE_END Дата_Начала, to_char(AR.ARENA_TITLE) Цирковая_площадка FROM JOURNAL J1 JOIN ARTIST A ON A.ID_ARTIST = J1.ID_ARTIST JOIN ARENS AR ON J1.ID_ARENA = AR.ID_ARENA, JOURNAL J2 WHERE J1.DATE_BEGIN > TO_DATE('10.12.2009','DD.MM.YYYY') AND J2.DATE_END < TO_DATE('11.12.2011','DD.MM.YYYY') AND J1.ID_ARENA = J2.ID_ARENA AND J1.DATE_BEGIN = J2.DATE_BEGIN  AND J1.DATE_END = J2.DATE_END AND J1.ID_ARTIST <> J2.ID_ARTIST";
            выполнитьЗапросToolStripMenuItem.PerformClick();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            queryTxt.Text = "SELECT to_char(A.ARENA_TITLE) , COUNT (J.ID_JOURNAL) FROM JOURNAL J JOIN ARENS A ON J.ID_ARENA = A.ID_ARENA WHERE J.DATE_BEGIN > TO_DATE('11.11.2009','DD.MM.YYYY') AND J.DATE_END < TO_DATE('11.12.2011','DD.MM.YYYY') AND ROWNUM <= 4 GROUP BY to_char(A.ARENA_TITLE) ORDER BY 2 DESC";
            выполнитьЗапросToolStripMenuItem.PerformClick();
        }
    }
}
