﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace SUBD
{
    public partial class Categories : Form
    {
        public Categories()
        {
            InitializeComponent();
        }

        private void Categories_Load(object sender, EventArgs e)
        {
            this.cATEGORIESTableAdapter.Fill(this.dataSet1.CATEGORIES);
            dataGridView1.Sort(dataGridView1.Columns[0], 0);

        }

        private void удалитьТекущуюЗаписьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CurrencyManager CurMan = (CurrencyManager)dataGridView1.BindingContext[dataGridView1.DataSource];
            if (CurMan.Count > 0)
            {
                CurMan.RemoveAt(CurMan.Position);
                cATEGORIESTableAdapter.Update(this.dataSet1.CATEGORIES);
                dataGridView1.Sort(dataGridView1.Columns[0], 0);
            }
        }

        private void сохранитьИзмененияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.DataSource = dataSet1.CATEGORIES;
                this.cATEGORIESTableAdapter.Update(this.dataSet1.CATEGORIES);
                dataGridView1.Sort(dataGridView1.Columns[0], 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка");
            }
        }

        private void excelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfdArens = new SaveFileDialog();
            sfdArens.DefaultExt = "xls";
            sfdArens.Filter = "Файлы Excel|*.xls";
            sfdArens.Title = "Экспорт: Excel";
            if (sfdArens.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                FileStream fs = new FileStream(sfdArens.FileName, FileMode.Create);
                try
                {
                    StreamWriter swArens = new StreamWriter(fs, System.Text.Encoding.Unicode);
                    foreach (System.Data.DataColumn Column in dataSet1.ARENS.Columns)
                        swArens.Write(Column.Caption + "\t");
                    swArens.WriteLine();
                    foreach (System.Data.DataRow Row in dataSet1.ARENS.Rows)
                    {
                        foreach (object Entity in Row.ItemArray)
                        {
                            swArens.Write(Entity.ToString() + "\t");
                        }
                        swArens.WriteLine();
                    }
                    swArens.Flush();
                }
                catch
                {
                    MessageBox.Show("При передаче данных возникла ошибка", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                fs.Close();
                Process.Start(fs.Name);
            }
        }

        private void hTMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int i, j;
            SaveFileDialog sfdArens = new SaveFileDialog();
            sfdArens.DefaultExt = "html";
            sfdArens.Filter = "HTML файлы(*.html)|*.html";
            sfdArens.Title = "Экспорт: HTML";
            if (sfdArens.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                FileStream fs = new FileStream(sfdArens.FileName, FileMode.Create);
                try
                {
                    StreamWriter swArens = new StreamWriter(fs);
                    swArens.WriteLine("<html>");
                    swArens.WriteLine("<head>");
                    swArens.WriteLine("<meta content=\"text/html; charset=utf-8\" http-equiv=\"Content-Type\">");
                    swArens.WriteLine("<title>База данных цирковых площадок</title>");
                    swArens.WriteLine("</head>"); swArens.WriteLine("<body bgcolor=\"000000\">");
                    swArens.WriteLine("<table align=\"center\" cols =0 cellspacing = 0>");
                    swArens.WriteLine("<tr>");
                    swArens.WriteLine("<td colspan=2 align=\"center\" valign=\"top\"><img src=\"pics/buyers.gif\" >");
                    swArens.WriteLine("</td>");
                    swArens.WriteLine("</tr>");
                    for (j = 0; j < dataSet1.ARENS.Columns.Count; j++)
                    {
                        swArens.WriteLine("<td><font face=\"Verdana\" size=\"2\" color=\"ffffff\"›<p align=\"center\"><b>");
                        swArens.WriteLine("" + dataSet1.ARENS.Columns[j].ColumnName);
                        swArens.WriteLine("</b></font></td>");
                    }
                    swArens.WriteLine("</tr>");
                    for (i = 0; i < dataSet1.ARENS.Rows.Count; i++)
                    {
                        if (i % 2 == 0)
                        {
                            swArens.WriteLine("<tr bgcolor=\"3399cc\">");
                            for (j = 0; j < dataSet1.ARENS.Rows.Count; j++)
                            {
                                swArens.WriteLine("<td><font face=\"Verdana\" size=\"2\" color=\"#000000\"><p align=\"center\">");
                                swArens.WriteLine("" + dataSet1.ARENS.Rows[i][j]);
                                swArens.WriteLine("</font></td>");
                            }
                            swArens.WriteLine("</tr>");
                        }
                        else
                        {
                            swArens.WriteLine("<tr>");
                            for (j = 0; j < dataSet1.ARENS.Columns.Count; j++)
                            {
                                swArens.WriteLine("<td><font face=\"Verdana\" size=\"2\" color=\"#ififff\"><p align=\"center\">");
                                swArens.WriteLine("" + dataSet1.ARENS.Rows[i][j]);
                                swArens.WriteLine("</font></td>");
                            }
                            swArens.WriteLine("</tr>");
                        }
                    }
                    swArens.WriteLine("</table></center></body></html>");
                    MessageBox.Show("Экспорт успешно завершен!", "Экспорт...", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    swArens.Flush();
                }
                catch
                {
                    MessageBox.Show("При передаче данных возникла ошибка!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                fs.Close();
                Process.Start(fs.Name);
            }
        }

        private void вернутьсяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void выйтиИзПроектаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dataGridView1_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            if (dataGridView1.ColumnCount == 0) dataGridView1.Rows[e.Row.Index - 1].Cells[0].Value = 1;
            else dataGridView1.Rows[e.Row.Index - 1].Cells[0].Value = Convert.ToInt32(dataGridView1.Rows[e.Row.Index - 2].Cells[0].Value)+1;
        }

        private void dataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            MessageBox.Show("Неправильно введены данные!");
        }
    }
}
