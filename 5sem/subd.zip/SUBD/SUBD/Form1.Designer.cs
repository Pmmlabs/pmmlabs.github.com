﻿namespace SUBD
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.таблицыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.площадкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.артистыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.категорииАртистовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.журналВыходаАртистовНаРаботуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запросыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчет1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.отчетОбАртистахToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.таблицыToolStripMenuItem,
            this.запросыToolStripMenuItem,
            this.отчетыToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(421, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // таблицыToolStripMenuItem
            // 
            this.таблицыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.площадкиToolStripMenuItem,
            this.артистыToolStripMenuItem,
            this.категорииАртистовToolStripMenuItem,
            this.журналВыходаАртистовНаРаботуToolStripMenuItem});
            this.таблицыToolStripMenuItem.Name = "таблицыToolStripMenuItem";
            this.таблицыToolStripMenuItem.Size = new System.Drawing.Size(63, 20);
            this.таблицыToolStripMenuItem.Text = "Таблицы";
            // 
            // площадкиToolStripMenuItem
            // 
            this.площадкиToolStripMenuItem.Name = "площадкиToolStripMenuItem";
            this.площадкиToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.площадкиToolStripMenuItem.Text = "Площадки";
            this.площадкиToolStripMenuItem.Click += new System.EventHandler(this.площадкиToolStripMenuItem_Click);
            // 
            // артистыToolStripMenuItem
            // 
            this.артистыToolStripMenuItem.Name = "артистыToolStripMenuItem";
            this.артистыToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.артистыToolStripMenuItem.Text = "Артисты";
            this.артистыToolStripMenuItem.Click += new System.EventHandler(this.артистыToolStripMenuItem_Click);
            // 
            // категорииАртистовToolStripMenuItem
            // 
            this.категорииАртистовToolStripMenuItem.Name = "категорииАртистовToolStripMenuItem";
            this.категорииАртистовToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.категорииАртистовToolStripMenuItem.Text = "Категории артистов";
            this.категорииАртистовToolStripMenuItem.Click += new System.EventHandler(this.категорииАртистовToolStripMenuItem_Click);
            // 
            // журналВыходаАртистовНаРаботуToolStripMenuItem
            // 
            this.журналВыходаАртистовНаРаботуToolStripMenuItem.Name = "журналВыходаАртистовНаРаботуToolStripMenuItem";
            this.журналВыходаАртистовНаРаботуToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.журналВыходаАртистовНаРаботуToolStripMenuItem.Text = "Журнал выхода артистов на работу";
            this.журналВыходаАртистовНаРаботуToolStripMenuItem.Click += new System.EventHandler(this.журналВыходаАртистовНаРаботуToolStripMenuItem_Click);
            // 
            // запросыToolStripMenuItem
            // 
            this.запросыToolStripMenuItem.Name = "запросыToolStripMenuItem";
            this.запросыToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.запросыToolStripMenuItem.Text = "Запросы";
            this.запросыToolStripMenuItem.Click += new System.EventHandler(this.запросыToolStripMenuItem_Click);
            // 
            // отчетыToolStripMenuItem
            // 
            this.отчетыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.отчет1ToolStripMenuItem,
            this.отчетОбАртистахToolStripMenuItem});
            this.отчетыToolStripMenuItem.Name = "отчетыToolStripMenuItem";
            this.отчетыToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.отчетыToolStripMenuItem.Text = "Отчеты";
            // 
            // отчет1ToolStripMenuItem
            // 
            this.отчет1ToolStripMenuItem.Name = "отчет1ToolStripMenuItem";
            this.отчет1ToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.отчет1ToolStripMenuItem.Text = "Отчет о выступлениях";
            this.отчет1ToolStripMenuItem.Click += new System.EventHandler(this.отчет1ToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label1.Location = new System.Drawing.Point(23, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(386, 57);
            this.label1.TabIndex = 2;
            this.label1.Text = "База данных цирка";
            // 
            // отчетОбАртистахToolStripMenuItem
            // 
            this.отчетОбАртистахToolStripMenuItem.Name = "отчетОбАртистахToolStripMenuItem";
            this.отчетОбАртистахToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.отчетОбАртистахToolStripMenuItem.Text = "Отчет об артистах";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(421, 226);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "База данных цирка";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem таблицыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem площадкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запросыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem артистыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem категорииАртистовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem журналВыходаАртистовНаРаботуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчет1ToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem отчетОбАртистахToolStripMenuItem;
    }
}

