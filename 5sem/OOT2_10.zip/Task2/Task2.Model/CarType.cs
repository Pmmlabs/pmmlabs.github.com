﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Task2.Model
{
    public class CarType
    {
        [XmlAttribute]
        public string TypeName { get; set; }

        [XmlAttribute]
        public short MaxWeight { get; set; }

        public CarType()
        {
        }

        public CarType(string aTypeName, short aMaxWeight)
        {
            TypeName = aTypeName;
            MaxWeight = aMaxWeight;
        }
    }
}
