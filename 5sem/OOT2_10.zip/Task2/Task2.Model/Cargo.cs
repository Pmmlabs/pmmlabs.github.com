﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task2.Model
{
   public class Cargo
    {
        public string CargoName { get; set; }

        public CargoType Type { get; set; }

        public Customer CustomerSender { get; set; }

        public Customer CustomerReciever { get; set; }

        public int CargoWeight { get; set; }

        public City CityFrom { get; set; }

        public City CityTo { get; set; }

        public DateTime SendDate { get; set; }

        public CargoStatus Status { get; set; }

        public List<Road> Path { get; set; }

        public Car CarDelivery { get; set; }

       public List<Road> CarPath { get; set; }

       public Cargo()
        {
            Path = new List<Road>();
        }

        public Cargo(string aCargoName, CargoType aType, Customer aCustomerSender, Customer aCustomerReciever,
            int aCargoWeight, City aCityFrom, City aCityTo, DateTime aSendDate,CargoStatus aStatus)
        {
            CargoName = aCargoName;
            Type = aType;
            CustomerSender = aCustomerSender;
            CustomerReciever = aCustomerReciever;
            CargoWeight = aCargoWeight;
            CityFrom = aCityFrom;
            CityTo = aCityTo;
            SendDate = aSendDate;
            Status = aStatus;
            Path = new List<Road>();
        }
    }
}
