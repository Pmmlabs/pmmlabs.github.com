﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Task2.Model
{
    public class City
    {
        [XmlAttribute]
        public string CityName { get; set; }

        [XmlAttribute]
        public string OficeAddress { get; set; }

        public City()
        {
        }

        public City(string aCityName, string aOficeAddress)
        {
            CityName = aCityName;
            OficeAddress = aOficeAddress;
        }
    }
}
