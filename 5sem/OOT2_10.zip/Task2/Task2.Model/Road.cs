﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Task2.Model
{
    public class Road
    {
        public City CityFrom { get; set; }

        public City CityTo { get; set; }

        [XmlAttribute]
        public int Distance { get; set; }

        public Road()
        {
        }

        public Road(City aCityFrom, City aCityTo, int aDistance)
        {
            CityFrom = aCityFrom;
            CityTo = aCityTo;
            Distance = aDistance;
        }
    }
}
