﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Task2.Model
{
    public class CargoType
    {
        [XmlAttribute]
        public string TypeName { get; set; }
        [XmlAttribute]
        public int MaxWeight { get; set; }

        public CargoType()
        {
        }

        public CargoType(string aTypeName, int aMaxWeight)
        {
            TypeName = aTypeName;
            MaxWeight = aMaxWeight;
        }
    }
}
