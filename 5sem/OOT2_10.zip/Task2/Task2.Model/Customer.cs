﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Task2.Model
{
    public class Customer
    {
        [XmlAttribute]
        public string FirstName { get; set; }

        [XmlAttribute]
        public string LastName { get; set; }

        public Customer()
        {
        }

        public Customer(string aFirstName, string aLastName)
        {
            FirstName = aFirstName;
            LastName = aLastName;
        }
    }
}
