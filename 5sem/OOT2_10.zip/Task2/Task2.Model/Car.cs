﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Task2.Model
{
    public class Car
    {

        public CarType Type { get; set; }

        [XmlAttribute]
        public string Driver { get; set; }

        [XmlAttribute]
        public string LisencePlate { get; set; }

        public City CurrentCity { get; set; }

        public bool Busy { get; set; }

        public Car()
        {
            CurrentCity = new City("Воронеж","Пр. Революции, д. 1");
        }

        public Car(CarType aType, string aDriver, string aLisencePlate, City aCurrentCity)
        {
            Type = aType;
            Driver = aDriver;
            LisencePlate = aLisencePlate;
            CurrentCity = aCurrentCity;
        }    
    }
}
