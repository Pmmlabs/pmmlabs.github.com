﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace Task2.Model
{
    [XmlRoot]
    public class Manager
    {

        [XmlArray]
        public List<Car> Cars { get; set; }

        [XmlArray]
        public List<CarType> CarTypes { get; set; }

        [XmlArray]
        public List<City> Cities { get; set; }

        [XmlArray]
        public List<Road> Roads { get; set; }

        [XmlArray]
        public List<CargoType> CargoTypes { get; set; }

        [XmlArray]
        public List<Customer> Customers { get; set; }


        public List<Cargo> Cargoes { get; set; }

        public Manager()
        {
            Cars = new List<Car>();
            CarTypes = new List<CarType>();

            Cities = new List<City>();
            Roads = new List<Road>();

            Cargoes = new List<Cargo>();
            CargoTypes = new List<CargoType>();

            Customers = new List<Customer>();
        }

        public List<Road> FindPath(City aCityFrom, City aCityTo)
        {
            List<Road> path = new List<Road>();
            foreach (var road in Roads)
            {
               if ( (aCityFrom.CityName == road.CityFrom.CityName && aCityTo.CityName == road.CityTo.CityName)
                   || (aCityTo.CityName == road.CityFrom.CityName && aCityFrom.CityName == road.CityTo.CityName))
               {
                   path.Add(road);
                   return path;
               }
            }
            path.Add(Roads.FirstOrDefault(x => (x.CityFrom.CityName == aCityFrom.CityName && x.CityTo.CityName == "Воронеж") 
                || (x.CityTo.CityName == aCityFrom.CityName && x.CityFrom.CityName == "Воронеж") ));

            path.Add(Roads.FirstOrDefault(x => (x.CityTo.CityName == aCityTo.CityName && x.CityFrom.CityName == "Воронеж")
                || (x.CityFrom.CityName == aCityTo.CityName && x.CityTo.CityName == "Воронеж")));
            return path;
        }

        public void FindCar( ref Cargo aCargo)
        {
            Car car = new Car();
            int weight = aCargo.CargoWeight;
            car = Cars.FirstOrDefault(x => x.Type.MaxWeight >= weight && !x.Busy);
            if (car != null)
            {
                Cars[Cars.IndexOf(car)].Busy = true;
                aCargo.CarDelivery = car;
                aCargo.Status = CargoStatus.WaitCar;

                if (aCargo.CarDelivery.CurrentCity.CityName != aCargo.CityFrom.CityName)
                {
                    aCargo.CarPath = FindPath(aCargo.CarDelivery.CurrentCity, aCargo.CityFrom);
                }
                else
                {
                    aCargo.Status = CargoStatus.CarInCargoCity;
                }
            }
            else
            {
                aCargo.Status = CargoStatus.CarIsBusy;
            }
        }

        public Cargo NewCargo(Random aRandom, int aMaxCargoWeight)
        {
            int c1 = aRandom.Next(Customers.Count);
            int c2;
            int n1 = aRandom.Next(Cities.Count);
            int n2;
            Cargo cargo = new Cargo();
            cargo.CargoWeight = aRandom.Next(aMaxCargoWeight);
            cargo.CustomerSender = Customers[c1];
            cargo.CityFrom = Cities[n1];

            c2 = aRandom.Next(Customers.Count);
            while (c1 == c2)
            {
                c2 = aRandom.Next(Customers.Count);
            }
            cargo.CustomerReciever = Customers[c2];

            n2 = aRandom.Next(Cities.Count);
            while (n1 == n2)
            {
                n2 = aRandom.Next(Cities.Count);
            }
            cargo.CityTo = Cities[n2];

            return cargo;
        }

        public void Serialize()
        {
            XmlSerializer ser = new XmlSerializer(typeof(Manager));
            TextWriter writer = new StreamWriter("Manager.xml");
            ser.Serialize(writer, this);
            writer.Close();
        }

        public static Manager Deserialize()
        {
            XmlReader reader = new XmlTextReader("Manager.xml");
            XmlSerializer serializer = new XmlSerializer(typeof(Manager));
            Manager manager = (Manager)serializer.Deserialize(reader);
            reader.Close();
            return manager;
        }
    }
}
