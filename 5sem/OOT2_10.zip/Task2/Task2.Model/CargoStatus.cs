﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task2.Model
{
    public enum CargoStatus
    {
        CarIsBusy, // все машины заняты,ждем пока хотя бы одна освободится
        WaitCar, // машина нашлась,но в другом городе и она в пути к городу из которого отправится груз
        EmptyCarOnTheWay, // пустая машина едет за грузом
        CarInCargoCity, // машина в городе, откуда отправляется груз
        FullCarOnTheWay, // машина доставляет груз
        Shiped // доставлен груз
    }

    public class Status
    {
        public static string GetStatus(CargoStatus aCargoStatus)
        {
            switch(aCargoStatus)
            {
                case CargoStatus.CarIsBusy:
                    return "Все машины заняты";
                case CargoStatus.WaitCar:
                    return "Ожидает машину";
                case CargoStatus.EmptyCarOnTheWay:
                    return "Машина едет за грузом";
                case CargoStatus.CarInCargoCity:
                    return "Машина в городе отправки груза";
                case CargoStatus.FullCarOnTheWay:
                    return "Машина едет с грузом";
                case CargoStatus.Shiped:
                    return "Доставлено";
                default:
                    throw new ArgumentOutOfRangeException("aCargoStatus");
            }
        }
    }
}
