﻿namespace Task2
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tmrWork = new System.Windows.Forms.Timer(this.components);
            this.GridResult = new System.Windows.Forms.DataGridView();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnPause = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Number = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerSender = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CityFrom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CityTo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerReciever = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Path = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CargoWeight = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CarDelivery = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CurrentCityCar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.GridResult)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tmrWork
            // 
            this.tmrWork.Interval = 1000;
            this.tmrWork.Tick += new System.EventHandler(this.tmrWork_Tick);
            // 
            // GridResult
            // 
            this.GridResult.AllowUserToAddRows = false;
            this.GridResult.AllowUserToDeleteRows = false;
            this.GridResult.AllowUserToResizeRows = false;
            this.GridResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridResult.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Number,
            this.CustomerSender,
            this.CityFrom,
            this.CityTo,
            this.CustomerReciever,
            this.Path,
            this.CargoWeight,
            this.CarDelivery,
            this.CurrentCityCar,
            this.Status});
            this.GridResult.Location = new System.Drawing.Point(12, 3);
            this.GridResult.Name = "GridResult";
            this.GridResult.RowHeadersVisible = false;
            this.GridResult.Size = new System.Drawing.Size(1473, 546);
            this.GridResult.TabIndex = 1;
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(3, 3);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 2;
            this.btnStart.Text = "Старт";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnPause
            // 
            this.btnPause.Location = new System.Drawing.Point(84, 3);
            this.btnPause.Name = "btnPause";
            this.btnPause.Size = new System.Drawing.Size(75, 23);
            this.btnPause.TabIndex = 3;
            this.btnPause.Text = "Пауза";
            this.btnPause.UseVisualStyleBackColor = true;
            this.btnPause.Click += new System.EventHandler(this.btnPause_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(165, 3);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(75, 23);
            this.btnStop.TabIndex = 4;
            this.btnStop.Text = "Стоп";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(246, 3);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Очистить";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnClear);
            this.panel1.Controls.Add(this.btnStart);
            this.panel1.Controls.Add(this.btnPause);
            this.panel1.Controls.Add(this.btnStop);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1497, 35);
            this.panel1.TabIndex = 6;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.GridResult);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 41);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1497, 561);
            this.panel2.TabIndex = 7;
            // 
            // Number
            // 
            this.Number.HeaderText = "№";
            this.Number.Name = "Number";
            this.Number.ReadOnly = true;
            this.Number.Width = 40;
            // 
            // CustomerSender
            // 
            this.CustomerSender.FillWeight = 150F;
            this.CustomerSender.HeaderText = "Заказчик";
            this.CustomerSender.MinimumWidth = 15;
            this.CustomerSender.Name = "CustomerSender";
            this.CustomerSender.ReadOnly = true;
            this.CustomerSender.Width = 150;
            // 
            // CityFrom
            // 
            this.CityFrom.HeaderText = "Откуда";
            this.CityFrom.Name = "CityFrom";
            this.CityFrom.ReadOnly = true;
            this.CityFrom.Width = 180;
            // 
            // CityTo
            // 
            this.CityTo.HeaderText = "Куда";
            this.CityTo.Name = "CityTo";
            this.CityTo.ReadOnly = true;
            this.CityTo.Width = 180;
            // 
            // CustomerReciever
            // 
            this.CustomerReciever.HeaderText = "Получатель";
            this.CustomerReciever.Name = "CustomerReciever";
            this.CustomerReciever.ReadOnly = true;
            this.CustomerReciever.Width = 150;
            // 
            // Path
            // 
            this.Path.HeaderText = "Путь";
            this.Path.Name = "Path";
            this.Path.ReadOnly = true;
            this.Path.Width = 200;
            // 
            // CargoWeight
            // 
            this.CargoWeight.HeaderText = "Вес груза";
            this.CargoWeight.Name = "CargoWeight";
            this.CargoWeight.ReadOnly = true;
            // 
            // CarDelivery
            // 
            this.CarDelivery.HeaderText = "Машина для доставки";
            this.CarDelivery.Name = "CarDelivery";
            this.CarDelivery.ReadOnly = true;
            this.CarDelivery.Width = 150;
            // 
            // CurrentCityCar
            // 
            this.CurrentCityCar.HeaderText = "Машина в";
            this.CurrentCityCar.Name = "CurrentCityCar";
            this.CurrentCityCar.ReadOnly = true;
            // 
            // Status
            // 
            this.Status.FillWeight = 190F;
            this.Status.HeaderText = "Статус";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.Width = 180;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1497, 602);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "FrmMain";
            this.Text = "Задача №2 \"Грузоперевозки\"";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GridResult)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer tmrWork;
        private System.Windows.Forms.DataGridView GridResult;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnPause;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Number;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerSender;
        private System.Windows.Forms.DataGridViewTextBoxColumn CityFrom;
        private System.Windows.Forms.DataGridViewTextBoxColumn CityTo;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerReciever;
        private System.Windows.Forms.DataGridViewTextBoxColumn Path;
        private System.Windows.Forms.DataGridViewTextBoxColumn CargoWeight;
        private System.Windows.Forms.DataGridViewTextBoxColumn CarDelivery;
        private System.Windows.Forms.DataGridViewTextBoxColumn CurrentCityCar;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
    }
}

