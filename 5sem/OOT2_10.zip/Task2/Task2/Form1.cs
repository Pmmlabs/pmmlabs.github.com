﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Task2.Model;

namespace Task2
{
    public partial class FrmMain : Form
    {
        private Manager manager;
        private Random rnd = new Random();
        private int maxCargoWeight;
        private bool TimerState = true;

        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            Clear();
        }


        //Manager one = new Manager();
        //one.Cars.Add(new Car(new CarType("str", 10), "Ivanov", "t147to"));
        //one.CarTypes.Add(new CarType("str", 10));
        //one.Cities.Add(new City("City1","Address1"));
        //one.Roads.Add(new Road(new City("City2","Address2"), new City("City3","Address3"), 500));
        //one.CargoTypes.Add(new CargoType("type"));
        //one.Customers.Add(new Customer("First", "Last"));
        //one.Serialize();

        //Manager one = Manager.Deserialize();


        private void btnPause_Click(object sender, EventArgs e)
        {
            btnClear.Enabled = true;
            btnStop.Enabled = false;
            tmrWork.Enabled = false;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            btnPause.Enabled = false;
            btnClear.Enabled = true;
            tmrWork.Enabled = false;
            Clear();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            btnClear.Enabled = false;
            btnPause.Enabled = true;
            btnStop.Enabled = true;
            tmrWork.Enabled = true;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void Clear()
        {
            btnPause.Enabled = false;
            btnStop.Enabled = false;
            GridResult.Rows.Clear();
            tmrWork.Enabled = false;
            TimerState = true;
            manager = Manager.Deserialize();
            maxCargoWeight = manager.CargoTypes.Max(x => x.MaxWeight);
        }

        private void tmrWork_Tick(object sender, EventArgs e)
        {
            if (TimerState)
            {
                int count = GridResult.Rows.Add();
                GridResult.CurrentCell.Selected = false;
                GridResult.CurrentCell = GridResult.Rows[count].Cells["Number"];
                GridResult.Rows[count].Cells["Number"].Selected = true;

                Cargo cargo = manager.NewCargo(rnd, maxCargoWeight);

                cargo.Path = manager.FindPath(cargo.CityFrom, cargo.CityTo);

                manager.FindCar(ref cargo);

                manager.Cargoes.Add(cargo);

                GridResult.Rows[count].Cells["Number"].Value = count + 1;
                GridResult.Rows[count].Cells["CargoWeight"].Value = cargo.CargoWeight;
                GridResult.Rows[count].Cells["CustomerSender"].Value = cargo.CustomerSender.LastName + " " +
                                                                       cargo.CustomerSender.FirstName;
                GridResult.Rows[count].Cells["CustomerReciever"].Value = cargo.CustomerReciever.LastName + " " +
                                                                         cargo.CustomerReciever.FirstName;
                GridResult.Rows[count].Cells["CityFrom"].Value = cargo.CityFrom.CityName + ", " +
                                                                 cargo.CityFrom.OficeAddress;
                GridResult.Rows[count].Cells["CityTo"].Value = cargo.CityTo.CityName + ", " + cargo.CityTo.OficeAddress;

                if (cargo.Path.Count == 1)
                {
                    GridResult.Rows[count].Cells["Path"].Value += cargo.CityFrom.CityName + " - " +
                                                                  cargo.CityTo.CityName +
                                                                  " (" + cargo.Path[0].Distance + ")";
                }
                else
                {
                    if (cargo.Path[0].CityFrom.CityName == cargo.CityFrom.CityName ||
                        cargo.Path[0].CityTo.CityName == cargo.CityFrom.CityName)
                    {
                        GridResult.Rows[count].Cells["Path"].Value += cargo.CityFrom.CityName + " - Воронеж";
                    }
                    if (cargo.Path[1].CityFrom.CityName == cargo.CityTo.CityName ||
                        cargo.Path[1].CityTo.CityName == cargo.CityTo.CityName)
                    {
                        GridResult.Rows[count].Cells["Path"].Value += " - " + cargo.CityTo.CityName;
                    }
                    GridResult.Rows[count].Cells["Path"].Value += " (" + (cargo.Path.Sum(x => x.Distance)) + ")";
                }

                if (cargo.Status != CargoStatus.CarIsBusy)
                {
                    GridResult.Rows[count].Cells["CarDelivery"].Value = cargo.CarDelivery.Driver + " " +
                                                                        cargo.CarDelivery.LisencePlate + " " +
                                                                        cargo.CarDelivery.Type.MaxWeight;
                    GridResult.Rows[count].Cells["CurrentCityCar"].Value = cargo.CarDelivery.CurrentCity.CityName;
                }
                else
                {
                    GridResult.Rows[count].Cells["Status"].Style.ForeColor = Color.Red;
                }

                GridResult.Rows[count].Cells["Status"].Value = Model.Status.GetStatus(cargo.Status);
                TimerState = false;
            }
            else
            {
                for (int i = 0; i < manager.Cargoes.Count; i++)
                {
                    if (manager.Cargoes[i].Status == CargoStatus.Shiped) continue;
                    Cargo cargo = manager.Cargoes[i];
                    switch (cargo.Status)
                    {
                        case CargoStatus.CarIsBusy:
                            manager.FindCar(ref cargo);

                            if (cargo.Status != CargoStatus.CarIsBusy)
                            {
                                GridResult.Rows[i].Cells["CarDelivery"].Value = cargo.CarDelivery.Driver + " " +
                                                                                cargo.CarDelivery.LisencePlate + " " +
                                                                                cargo.CarDelivery.Type.MaxWeight;
                                GridResult.Rows[i].Cells["CurrentCityCar"].Value = cargo.CarDelivery.CurrentCity.CityName;
                                GridResult.Rows[i].Cells["Status"].Style.ForeColor = Color.Black;
                            }
                            else
                            {
                                GridResult.Rows[i].Cells["Status"].Style.ForeColor = Color.Red;
                            }
                            GridResult.Rows[i].Cells["Status"].Value = Model.Status.GetStatus(cargo.Status);
                            break;
                        case CargoStatus.WaitCar:
                            if (cargo.CarPath.Count == 1)
                            {
                                manager.Cars[manager.Cars.IndexOf(cargo.CarDelivery)].CurrentCity = cargo.CityFrom;
                                cargo.CarDelivery.CurrentCity = cargo.CityFrom;
                                cargo.Status = CargoStatus.CarInCargoCity;
                            }
                            else if (cargo.CarPath.Count == 2)
                            {
                                manager.Cars[manager.Cars.IndexOf(cargo.CarDelivery)].CurrentCity =
                                    (cargo.CarPath[0].CityFrom == cargo.CarDelivery.CurrentCity)
                                        ? cargo.CarPath[0].CityTo
                                        : cargo.CarPath[0].CityFrom;

                                cargo.CarDelivery.CurrentCity =
                                    manager.Cars[manager.Cars.IndexOf(cargo.CarDelivery)].CurrentCity;
                                cargo.Status = CargoStatus.EmptyCarOnTheWay;
                            }

                            GridResult.Rows[i].Cells["CurrentCityCar"].Value = cargo.CarDelivery.CurrentCity.CityName;
                            GridResult.Rows[i].Cells["Status"].Value = Model.Status.GetStatus(cargo.Status);
                            break;
                        case CargoStatus.EmptyCarOnTheWay:
                            manager.Cars[manager.Cars.IndexOf(cargo.CarDelivery)].CurrentCity = cargo.CityFrom;
                            cargo.CarDelivery.CurrentCity = cargo.CityFrom;
                            cargo.Status = CargoStatus.CarInCargoCity;

                            GridResult.Rows[i].Cells["CurrentCityCar"].Value = cargo.CarDelivery.CurrentCity.CityName;
                            GridResult.Rows[i].Cells["Status"].Value = Model.Status.GetStatus(cargo.Status);
                            break;
                        case CargoStatus.CarInCargoCity:
                            if (cargo.Path.Count == 1)
                            {
                                manager.Cars[manager.Cars.IndexOf(cargo.CarDelivery)].CurrentCity = cargo.CityTo;
                                cargo.CarDelivery.CurrentCity = cargo.CityTo;
                                cargo.Status = CargoStatus.Shiped;
                                GridResult.Rows[i].Cells["Status"].Style.ForeColor = Color.DarkGreen;
                                manager.Cars[manager.Cars.IndexOf(cargo.CarDelivery)].Busy = false;
                                cargo.CarDelivery.Busy = false;
                            }
                            else if (cargo.Path.Count == 2)
                            {
                                manager.Cars[manager.Cars.IndexOf(cargo.CarDelivery)].CurrentCity =
                                    (cargo.Path[0].CityFrom == cargo.CarDelivery.CurrentCity)
                                        ? cargo.Path[0].CityTo
                                        : cargo.Path[0].CityFrom;

                                cargo.CarDelivery.CurrentCity =
                                    manager.Cars[manager.Cars.IndexOf(cargo.CarDelivery)].CurrentCity;
                                cargo.Status = CargoStatus.FullCarOnTheWay;
                            }

                            GridResult.Rows[i].Cells["CurrentCityCar"].Value = cargo.CarDelivery.CurrentCity.CityName;
                            GridResult.Rows[i].Cells["Status"].Value = Model.Status.GetStatus(cargo.Status);
                            break;
                        case CargoStatus.FullCarOnTheWay:
                                manager.Cars[manager.Cars.IndexOf(cargo.CarDelivery)].CurrentCity = cargo.CityTo;
                                cargo.CarDelivery.CurrentCity = cargo.CityTo;
                                cargo.Status = CargoStatus.Shiped;
                                GridResult.Rows[i].Cells["Status"].Style.ForeColor = Color.DarkGreen;
                                manager.Cars[manager.Cars.IndexOf(cargo.CarDelivery)].Busy = false;
                                cargo.CarDelivery.Busy = false;

                                GridResult.Rows[i].Cells["CurrentCityCar"].Value = cargo.CarDelivery.CurrentCity.CityName;
                                GridResult.Rows[i].Cells["Status"].Value = Model.Status.GetStatus(cargo.Status);
                            break;
                    }
                }
                TimerState = true;
            }
        }
    }
}
