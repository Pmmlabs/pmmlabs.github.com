﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AppClasses
{
    public class ClassLetter : ClassMail
    {
        private string FWords;
        private bool FRegistered;

        public string Words
        {
            get
            {
                return FWords;
            }
            set
            {
                FWords = value;
            }
        }
        public bool Registered
        {
            get
            {
                return FRegistered;
            }
            set
            {
                FRegistered = value;
            }
        }
        public ClassLetter() : base()
        {
            FWords = "";
            FRegistered = false;
        }
        public override string ToString()
        {
            
            if (FRegistered)
                return "Письмо. " + base.ToString() + "  Текст: " + FWords + "  Заказное";
            else
                return "Письмо. " + base.ToString() + "  Текст: " + FWords + "  Обычное";
        }
    }
}
