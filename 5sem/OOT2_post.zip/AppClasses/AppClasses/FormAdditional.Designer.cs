﻿namespace AppClasses
{
    partial class FormAdditional
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonOk = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.textBoxAddressee = new System.Windows.Forms.TextBox();
            this.labelAddressee = new System.Windows.Forms.Label();
            this.labelSender = new System.Windows.Forms.Label();
            this.textBoxSender = new System.Windows.Forms.TextBox();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.labelDateOfSending = new System.Windows.Forms.Label();
            this.checkBoxRegistered = new System.Windows.Forms.CheckBox();
            this.textBoxWords = new System.Windows.Forms.TextBox();
            this.labelSum = new System.Windows.Forms.Label();
            this.textBoxSum = new System.Windows.Forms.TextBox();
            this.labelWeight = new System.Windows.Forms.Label();
            this.textBoxWeight = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonOk
            // 
            this.buttonOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonOk.Location = new System.Drawing.Point(33, 224);
            this.buttonOk.Name = "buttonOk";
            this.buttonOk.Size = new System.Drawing.Size(75, 23);
            this.buttonOk.TabIndex = 1;
            this.buttonOk.Text = "Ok";
            this.buttonOk.UseVisualStyleBackColor = true;
            // 
            // buttonCancel
            // 
            this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancel.Location = new System.Drawing.Point(318, 226);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonCancel.TabIndex = 2;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            // 
            // textBoxAddressee
            // 
            this.textBoxAddressee.Location = new System.Drawing.Point(34, 32);
            this.textBoxAddressee.Name = "textBoxAddressee";
            this.textBoxAddressee.Size = new System.Drawing.Size(100, 20);
            this.textBoxAddressee.TabIndex = 3;
            // 
            // labelAddressee
            // 
            this.labelAddressee.AutoSize = true;
            this.labelAddressee.Location = new System.Drawing.Point(36, 14);
            this.labelAddressee.Name = "labelAddressee";
            this.labelAddressee.Size = new System.Drawing.Size(66, 13);
            this.labelAddressee.TabIndex = 4;
            this.labelAddressee.Text = "Получатель";
            // 
            // labelSender
            // 
            this.labelSender.AutoSize = true;
            this.labelSender.Location = new System.Drawing.Point(36, 72);
            this.labelSender.Name = "labelSender";
            this.labelSender.Size = new System.Drawing.Size(73, 13);
            this.labelSender.TabIndex = 5;
            this.labelSender.Text = "Отправитель";
            // 
            // textBoxSender
            // 
            this.textBoxSender.Location = new System.Drawing.Point(34, 88);
            this.textBoxSender.Name = "textBoxSender";
            this.textBoxSender.Size = new System.Drawing.Size(100, 20);
            this.textBoxSender.TabIndex = 6;
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(34, 142);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(132, 20);
            this.dateTimePicker.TabIndex = 7;
            // 
            // labelDateOfSending
            // 
            this.labelDateOfSending.AutoSize = true;
            this.labelDateOfSending.Location = new System.Drawing.Point(36, 126);
            this.labelDateOfSending.Name = "labelDateOfSending";
            this.labelDateOfSending.Size = new System.Drawing.Size(101, 13);
            this.labelDateOfSending.TabIndex = 8;
            this.labelDateOfSending.Text = "Дата отправления";
            // 
            // checkBoxRegistered
            // 
            this.checkBoxRegistered.AutoSize = true;
            this.checkBoxRegistered.Location = new System.Drawing.Point(227, 71);
            this.checkBoxRegistered.Name = "checkBoxRegistered";
            this.checkBoxRegistered.Size = new System.Drawing.Size(75, 17);
            this.checkBoxRegistered.TabIndex = 10;
            this.checkBoxRegistered.Text = "Заказное";
            this.checkBoxRegistered.UseVisualStyleBackColor = true;
            // 
            // textBoxWords
            // 
            this.textBoxWords.Location = new System.Drawing.Point(227, 32);
            this.textBoxWords.Name = "textBoxWords";
            this.textBoxWords.Size = new System.Drawing.Size(166, 20);
            this.textBoxWords.TabIndex = 11;
            this.textBoxWords.Text = "Текст письма";
            // 
            // labelSum
            // 
            this.labelSum.AutoSize = true;
            this.labelSum.Location = new System.Drawing.Point(231, 113);
            this.labelSum.Name = "labelSum";
            this.labelSum.Size = new System.Drawing.Size(92, 13);
            this.labelSum.TabIndex = 12;
            this.labelSum.Text = "Сумма перевода";
            // 
            // textBoxSum
            // 
            this.textBoxSum.Location = new System.Drawing.Point(227, 129);
            this.textBoxSum.Name = "textBoxSum";
            this.textBoxSum.Size = new System.Drawing.Size(166, 20);
            this.textBoxSum.TabIndex = 13;
            // 
            // labelWeight
            // 
            this.labelWeight.AutoSize = true;
            this.labelWeight.Location = new System.Drawing.Point(231, 166);
            this.labelWeight.Name = "labelWeight";
            this.labelWeight.Size = new System.Drawing.Size(73, 13);
            this.labelWeight.TabIndex = 14;
            this.labelWeight.Text = "Вес посылки";
            // 
            // textBoxWeight
            // 
            this.textBoxWeight.Location = new System.Drawing.Point(227, 182);
            this.textBoxWeight.Name = "textBoxWeight";
            this.textBoxWeight.Size = new System.Drawing.Size(166, 20);
            this.textBoxWeight.TabIndex = 15;
            // 
            // FormAdditional
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(448, 272);
            this.Controls.Add(this.textBoxWeight);
            this.Controls.Add(this.labelWeight);
            this.Controls.Add(this.textBoxSum);
            this.Controls.Add(this.labelSum);
            this.Controls.Add(this.textBoxWords);
            this.Controls.Add(this.checkBoxRegistered);
            this.Controls.Add(this.labelDateOfSending);
            this.Controls.Add(this.dateTimePicker);
            this.Controls.Add(this.textBoxSender);
            this.Controls.Add(this.labelSender);
            this.Controls.Add(this.labelAddressee);
            this.Controls.Add(this.textBoxAddressee);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonOk);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "FormAdditional";
            this.Text = "Добавить";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonOk;
        private System.Windows.Forms.Button buttonCancel;
        public System.Windows.Forms.TextBox textBoxAddressee;
        public System.Windows.Forms.Label labelAddressee;
        public System.Windows.Forms.Label labelSender;
        public System.Windows.Forms.TextBox textBoxSender;
        public System.Windows.Forms.DateTimePicker dateTimePicker;
        public System.Windows.Forms.Label labelDateOfSending;
        public System.Windows.Forms.CheckBox checkBoxRegistered;
        public System.Windows.Forms.TextBox textBoxWords;
        public System.Windows.Forms.Label labelSum;
        public System.Windows.Forms.TextBox textBoxSum;
        public System.Windows.Forms.Label labelWeight;
        public System.Windows.Forms.TextBox textBoxWeight;
    }
}