﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AppClasses
{
    public class ClassOrder : ClassMail
    {
        private double FSum;

        public double Sum
        {
            get
            {
                return FSum;
            }
            set
            {
                FSum = value;
            }
        }

        public ClassOrder() : base()
        {
            FSum = 0;
        }

        public override string ToString()
        {
            return "Перевод. " + base.ToString() + "  Сумма: " + FSum.ToString();
        }
    }
}
