﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AppClasses
{
    public partial class ClassList
    {
        private List<ClassMail> FList;

        public ClassList()
        {
            FList = new List<ClassMail>();
        }

        public void Add(ClassMail elem)
        {
            FList.Add(elem);
        }
        public void Delete(int index)
        {
            FList.RemoveAt(index);
        }
        public int Find(ClassMail elem)
        {
            return FList.IndexOf(elem);
        }
        public List<string> GetStringList()
        {
            List<string> res = new List<string>();
            foreach (ClassMail elem in FList)
            {
                res.Add(elem.ToString());
            }
            return res;
        }
        public int Count
        {
            get
            {
                return FList.Count();
            }
        }
    }
}
