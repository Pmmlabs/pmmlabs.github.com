﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AppClasses
{
    public partial class FormType : Form
    {
        public ClassMail mail;

        public FormType()
        {
            InitializeComponent();
        }

        private void buttonOk_Click(object sender, EventArgs e)
        {
            FormAdditional FormAdd = new FormAdditional();
            FormAdd.Text = Text;
            FormAdd.labelSum.Visible = radioButtonOrder.Checked;
            FormAdd.textBoxSum.Visible = radioButtonOrder.Checked;
            FormAdd.labelWeight.Visible = radioButtonSending.Checked;
            FormAdd.textBoxWeight.Visible = radioButtonSending.Checked;
            FormAdd.checkBoxRegistered.Visible = radioButtonLetter.Checked;
            FormAdd.textBoxWords.Visible = radioButtonLetter.Checked;
            FormAdd.ShowDialog();
            if (FormAdd.DialogResult == System.Windows.Forms.DialogResult.OK)
            {
                try
                {
                    if (radioButtonLetter.Checked)
                    {
                        mail = new ClassLetter();
                        mail.Addressee = FormAdd.textBoxAddressee.Text;
                        mail.Sender = FormAdd.textBoxSender.Text;
                        mail.DateOfSending = FormAdd.dateTimePicker.Value;
                        (mail as ClassLetter).Words = FormAdd.textBoxWords.Text;
                        (mail as ClassLetter).Registered = FormAdd.checkBoxRegistered.Checked;
                    }
                    else
                        if (radioButtonOrder.Checked)
                        {
                            mail = new ClassOrder();
                            mail.Addressee = FormAdd.textBoxAddressee.Text;
                            mail.Sender = FormAdd.textBoxSender.Text;
                            mail.DateOfSending = FormAdd.dateTimePicker.Value;
                            (mail as ClassOrder).Sum = Convert.ToDouble(FormAdd.textBoxSum.Text);
                        }
                        else
                            if (radioButtonSending.Checked)
                            {
                                mail = new ClassSending();
                                mail.Addressee = FormAdd.textBoxAddressee.Text;
                                mail.Sender = FormAdd.textBoxSender.Text;
                                mail.DateOfSending = FormAdd.dateTimePicker.Value;
                                (mail as ClassSending).Weight = Convert.ToDouble(FormAdd.textBoxWeight.Text);
                            }
                    DialogResult = System.Windows.Forms.DialogResult.OK;
                }
                catch
                {
                    DialogResult = System.Windows.Forms.DialogResult.Cancel;
                    MessageBox.Show("Ошибка! Попробуйте повторить ввод.");
                }
            }
            else
                DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }
    }
}
