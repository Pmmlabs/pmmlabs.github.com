﻿namespace AppClasses
{
    partial class FormFeildSearch
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox = new System.Windows.Forms.GroupBox();
            this.radioButtonAllField = new System.Windows.Forms.RadioButton();
            this.radioButtonDate = new System.Windows.Forms.RadioButton();
            this.radioButtonSender = new System.Windows.Forms.RadioButton();
            this.radioButtonAddressee = new System.Windows.Forms.RadioButton();
            this.buttonOk = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.groupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox
            // 
            this.groupBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox.Controls.Add(this.radioButtonAllField);
            this.groupBox.Controls.Add(this.radioButtonDate);
            this.groupBox.Controls.Add(this.radioButtonSender);
            this.groupBox.Controls.Add(this.radioButtonAddressee);
            this.groupBox.Location = new System.Drawing.Point(12, 12);
            this.groupBox.Name = "groupBox";
            this.groupBox.Size = new System.Drawing.Size(267, 184);
            this.groupBox.TabIndex = 0;
            this.groupBox.TabStop = false;
            this.groupBox.Text = "Критерий поиска";
            // 
            // radioButtonAllField
            // 
            this.radioButtonAllField.AutoSize = true;
            this.radioButtonAllField.Location = new System.Drawing.Point(32, 143);
            this.radioButtonAllField.Name = "radioButtonAllField";
            this.radioButtonAllField.Size = new System.Drawing.Size(101, 17);
            this.radioButtonAllField.TabIndex = 3;
            this.radioButtonAllField.TabStop = true;
            this.radioButtonAllField.Text = "по всем полям";
            this.radioButtonAllField.UseVisualStyleBackColor = true;
            // 
            // radioButtonDate
            // 
            this.radioButtonDate.AutoSize = true;
            this.radioButtonDate.Location = new System.Drawing.Point(32, 107);
            this.radioButtonDate.Name = "radioButtonDate";
            this.radioButtonDate.Size = new System.Drawing.Size(131, 17);
            this.radioButtonDate.TabIndex = 2;
            this.radioButtonDate.TabStop = true;
            this.radioButtonDate.Text = "по дате отправления";
            this.radioButtonDate.UseVisualStyleBackColor = true;
            // 
            // radioButtonSender
            // 
            this.radioButtonSender.AutoSize = true;
            this.radioButtonSender.Location = new System.Drawing.Point(32, 68);
            this.radioButtonSender.Name = "radioButtonSender";
            this.radioButtonSender.Size = new System.Drawing.Size(106, 17);
            this.radioButtonSender.TabIndex = 1;
            this.radioButtonSender.TabStop = true;
            this.radioButtonSender.Text = "по отправителю";
            this.radioButtonSender.UseVisualStyleBackColor = true;
            // 
            // radioButtonAddressee
            // 
            this.radioButtonAddressee.AutoSize = true;
            this.radioButtonAddressee.Location = new System.Drawing.Point(32, 29);
            this.radioButtonAddressee.Name = "radioButtonAddressee";
            this.radioButtonAddressee.Size = new System.Drawing.Size(99, 17);
            this.radioButtonAddressee.TabIndex = 0;
            this.radioButtonAddressee.TabStop = true;
            this.radioButtonAddressee.Text = "по получателю";
            this.radioButtonAddressee.UseVisualStyleBackColor = true;
            // 
            // buttonOk
            // 
            this.buttonOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonOk.Location = new System.Drawing.Point(22, 214);
            this.buttonOk.Name = "buttonOk";
            this.buttonOk.Size = new System.Drawing.Size(75, 23);
            this.buttonOk.TabIndex = 1;
            this.buttonOk.Text = "Ok";
            this.buttonOk.UseVisualStyleBackColor = true;
            // 
            // buttonCancel
            // 
            this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancel.Location = new System.Drawing.Point(193, 214);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonCancel.TabIndex = 2;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            // 
            // FormFeildSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(291, 251);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonOk);
            this.Controls.Add(this.groupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "FormFeildSearch";
            this.Text = "Поиск";
            this.groupBox.ResumeLayout(false);
            this.groupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox;
        public System.Windows.Forms.RadioButton radioButtonDate;
        public System.Windows.Forms.RadioButton radioButtonSender;
        public System.Windows.Forms.RadioButton radioButtonAddressee;
        public System.Windows.Forms.RadioButton radioButtonAllField;
        private System.Windows.Forms.Button buttonOk;
        private System.Windows.Forms.Button buttonCancel;
    }
}