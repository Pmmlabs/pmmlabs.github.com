﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AppClasses
{
    public class ClassMail
    {
        private string FAddressee;
        private string FSender;
        private DateTime FDateOfSending;

        public string Addressee
        {
            get
            {
                return FAddressee;
            }
            set
            {
                FAddressee = value;
            }
        }
        public string Sender
        {
            get
            {
                return FSender;
            }
            set
            {
                FSender = value;
            }
        }
        public DateTime DateOfSending
        {
            get
            {
                return FDateOfSending;
            }
            set
            {
                FDateOfSending = value;
            }
        }

        public ClassMail()
        {
            FAddressee = "";
            FSender = "";
            FDateOfSending = DateTime.Parse("01.01.01");
        }
        public override string ToString()
        {
            return "Получатель: " + FAddressee +
                "  Отправитель: " + FSender +
                "  Дата отправки: " + FDateOfSending.ToShortDateString();
        }
    }
}
