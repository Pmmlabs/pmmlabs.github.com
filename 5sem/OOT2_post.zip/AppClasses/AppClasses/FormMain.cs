﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AppClasses
{
    public partial class FormMain : Form
    {
        List<ClassMail> tmp;
        FormFeildSearch FormFS;
        FormStr FormS;
        FormType FormT;
        FormNum FormN;
        FormDate FormD;
        List<ClassMail> mailList;

        public FormMain()
        {
            InitializeComponent();
            mailList = new List<ClassMail>();
            buttonRes.Hide();
        }

        private void PrintListToDGV()
        {
            dataGridView.ColumnCount = 2;
            dataGridView.Columns[0].HeaderText = "Номер";
            dataGridView.Columns[1].HeaderText = "Информация";
            dataGridView.Columns[0].ValueType = typeof(int);
            dataGridView.Columns[1].ValueType = typeof(string);
            dataGridView.RowCount = mailList.Count;
            int i = 0;
            foreach (ClassMail x in mailList)
            {
                dataGridView.Rows[i].Cells[0].Value = i+1;
                dataGridView.Rows[i].Cells[1].Value = x.ToString();
                i++;
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            FormT = new FormType();
            FormT.Text = "Добавить";
            FormT.ShowDialog();
            if (FormT.DialogResult == System.Windows.Forms.DialogResult.OK && FormT.mail != null)
            {
                mailList.Add(FormT.mail);
                PrintListToDGV();
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            mailList.Clear();
            PrintListToDGV();
        }

        private void buttonDel_Click(object sender, EventArgs e)
        {
            FormN = new FormNum();
            FormN.numericUpDown.Maximum = mailList.Count;
            FormN.ShowDialog();
            if (FormN.DialogResult == System.Windows.Forms.DialogResult.OK)
            {
                mailList.RemoveAt(Convert.ToInt32(FormN.numericUpDown.Value)-1);
                PrintListToDGV();
            }
        }

        private bool FindAllFieldLetter(ClassMail elem)
        {
            if (elem is ClassLetter)
            {
                return elem.Addressee == FormT.mail.Addressee &&
                    elem.Sender == FormT.mail.Sender &&
                    elem.DateOfSending.Date == FormT.mail.DateOfSending.Date &&
                    (elem as ClassLetter).Words == (FormT.mail as ClassLetter).Words &&
                    (elem as ClassLetter).Registered == (FormT.mail as ClassLetter).Registered;
            }
            else
                return false;
        }

        private bool FindAllFieldOrder(ClassMail elem)
        {
            if (elem is ClassOrder)
            {
                return elem.Addressee == FormT.mail.Addressee &&
                    elem.Sender == FormT.mail.Sender &&
                    elem.DateOfSending.Date == FormT.mail.DateOfSending.Date &&
                    (elem as ClassOrder).Sum == (FormT.mail as ClassOrder).Sum;
            }
            else
                return false;
        }

        private bool FindAllFieldSending(ClassMail elem)
        {
            if (elem is ClassSending)
            {
                return elem.Addressee == FormT.mail.Addressee &&
                    elem.Sender == FormT.mail.Sender &&
                    elem.DateOfSending.Date == FormT.mail.DateOfSending.Date &&
                    (elem as ClassSending).Weight == (FormT.mail as ClassSending).Weight;
            }
            else
                return false;
        }

        private bool FindAddressee(ClassMail elem)
        {
            return elem.Addressee == FormS.textBoxStr.Text;
        }

        private bool FindSender(ClassMail elem)
        {
            return elem.Sender == FormS.textBoxStr.Text;
        }

        private bool FindDate(ClassMail elem)
        {
            return elem.DateOfSending.Date == FormD.dateTimePicker.Value.Date;
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            FormFS = new FormFeildSearch();
            FormFS.ShowDialog();
            if (FormFS.DialogResult == System.Windows.Forms.DialogResult.OK)
            {
                if (FormFS.radioButtonAllField.Checked)
                {
                    FormT = new FormType();
                    FormT.Text = "Найти";
                    FormT.ShowDialog();
                    if (FormT.DialogResult == System.Windows.Forms.DialogResult.OK)
                    {
                        int i = -1;
                        if (FormT.radioButtonLetter.Checked)
                            i = mailList.FindIndex(FindAllFieldLetter);
                        else
                            if (FormT.radioButtonOrder.Checked)
                                i = mailList.FindIndex(FindAllFieldOrder);
                            else
                                if (FormT.radioButtonSending.Checked)
                                    i = mailList.FindIndex(FindAllFieldSending);
                        if (i >= 0 && i < mailList.Count)
                            MessageBox.Show("Элемент найден. Его номер " + (i + 1).ToString() + ".");
                        else
                            MessageBox.Show("Элемент не найден.");
                    }
                }
                else
                    if (FormFS.radioButtonAddressee.Checked)
                    {
                        FormS = new FormStr();
                        FormS.Text = "Поиск по получателю";
                        FormS.labelStr.Text = "Получатель";
                        FormS.ShowDialog();
                        if (FormS.DialogResult == System.Windows.Forms.DialogResult.OK)
                        {
                            tmp = mailList;
                            mailList = mailList.FindAll(FindAddressee);
                            PrintListToDGV();
                            buttonRes.Show();
                        }
                    }
                    else
                        if (FormFS.radioButtonSender.Checked)
                        {
                            FormS = new FormStr();
                            FormS.Text = "Поиск по отправителю";
                            FormS.labelStr.Text = "Отправитель";
                            FormS.ShowDialog();
                            if (FormS.DialogResult == System.Windows.Forms.DialogResult.OK)
                            {
                                tmp = mailList;
                                mailList = mailList.FindAll(FindSender);
                                PrintListToDGV();
                                buttonRes.Show();
                            }
                        }
                        else
                            if (FormFS.radioButtonDate.Checked)
                            {
                                FormD = new FormDate();
                                FormD.ShowDialog();
                                if (FormD.DialogResult == System.Windows.Forms.DialogResult.OK)
                                {
                                    tmp = mailList;
                                    mailList = mailList.FindAll(FindDate);
                                    PrintListToDGV();
                                    buttonRes.Show();
                                }
                            }
            }
        }

        private void buttonRes_Click(object sender, EventArgs e)
        {
            mailList = tmp;
            PrintListToDGV();
            buttonRes.Hide();
        }
    }
}
