﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AppClasses
{
    public class ClassSending : ClassMail
    {
        private double FWeight;

        public double Weight
        {
            get
            {
                return FWeight;
            }
            set
            {
                FWeight = value;
            }
        }

        public ClassSending() : base()
        {
            FWeight = 0;
        }

        public override string ToString()
        {
            return "Посылка. " + base.ToString() + "  Вес: " + FWeight.ToString();
        }
    }
}
