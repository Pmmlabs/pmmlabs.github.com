﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AppStack
{
    public class Constants
    {
        public const int step = 5;
    }
    public class ClassStack
    {
        private char[] StArr;
        private int top;

        private bool IsFull()
        {
            if (top == StArr.Length)
                return true;
            else
                return false;
        }

        public ClassStack()
        {
            StArr = new char[Constants.step];
            top = 0;
        }

        public bool IsEmpty()
        {
            return top == 0;
        }

        public void Push(char x)
        {
            if (IsFull())
            {
                char[] tmp = new char[StArr.Length+Constants.step];
                StArr.CopyTo(tmp, 0);
                StArr = tmp;
            }
            StArr[top] = x;
            top++;
        }

        public char Pop()
        {
            top--;
            char x = StArr[top];
            return x;
        }
    }
}
