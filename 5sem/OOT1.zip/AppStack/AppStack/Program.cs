﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AppStack
{
    class Program
    {
        static int OpCode(char ch)
        {
            if ((ch == '+') || (ch == '-'))
                return 0;
            else
                return 1;
        }
        static bool TryTranslate(string infix, ref string postfix)
        {
            bool fl = true;
            ClassStack stack = new ClassStack();
            postfix = "";
            infix = "(" + infix + ")";
            int i = 0;
            while ((i < infix.Length) && fl)
            {
                if (infix[i] == ' ')
                    i++;
                else
                {
                    if ((infix[i] >= '0') && (infix[i] <= '9'))
                    {
                        while ((i < infix.Length) && (infix[i] >= '0') && (infix[i] <= '9'))
                        {
                            postfix = postfix + infix[i];
                            i++;
                        }
                        postfix = postfix + ' ';
                    }
                    else
                    {
                        if ((infix[i] >= 'a') && (infix[i] <= 'z'))
                        {
                            postfix = postfix + infix[i];
                            i++;
                        }
                        else
                        {
                            if (infix[i] == '(')
                            {
                                stack.Push(infix[i]);
                                i++;
                            }
                            else
                            {
                                if (infix[i] == ')')
                                {
                                    if (!stack.IsEmpty())
                                    {
                                        char ch = stack.Pop();
                                        while ((!stack.IsEmpty()) && (ch != '('))
                                        {
                                            postfix = postfix + ch;
                                            ch = stack.Pop();
                                        }
                                        if (ch != '(')
                                            fl = false;
                                    }
                                    else fl = false;
                                    i++;
                                }
                                else
                                {
                                    if ((infix[i] == '+') || (infix[i] == '-') ||
                                        (infix[i] == '*') || (infix[i] == '/'))
                                    {
                                        if (!stack.IsEmpty())
                                        {
                                            char ch = stack.Pop();
                                            while ((!stack.IsEmpty()) && (ch != '(') && (OpCode(ch) >= OpCode(infix[i])))
                                            {
                                                postfix = postfix + ch;
                                                ch = stack.Pop();
                                            }
                                           // if (ch == '(')
                                                stack.Push(ch);
                                            stack.Push(infix[i]);
                                        }
                                        else fl = false;
                                        i++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return fl;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Перевод арифметической записи из инфиксной формы в постфиксную");
            Console.WriteLine("Введите запись в инфиксной форме");
            string s = Console.ReadLine();
            string res = "";
            if (TryTranslate(s, ref res))
                Console.WriteLine(res);
            else
                Console.WriteLine("Error...");
            Console.ReadLine();
        }
    }
}
