﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_9.Observer
{
    public delegate void Del(object ob);//объявление делегата

    class Subj                             //класс источник
    {

        Del dels;                          // объявление экземпляра делегата

        public void Register(Del d)                // регистрация делегата
        {
            dels += d;
        }
        public void UnRegister(Del d)                 // удаление делегата
        {
            dels -= d;
        }

        public void OOPS()                               // что-то произошло
        {
            Console.WriteLine("ОЙ!");
            if (dels != null) dels(this);     // оповещение наблюдателей
        }
    }

    class ObsA                                          // класс-наблюдатель
    {
        public void Do(object o)           // реакция на событие источника
        {
            Console.WriteLine("Бедняжка!");
        }
    }

    class ObsB                                          // класс-наблюдатель
    {
        public static void See(object o)   // реакция на событие источника
        {
            Console.WriteLine("Да ну, ерунда!");
        }
    }

   class Test
   {
        public static void TestObserver()
        {
            Subj s = new Subj();                //  объект класса-источника

            ObsA o1 = new ObsA();                //                  объекты
            ObsA o2 = new ObsA();                //       класса-наблюдателя

            s.Register(new Del(o1.Do));      //      регистрация методов
            s.Register(new Del(o2.Do));      // наблюдателей в источнике
            s.Register(new Del(ObsB.See));   //  ( экземпляры делегата )

            s.OOPS();                            //    инициирование события
        }

    }
}
