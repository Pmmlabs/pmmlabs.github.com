﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_9.Event
{
    public delegate void Del();
    class Subj
    {
        public event Del Oops;                         // объявление события

        public void CryOops()                 // метод, инициирующий событие
        {
            Console.WriteLine( "ОЙ!" );
            if ( Oops != null ) Oops();
        }
    }

    class ObsA                                          // класс-наблюдатель
    {
        public void Do()                    // реакция на событие источника
        {
            Console.WriteLine( "Бедняжка!" );
        }
    }

    class ObsB                                          // класс-наблюдатель
    {
        public static void See()             // реакция на событие источника
        {
            Console.WriteLine( "Да ну, ерунда!" );
        }
    }

    class Class1
    {
        public static void TestEvent()
        {
            Subj s  = new Subj();              //    объект класса-источника

            ObsA o1 = new ObsA();              //                    объекты
            ObsA o2 = new ObsA();              //         класса-наблюдателя

            s.Oops += new Del( o1.Do );        //                 добавление
            s.Oops += new Del( o2.Do );        //               обработчиков
            s.Oops += new Del( ObsB.See );     //                  к событию

            s.CryOops();                       //      инициирование события 
        }
    }

    }

