﻿using System;
using System.Collections;
using System.Text;

namespace L_9
{

    class SamplesArrayList
    {
        static void Main(string[] args)
        {
          /* Example1();
            Example2();
            Example3();
            Example4();
            Example5();
            Example6();
            Example7();
            Example8();
            Example9();
            Example10();
            Example11();
            Example12();
            Example13();
            Example14();*/
            Delegate.Class1.TestDelegate1();
            Delegate.Class1.TestDelegate2();
          //  Observer.Test.TestObserver();
          //  Event.Class1.TestEvent();
          //  SysEvent.Class1.TestSysEvent();
        }

        public static void Example1()
        {
            // Создается и инициализируется объект ArrayList.
            ArrayList myAL = new ArrayList();
            myAL.Add("Россия,");
            myAL.Add("вперед");
            myAL.Add("!");

            // Свойства и значения ArrayList.
            Console.WriteLine("myAL");
            Console.WriteLine("\tCount:    {0}", myAL.Count);
            Console.WriteLine("\tCapacity: {0}", myAL.Capacity);
            Console.Write("\tValues:");
            PrintValues(myAL);
        }
        public static void PrintValues(IEnumerable myList)
        {
            // Для эффективной работы с объектом ArrayList
            // создается перечислитель...
            // Перечислитель обеспечивает перебор элементов.
            System.Collections.IEnumerator myEnumerator
                     = myList.GetEnumerator(); // Перечислитель для myList
            while (myEnumerator.MoveNext())
                Console.Write("\t{0}", myEnumerator.Current);
        }
        /// <summary>
        /// /////////////////
        /// </summary>


        public static void Example2()
        {
            // create an array list 
            ArrayList al = new ArrayList();

            Console.WriteLine("Initial capacity: " +
                               al.Capacity);
            Console.WriteLine("Initial number of elements: " +
                               al.Count);

            Console.WriteLine();

            Console.WriteLine("Adding 6 elements");
            // Add elements to the array list 
            al.Add('C');
            al.Add('A');
            al.Add('E');
            al.Add('B');
            al.Add('D');
            al.Add('F');

            Console.WriteLine("Current capacity: " +
                               al.Capacity);
            Console.WriteLine("Number of elements: " +
                               al.Count);

            // Display the array list using array indexing. 
            Console.Write("Current contents: ");
            for (int i = 0; i < al.Count; i++)
                Console.Write(al[i] + " ");
            Console.WriteLine("\n");

            Console.WriteLine("Removing 2 elements");
            // Remove elements from the array list. 
            al.Remove('F');
            al.Remove('A');

            Console.WriteLine("Current capacity: " +
                               al.Capacity);
            Console.WriteLine("Number of elements: " +
                               al.Count);

            // Use foreach loop to display the list. 
            Console.Write("Contents: ");
            foreach (char c in al)
                Console.Write(c + " ");
            Console.WriteLine("\n");

            Console.WriteLine("Adding 20 more elements");
            // Add enough elements to force al to grow. 
            for (int i = 0; i < 20; i++)
                al.Add((char)('a' + i));
            Console.WriteLine("Current capacity: " +
                               al.Capacity);
            Console.WriteLine("Number of elements after adding 20: " +
                               al.Count);
            Console.Write("Contents: ");
            foreach (char c in al)
                Console.Write(c + " ");
            Console.WriteLine("\n");

            // Change contents using array indexing. 
            Console.WriteLine("Change first three elements");
            al[0] = 'X';
            al[1] = 'Y';
            al[2] = 'Z';
            Console.Write("Contents: ");
            foreach (char c in al)
                Console.Write(c + " ");
            Console.WriteLine();
        }


        ///////////////////listing 3
        // Sort and search an ArrayList. 


        public static void Example3()
        {
            // create an array list 
            ArrayList al = new ArrayList();

            // Add elements to the array list 
            al.Add(55);
            al.Add(43);
            al.Add(-4);
            al.Add(88);
            al.Add(3);
            al.Add(19);

            Console.Write("Original contents: ");
            foreach (int i in al)
                Console.Write(i + " ");
            Console.WriteLine("\n");

            // Sort 
            al.Sort();

            // Use foreach loop to display the list. 
            Console.Write("Contents after sorting: ");
            foreach (int i in al)
                Console.Write(i + " ");
            Console.WriteLine("\n");

            Console.WriteLine("Index of 43 is " +
                              al.BinarySearch(43));
        }


        //////////////////////////listing 4
        // Convert an ArrayList into an array. 


        public static void Example4()
        {
            ArrayList al = new ArrayList();

            // Add elements to the array list. 
            al.Add(1);
            al.Add(2);
            al.Add(3);
            al.Add(4);

            Console.Write("Contents: ");
            foreach (int i in al)
                Console.Write(i + " ");
            Console.WriteLine();

            // Get the array. 
            int[] ia = (int[])al.ToArray(typeof(int));
            int sum = 0;

            // sum the array 
            for (int i = 0; i < ia.Length; i++)
                sum += ia[i];

            Console.WriteLine("Sum is: " + sum);
        }


        ////listing 5
        // Demonstrate Hashtable. 


        public static void Example5()
        {
            // Create a hash table. 
            Hashtable ht = new Hashtable();

            // Add elements to the table 
            ht.Add("house", "Dwelling");
            ht.Add("car", "Means of transport");
            ht.Add("book", "Collection of printed words");
            ht.Add("apple", "Edible fruit");

            // Can also add by using the indexer. 
            ht["tractor"] = "farm implement";

            // Get a collection of the keys. 
            ICollection c = ht.Keys;

            // Use the keys to obtain the values. 
            foreach (string str in c)
                Console.WriteLine(str + ": " + ht[str]);
        }


        ////listing 6
        // Demonstrate a SortedList. 


        public static void Example6()
        {
            // Create a sorted SortedList. 
            SortedList sl = new SortedList();

            // Add elements to the table 
            sl.Add("house", "Dwelling");
            sl.Add("car", "Means of transport");
            sl.Add("book", "Collection of printed words");
            sl.Add("apple", "Edible fruit");

            // Can also add by using the indexer. 
            sl["tractor"] = "farm implement";

            // Get a collection of the keys. 
            ICollection c = sl.Keys;

            // Use the keys to obtain the values. 
            Console.WriteLine("Contents of list via indexer.");
            foreach (string str in c)
                Console.WriteLine(str + ": " + sl[str]);

            Console.WriteLine();

            // Display list using integer indexes. 
            Console.WriteLine("Contents by integer indexes.");
            for (int i = 0; i < sl.Count; i++)
                Console.WriteLine(sl.GetByIndex(i));

            Console.WriteLine();

            // Show integer indexes of entries. 
            Console.WriteLine("Integer indexes of entries.");
            foreach (string str in c)
                Console.WriteLine(str + ": " + sl.IndexOfKey(str));
        }


        ////listing 7
        // Demonstrate the Stack class. 


        static void showPush(Stack st, int a)
        {
            st.Push(a);
            Console.WriteLine("Push(" + a + ")");

            Console.Write("stack: ");
            foreach (int i in st)
                Console.Write(i + " ");

            Console.WriteLine();
        }

        static void showPop(Stack st)
        {
            Console.Write("Pop -> ");
            int a = (int)st.Pop();
            Console.WriteLine(a);

            Console.Write("stack: ");
            foreach (int i in st)
                Console.Write(i + " ");

            Console.WriteLine();
        }

        public static void Example7()
        {
            Stack st = new Stack();

            foreach (int i in st)
                Console.Write(i + " ");

            Console.WriteLine();

            showPush(st, 22);
            showPush(st, 65);
            showPush(st, 91);
            showPop(st);
            showPop(st);
            showPop(st);

            try
            {
                showPop(st);
            }
            catch (InvalidOperationException)
            {
                Console.WriteLine("Stack empty.");
            }
        }


        ////listing 8
        // Demonstrate the Queue class. 


        static void showEnq(Queue q, int a)
        {
            q.Enqueue(a);
            Console.WriteLine("Enqueue(" + a + ")");

            Console.Write("queue: ");
            foreach (int i in q)
                Console.Write(i + " ");

            Console.WriteLine();
        }

        static void showDeq(Queue q)
        {
            Console.Write("Dequeue -> ");
            int a = (int)q.Dequeue();
            Console.WriteLine(a);

            Console.Write("queue: ");
            foreach (int i in q)
                Console.Write(i + " ");

            Console.WriteLine();
        }

        public static void Example8()
        {
            Queue q = new Queue();

            foreach (int i in q)
                Console.Write(i + " ");

            Console.WriteLine();

            showEnq(q, 22);
            showEnq(q, 65);
            showEnq(q, 91);
            showDeq(q);
            showDeq(q);
            showDeq(q);

            try
            {
                showDeq(q);
            }
            catch (InvalidOperationException)
            {
                Console.WriteLine("Queue empty.");
            }
        }


        ////listing 9
        // Demonstrate BitArray. 


        public static void showbits(string rem,
                               BitArray bits)
        {
            Console.WriteLine(rem);
            for (int i = 0; i < bits.Count; i++)
                Console.Write("{0, -6} ", bits[i]);
            Console.WriteLine("\n");
        }

        public static void Example9()
        {
            BitArray ba = new BitArray(8);
            byte[] b = { 67 };
            BitArray ba2 = new BitArray(b);

            showbits("Original contents of ba:", ba);

            ba = ba.Not();

            showbits("Contents of ba after Not:", ba);

            showbits("Contents of ba2:", ba2);

            BitArray ba3 = ba.Xor(ba2);

            showbits("Result of ba XOR ba2:", ba3);
        }


        ///listing 10
        // Demonstrate an enumerator. 


        public static void Example10()
        {
            ArrayList list = new ArrayList(1);

            for (int i = 0; i < 10; i++)
                list.Add(i);

            // Use enumerator to access list. 
            IEnumerator etr = list.GetEnumerator();
            while (etr.MoveNext())
                Console.Write(etr.Current + " ");

            Console.WriteLine();

            // Re–enumerate the list. 
            etr.Reset();
            while (etr.MoveNext())
                Console.Write(etr.Current + " ");

            Console.WriteLine();
        }


        ///listing 11
        // Demonstrate IDictionaryEnumerator. 


        public static void Example11()
        {
            // Create a hash table. 
            Hashtable ht = new Hashtable();

            // Add elements to the table 
            ht.Add("Tom", "555–3456");
            ht.Add("Mary", "555–9876");
            ht.Add("Todd", "555–3452");
            ht.Add("Ken", "555–7756");

            // Demonstrate enumerator 
            IDictionaryEnumerator etr = ht.GetEnumerator();
            Console.WriteLine("Display info using through Entry.");
            while (etr.MoveNext())
                Console.WriteLine(etr.Entry.Key + ": " +
                                  etr.Entry.Value);//свойство Entry позволяет получить
                                                   //следующую пару ключ/значение 

            Console.WriteLine();

            Console.WriteLine("Display info using Key and Value directly.");
            etr.Reset();
            while (etr.MoveNext())
                Console.WriteLine(etr.Key + ": " +
                                  etr.Value);

        }


        ////listing 12
        // A simple inventory example. 

      //  class InventoryList
      //  {
            public static void Example12()
            {
                ArrayList inv = new ArrayList();

                // Add elements to the list 
                inv.Add(new Inventory("Pliers", 5.95, 3));
                inv.Add(new Inventory("Wrenches", 8.29, 2));
                inv.Add(new Inventory("Hammers", 3.50, 4));
                inv.Add(new Inventory("Drills", 19.88, 8));

                Console.WriteLine("Inventory list:");
                foreach (Inventory i in inv)
                {
                    Console.WriteLine("   " + i);
                }
            }
       // }

        ///listing 13
        // Implement IComparable. 



       class Inventory: IComparable
        {
           public string name;
           public double cost;
           public int onhand;

            public Inventory(string n, double c, int h)
            {
                name = n;
                cost = c;
                onhand = h;
            }

            public override string ToString()
            {
                return
                  String.Format("{0,-10}Cost: {1,6:C}  On hand: {2}",
                                name, cost, onhand);
            }

            // Implement the IComparable interface. 
            public int CompareTo(object obj)
            {
                Inventory b;
                b = (Inventory)obj;
                return name.CompareTo(b.name);
            }
        }

      //  class IComparableDemo
       // {
            public static void Example13()
            {
                ArrayList inv = new ArrayList();

                // Add elements to the list 
                inv.Add(new Inventory("Pliers", 5.95, 3));
                inv.Add(new Inventory("Wrenches", 8.29, 2));
                inv.Add(new Inventory("Hammers", 3.50, 4));
                inv.Add(new Inventory("Drills", 19.88, 8));

                Console.WriteLine("Inventory list before sorting:");
                foreach (Inventory i in inv)
                {
                    Console.WriteLine("   " + i);
                }
                Console.WriteLine();

                // Sort the list. 
                inv.Sort();

                Console.WriteLine("Inventory list after sorting:");
                foreach (Inventory i in inv)
                {
                    Console.WriteLine("   " + i);
                }
            }
        //}

        ///listing 14
        // Use IComparer. 



        // Create an IComparer for Inventory objects. 
        class CompInv : IComparer
        {
          
            // Implement the IComparable interface. 
            public int Compare(object obj1, object obj2)
            {
                Inventory a, b;
                a = (Inventory)obj1;
                b = (Inventory)obj2;
                return a.name.CompareTo(b.name);
            }
        }


        public static void Example14()
        {
            CompInv comp = new CompInv();
            ArrayList inv = new ArrayList();

            // Add elements to the list 
            inv.Add(new Inventory("Pliers", 5.95, 3));
            inv.Add(new Inventory("Wrenches", 8.29, 2));
            inv.Add(new Inventory("Hammers", 3.50, 4));
            inv.Add(new Inventory("Drills", 19.88, 8));

            Console.WriteLine("Inventory list before sorting:");
            foreach (Inventory i in inv)
            {
                Console.WriteLine("   " + i);
            }
            Console.WriteLine();

            // Sort the list using an IComparer. 
            inv.Sort(comp);

            Console.WriteLine("Inventory list after sorting:");
            foreach (Inventory i in inv)
            {
                Console.WriteLine("   " + i);
            }
        }
    }
}

