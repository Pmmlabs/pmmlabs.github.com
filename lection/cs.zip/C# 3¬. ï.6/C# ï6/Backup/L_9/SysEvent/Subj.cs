﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_9.SysEvent
{
    class Subj
    {
        public event EventHandler Oops;

        public void CryOops()
        {
            Console.WriteLine( "ОЙ!" );
            if ( Oops != null ) Oops( this, null );
        }
    }

    class ObsA
    {
        public void OnOops( object sender, EventArgs e )
        {
            Console.WriteLine( "Бедняжка!" );
        }
    }

    class ObsB
    {
        public static void OnOops( object sender, EventArgs e )
        {
            Console.WriteLine( "Да ну, ерунда!" );
        }
    }

    class Class1
    {   
        public static void TestSysEvent()
        {
            Subj s  = new Subj();

            ObsA o1 = new ObsA();
            ObsA o2 = new ObsA();

            s.Oops += new EventHandler( o1.OnOops );
            s.Oops += new EventHandler( o2.OnOops );
            s.Oops += new EventHandler( ObsB.OnOops );

            s.CryOops();
        }
    }

    }

