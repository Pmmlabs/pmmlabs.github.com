﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_9.Delegate
{
    delegate void Del(ref string s);//объявление делегата
    class Class1
    {
        
        public static void C00l ( ref string s )                  // метод 1
        {
            string temp = "";
            for ( int i = 0; i < s.Length; ++i )
            {
                if      ( s[i] == 'o' || s[i] == 'O') temp += '0';
                else if ( s[i] == 'l' )               temp += '1';
                else                                  temp += s[i];
            }
            s = temp;
        }

        public static void Hack ( ref string s )                  // метод 2
        {
            string temp = "";
            for ( int i = 0; i < s.Length; ++i )
                if ( i / 2 * 2 == i ) temp += char.ToUpper( s[i] );
                else                  temp += s[i];

            s = temp; 
        }

        public static void TestDelegate1()
        {
            string s = "cool hackers";
            Del d;                                     // экземпляр делегата

            for ( int i = 0; i < 2; ++i )
            {
                d = new Del( C00l );              // инициализация методом 1
                if ( i == 1 ) d = new Del(Hack);  // инициализация методом 2

                d( ref s );     // использование делегата для вызова методов
                Console.WriteLine( s );
            }
        }
        public static void TestDelegate2()
        {
            string s = "cool hackers";
            Del d = new Del(C00l);
            d += new Del(Hack);             // добавление метода в делегат

            d(ref s);
            Console.WriteLine(s);           // результат: C001 hAcKeRs
        }

    }


    }

