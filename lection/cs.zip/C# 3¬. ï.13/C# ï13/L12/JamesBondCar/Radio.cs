﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L12.JamesBondCar
{
  [Serializable]  
  public class Radio
  {
      [NonSerialized]
      private int ObjectIdNumber=9;
      public Radio(){}
      public void On(bool state)
    {
      if(state)
        Console.WriteLine("Music is on...");
      else
        Console.WriteLine("No tunes...");
    }
  }

    
 [Serializable]  
  public class Car
  {
    
    protected int maxSpeed;
    protected string petName;
    protected Radio theRadio = new Radio();

    public Car(string name, int maxSp)
    {
      maxSpeed = maxSp;
      petName = name;
    }
    public Car(){} 

   public string PetName
   {
       get{return petName;}
       set{petName=value;}
   }
     public int MaxSpeed
   {
       get{return maxSpeed;}
       set{maxSpeed=value;}
   }
     public void TurnOnRadio(bool state)
     {
         theRadio.On(state);
     }
   
  }
    [Serializable]
    public class JamesBondCar : Car
    {
        protected bool isFlightWorthy;
        protected bool isSeaWorthy;
        public JamesBondCar() { }
        public JamesBondCar(string petName, int maxSped,bool canFly,bool canSubmerge):base(petName, maxSped) 
        {
            this.isFlightWorthy = canFly;
            this.isSeaWorthy = canSubmerge;
        }
        public void Fly()
        {
            if(isFlightWorthy)
                Console.WriteLine("Taking off");
            else
                Console.WriteLine("Falling off cliff!");
        }
        public void GoUnderWater()
        {
            if (isSeaWorthy)
                Console.WriteLine("Diving");
            else
                Console.WriteLine("Drowning!");
        }
    }
}


