﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;

namespace L12
{
    [Serializable]
    public class Personage
    {
        public Personage(string name, int age)
        {
            this.name = name; this.age = age;
        }
        //поля класса
        static int wishes;//желание
        public string name, status, wealth;//богатство
        int age;
        public Personage couple;//пара

        //методы класса
        public void marry(Personage couple)//супруг
        {
            this.couple = couple;
            couple.couple = this;
            this.status = "крестьянин";
            this.wealth = "рыбацкая сеть";
            this.couple.status = "крестьянка";
            this.couple.wealth = "корыто";
            SaveState();
           // SaveStateXML();
        }

        void SaveState()
        {
            BinaryFormatter bf = new BinaryFormatter();
            FileStream fs = new FileStream
               ("State.bin", FileMode.Create, FileAccess.Write);
            bf.Serialize(fs, this);
            fs.Close();
        }

        void SaveStateXML()
        {
            SoapFormatter sf = new SoapFormatter();
            FileStream fs = new FileStream
               ("State.xml", FileMode.Create, FileAccess.Write);
            sf.Serialize(fs, this);
            fs.Close();
        }

       //метод, описывающий жизнь героя сказки 
        public Personage AskGoldFish()
        {
            Personage fisher = this;
            if (fisher.name == "рыбак")
            {
                wishes++;
                switch (wishes)
                {
                    case 1: ChangeStateOne(); break;
                    case 2: ChangeStateTwo(); break;
                    case 3: ChangeStateThree(); break;
                    default: BackState(ref fisher); break;
                   // default: BackStateXML(ref fisher); break;
                }
            }
            return (fisher);
        }//AskGoldFish

        void ChangeStateOne()
        {
            this.status = "муж дворянки";
            this.couple.status = "дворянка";
            this.couple.wealth = "имение";
        }
        void ChangeStateTwo()
        {
            this.status = "муж боярыни";
            this.couple.status = "боярыня";
            this.couple.wealth = "много поместий";
        }
        void ChangeStateThree()
        {
            this.status = "муж государыни";
            this.couple.status = "государыня";
            this.couple.wealth = "страна";
        }

        void BackState(ref Personage fisher)
        {
            BinaryFormatter bf = new BinaryFormatter();
            FileStream fs = new FileStream
               ("State.bin", FileMode.Open, FileAccess.Read);
            fisher = (Personage)bf.Deserialize(fs);
            fs.Close();
        }

        void BackStateXML(ref Personage fisher)
        {
            SoapFormatter sf = new SoapFormatter();
            FileStream fs = new FileStream
         ("State.xml", FileMode.Open, FileAccess.Read);
            fisher = (Personage)sf.Deserialize(fs);
            fs.Close();
        }

        public void About()
        {
            Console.WriteLine("имя = {0}, возраст = {1}," +
            "статус = {2}, состояние ={3}", name, age, status, wealth);
            Console.WriteLine("имя = {0}, возраст = {1}," +
            "статус = {2}, состояние ={3}", this.couple.name,
            this.couple.age, this.couple.status, this.couple.wealth);
        }






    }

}
