﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L12
{
    class Program
    {
        static void Main(string[] args)
        {
            //TestGoldFish();
            TestJamesBondCar();
        }
        public static void TestGoldFish()
        {
            Personage fisher = new Personage("рыбак", 70);
            Personage wife = new Personage("старуха", 70);
            fisher.marry(wife);
            Console.WriteLine("До золотой рыбки"); fisher.About();
            fisher = fisher.AskGoldFish();
            Console.WriteLine("Первое желание"); fisher.About();
            fisher = fisher.AskGoldFish();
            Console.WriteLine("Второе желание"); fisher.About();
            fisher = fisher.AskGoldFish();
            Console.WriteLine("Третье желание"); fisher.About();
            fisher = fisher.AskGoldFish();
            Console.WriteLine("Еще хочу"); fisher.About();
            fisher = fisher.AskGoldFish();
            Console.WriteLine("Хочу, но уже поздно"); fisher.About();
        }
        public static void TestJamesBondCar()
        {
            JamesBondCar.JamesBondCar myAuto = new L12.JamesBondCar.JamesBondCar("Fred",50,false,true);
            myAuto.TurnOnRadio(true);
            myAuto.GoUnderWater();
        }

    }
}
