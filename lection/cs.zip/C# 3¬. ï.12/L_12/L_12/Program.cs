﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace L_12
{
   
        class NullableExample
        {
            static void Main()
            {
                // Вопросительный знак в объявлении - признак nullab'ости переменной.
                int? num = null;
                // Здесь мы обращаемся к свойству, которое проверяет наличие "непустого"
                // значения у переменной num.
                if (num.HasValue == true)
                {
                    System.Console.WriteLine("num = " + num.Value);
                }
                else
                {
                    System.Console.WriteLine("num = Null");
                }

                // Простой двойник (типа int) - переменная y устанавливается в 0.
                // И это безопасный способ инициализации "простого" двойника. 

                int y = num.GetValueOrDefault();

                // Можно, конечно, попытаться присвоить значение "напрямую",
                // однако при этом сохраняется опасность того, что nullable в
                // данный момент (num.Value - свойство, позволяющее получить 
                // значение num) проинициализировано пустым значением. Тип int этого 
                // не вынесет - будет возбуждено исключение. Поэтому присвоение 
                // значения и сопровождается такими предосторожностями. 
                try
                {
                    y = num.Value;
                }
                catch (System.InvalidOperationException e)
                {
                    System.Console.WriteLine(e.Message);
                }
            }
        }

    }

