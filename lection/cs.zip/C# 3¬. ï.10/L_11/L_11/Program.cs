﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
namespace L_11
{
    /* class Class1
     {
         static void Main(string[] args)
         {//примеры форматирования
             Console.WriteLine("Integer fotmating – {0:D3},{1:D5}", 12345, 12);
             Console.WriteLine("Currency formatting – {0:C},{1:C5}", 99.9, 999.9);
             Console.WriteLine("Exponential formatting – {0:E}", 1234.5);
             Console.WriteLine("Fixed Point formatting – {0:F3}", 1234.56789);
             Console.WriteLine("General formatting – {0:G}", 1234.56789);
             Console.WriteLine("Number formatting – {0:N}", 1234567.89);
             Console.WriteLine("Hexadecimal formatting – {0:X7}", 12345);//Integers only!
         }
     }
 }*/
    class Class1
    {
        static string[] str = {
 "1234567890",
 "qwertyuiop",
 "asdfghjkl",
 "zxcvbnm", };

        static void Main(string[] args)
        {
            int i;
            // Полное имя файла.
            string filename = @"D:\дубликат\дубликат\Презентации\Лекции C#\Демонстрационные материалы\C# Л.11\L_11\test.txt";
            string xLine = "";
            char[] buff = new char[128];
            for (i = 0; i < 128; i++) buff[i] = (char)25;
            // Запись в файл.
            FileStream fstr = new FileStream(filename,
            FileMode.Create,
            FileAccess.Write);
            BufferedStream buffStream = new BufferedStream(fstr);
            StreamWriter streamWr = new StreamWriter(buffStream); 
            for (i = 0; i < str.Length; i++)
            {
                streamWr.WriteLine(str[i]);
            }

            streamWr.Flush();
            streamWr.Close();

            Console.WriteLine("–––––––––––––––––––––––––––––––––––––––––––");

            fstr = new FileStream(filename,
             FileMode.Open,
             FileAccess.Read);

            StreamReader streamRd = new StreamReader(fstr);
            for (; xLine != null; )
            {
                xLine = streamRd.ReadLine();
                Console.WriteLine(xLine);
            }

            Console.WriteLine("––––––––––––––––––––––––––––––––––––––––––––");
            fstr.Seek(0, SeekOrigin.Begin);
            streamRd.Read(buff, 0, 10);
            Console.WriteLine(new string(buff));
            Console.WriteLine("1––––––––––––––––––––––––––––––––––––––––––");

            streamRd.Read(buff, 0, 20);
            Console.WriteLine(new string(buff));
            Console.WriteLine("2––––––––––––––––––––––––––––––––––––––––––");
            Console.WriteLine(streamRd.Read(buff, 0, 15));
            i = (int)fstr.Seek(-20, SeekOrigin.Current);
            Console.WriteLine(streamRd.ReadLine());

            Console.WriteLine("3––––––––––––––––––––––––––––––––––––––––––");
            Console.WriteLine("***{0,20}***", 3.14);
            Console.WriteLine("***{0,-20}***", 3.14);
        }
    }
} 
/*Пример перенаправления потоков.
 * В файл можно записать информацию, используя привычные классы и методы
 * class Program
  {

      static void Main(string[] args)
{
string buff;

FileStream outFstr, inFstr; // Ссылки на файловые потоки.

// Ссылка на выходной поток. Свойства и методы,
// которые обеспечивают запись в...
StreamWriter swr;

// Ссылка на входной поток. Свойства и методы,
// которые обеспечивают чтение из...
StreamReader sr;  

// Класс Console –  средство управления ПРЕДОПРЕДЕЛЕННЫМ потоком. 
// Сохранили стандартный выходной поток,
// связанный с окошком консольного приложения. 
TextWriter twrConsole = Console.Out;

// Сохранили стандартный входной поток, связанный с буфером клавиатуры.
TextReader trConsole = Console.In;

inFstr = new FileStream
         (@"D:\дубликат\дубликат\Презентации\Лекции C#\Демонстрационные материалы\C# Л.11\L_11\test.txt", FileMode.Open, FileAccess.Read);
sr = new StreamReader(inFstr); // Входной поток, связанный с файлом. 

outFstr = new FileStream
         (@"D:\дубликат\дубликат\Презентации\Лекции C#\Демонстрационные материалы\C# Л.11\L_11\txt.txt", FileMode.Create, FileAccess.Write);
swr = new StreamWriter(outFstr); // Выходной поток, связанный с файлом.
// А вот мы перенастроили предопределенный входной поток.
// Он теперь связан не с буфером клавиатуры, а с файлом, открытым для чтения.
Console.SetIn(sr);
Console.SetOut(swr);
     
while (true)
{
// Но поинтересоваться в предопределенном потоке отностительно
// конца файла невозможно.
// Такого для предопределенных потоков просто не предусмотрено. 
if (sr.EndOfStream) break;

// А вот читать - можно.
buff = Console.ReadLine();
Console.WriteLine(buff);           
    
}
Console.SetOut(twrConsole);
Console.WriteLine("12345");            
Console.SetOut(swr);
Console.WriteLine("12345");
Console.SetOut(twrConsole);
Console.WriteLine("67890");
Console.SetOut(swr);
Console.WriteLine("67890");

sr.Close();
inFstr.Close();
swr.Close();
outFstr.Close();
}
  }
}*/

 


