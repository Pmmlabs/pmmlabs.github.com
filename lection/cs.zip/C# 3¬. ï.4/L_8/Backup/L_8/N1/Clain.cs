﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_8
{
    public class Clain : IProps
    {
        public Clain() { }
        public void Prop1(string s)
        {
            Console.WriteLine(s);
        }
        public void Prop2(string name, int val)
        {
            Console.WriteLine("name = {0}, val ={1}", name, val);
        }
    }//Clain

}
