﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_8.N1
{
    public class ClainP : IProps
    {
        public ClainP() { }
        void IProps.Prop1(string s)
        {
            Console.WriteLine(s);
        }
        void IProps.Prop2(string name, int val)
        {
            Console.WriteLine("name = {0}, val ={1}", name, val);
        }

        //обертывание и кастинг
        public void MyProp1(string s)
        {
            ((IProps)this).Prop1(s);
        }
        public void MyProp2(string s, int x)
        {
            ((IProps)this).Prop2(s, x);
        }

    }//class ClainP

}
