﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_8.N2
{
    public interface IPropsOne
    {
        void Prop1(string s);
        void Prop2(int val);
        void Prop3();
    }

}
