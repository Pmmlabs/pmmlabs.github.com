﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_8.N2
{
    public class ClainTwo : IProps, IPropsOne
    {
        /// <summary>
        /// склеивание методов двух интерфейсов
        /// </summary>
        /// <param name="s"></param>
        public void Prop1(string s)
        {
            Console.WriteLine(s);
        }
        /// <summary>
        /// перегрузка методов двух интерфейсов
        /// </summary>
        /// <param name="s"></param>
        /// <param name="x"></param>
        public void Prop2(string s, int x)
        {
            Console.WriteLine(s + "; " + x);
        }
        public void Prop2(int x)
        {
            Console.WriteLine(x);
        }
        /// <summary>
        /// переименование методов двух интерфейсов
        /// </summary>
        void IProps.Prop3()
        {
            Console.WriteLine("Свойство 3 интерфейса 1");
        }
        void IPropsOne.Prop3()
        {
            Console.WriteLine("Свойство 3 интерфейса 2");
        }
        public void Prop3FromInterface1()
        {
            ((IProps)this).Prop3();
        }
        public void Prop3FromInterface2()
        {
            ((IPropsOne)this).Prop3();
        }
    }

}
