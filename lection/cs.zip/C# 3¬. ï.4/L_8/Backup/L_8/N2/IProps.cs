﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_8.N2
{
    public interface IProps
    {
        void Prop1(string s);
        void Prop2(string name, int val);
        void Prop3();
    }

}
