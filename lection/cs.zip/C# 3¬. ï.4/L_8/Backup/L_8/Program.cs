﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_8
{
    public class Test
    {
        public void TestClainIProps()
        {
            Console.WriteLine("Объект класса Clain вызывает открытые методы!");
            Clain clain = new Clain();
            clain.Prop1(" свойство 1 объекта");
            clain.Prop2("Владимир", 44);
            Console.WriteLine("Объект класса IProps вызывает открытые методы!");
            IProps ip = (IProps)clain;
            ip.Prop1("интерфейс: свойство");
            ip.Prop2("интерфейс: свойство", 77);
            Console.WriteLine("Объект класса ClainP вызывает открытые методы!");
            N1.ClainP clainp = new N1.ClainP();
            clainp.MyProp1(" свойство 1 объекта");
            clainp.MyProp2("Владимир", 44);
            Console.WriteLine("Объект класса IProps вызывает  закрытые методы!");
            IProps ipp = (IProps)clainp;
            ipp.Prop1("интерфейс: свойство");
            ipp.Prop2("интерфейс: свойство", 77);
        }

        public void TestCliTwoInterfaces()
        {
            Console.WriteLine("Объект ClainTwo вызывает методы двух интерфейсов!");
            N2.ClainTwo claintwo = new N2.ClainTwo();
            claintwo.Prop1("Склейка свойства двух интерфейсов");
            claintwo.Prop2("перегрузка ::: ", 99);
            claintwo.Prop2(9999);
            claintwo.Prop3FromInterface1();
            claintwo.Prop3FromInterface2();
            Console.WriteLine("Интерфейсный объект вызывает методы 1-го  интерфейса!");
            N2.IProps ip1 = (N2.IProps)claintwo;
            ip1.Prop1("интерфейс IProps: свойство 1");
            ip1.Prop2("интерфейс 1 ", 88);
            ip1.Prop3();
            Console.WriteLine("Интерфейсный объект вызывает методы 2-го интерфейса!");
            N2.IPropsOne ip2 = (N2.IPropsOne)claintwo;
            ip2.Prop1("интерфейс IPropsOne: свойство1");
            ip2.Prop2(7777);
            ip2.Prop3();
        }
        public void TestIParsons()
        {
            Console.WriteLine("Объект класса вызывает методы трех интерфейсов!");
            N3.Pars ct = new N3.Pars();
            ct.ParentMethod();
            ct.Son1Method();
            ct.Son2Method();
            Console.WriteLine("Интерфейсный объект 1 вызывает свои методы!");
            N3.IParent ip = (N3.IParent)ct;
            ip.ParentMethod();
            Console.WriteLine("Интерфейсный объект 2 вызывает свои методы!");
            N3.ISon1 ip1 = (N3.ISon1)ct;
            ip1.ParentMethod();
            ip1.Son1Method();
            Console.WriteLine("Интерфейсный объект 3 вызывает свои методы!");
            N3.ISon2 ip2 = (N3.ISon2)ct;
            ip2.ParentMethod();
            ip2.Son2Method();
        }
     
        class Program
        {
            static void Main(string[] args)
            {
                Test t = new Test();
                 t.TestClainIProps();
                // t.TestCliTwoInterfaces();
                //t.TestIParsons();
                
            }
        }
    }
}