﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_8.N3
{
    public interface IParent
    {
        void ParentMethod();
    }
    
    


}
