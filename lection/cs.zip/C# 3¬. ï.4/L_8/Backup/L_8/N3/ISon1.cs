﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_8.N3
{
    public interface ISon1 : IParent
    {
        void Son1Method();
    }
}
