﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_8.N3
{
    public class Pars : ISon1, ISon2
    {
        public void ParentMethod()
        {
            Console.WriteLine("Это метод родителя!");
        }
        public void Son1Method()
        {
            Console.WriteLine("Это метод старшего сына!");
        }
        public void Son2Method()
        {
            Console.WriteLine("Это метод младшего сына!");
        }
    }//class Pars

}
