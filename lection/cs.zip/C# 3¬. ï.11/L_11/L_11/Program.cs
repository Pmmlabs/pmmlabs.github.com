﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
namespace L_11
{

    class Class1
    {
        static public void Test1Swap()
        {
        }

        static void Main(string[] args)
        {
           // FileBinary.RWData.TestBinFile();
           // FileBinary.Inventory.TestInvertory();
          // FileBinary.RandomAccessDemo.TestRandomAccsess();
          // FileBinary.MemStrDemo.TestMemoStory();
           // FileBinary.StrRdrDemo.TestStringRW();
           // FileBinary.RandomAccessDemo.TestRandomAccsess();
            FileBinary.AvgNums.TestAvgNums();
        }
    }
}


 


