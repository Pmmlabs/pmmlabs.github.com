﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
namespace L_11.FileBinary
{
    // Запись в файл двоичных данных с последующим их считыванием 

    class RWData
    {
        public static void TestBinFile()
        {
            BinaryWriter dataOut;
            BinaryReader dataIn;

            int i = 10;
            double d = 1023.56;
            bool b = true;

            try
            {
                dataOut = new
                  BinaryWriter(new FileStream("testdata", FileMode.Create));
            }
            catch (IOException exc)
            {
                Console.WriteLine(exc.Message + "\nCannot open file.");
                return;
            }

            try
            {
                Console.WriteLine("Writing " + i);
                dataOut.Write(i);

                Console.WriteLine("Writing " + d);
                dataOut.Write(d);

                Console.WriteLine("Writing " + b);
                dataOut.Write(b);

                Console.WriteLine("Writing " + 12.2 * 7.4);
                dataOut.Write(12.2 * 7.4);

            }
            catch (IOException exc)
            {
                Console.WriteLine(exc.Message + "\nWrite error.");
            }

            dataOut.Close();

            Console.WriteLine();

            // Теперь попробуем прочитать эти данные 
            try
            {
                dataIn = new
                    BinaryReader(new FileStream("testdata", FileMode.Open));
            }
            catch (FileNotFoundException exc)
            {
                Console.WriteLine(exc.Message + "\nCannot open file.");
                return;
            }

            try
            {
                i = dataIn.ReadInt32();
                Console.WriteLine("Reading " + i);

                d = dataIn.ReadDouble();
                Console.WriteLine("Reading " + d);

                b = dataIn.ReadBoolean();
                Console.WriteLine("Reading " + b);

                d = dataIn.ReadDouble();
                Console.WriteLine("Reading " + d);
            }
            catch (IOException exc)
            {
                Console.WriteLine(exc.Message + "Read error.");
            }

            dataIn.Close();
        }
    }


    // Использование классов BinaryReader и BinaryWriter для реализации простой программы инвентаризации
  

    class Inventory
    {
        public static void TestInvertory()
        {
            BinaryWriter dataOut;
            BinaryReader dataIn;

            string item; // наименование элемента
            int onhand;  // количество, имеющееся в наличии 
            double cost; // цена 

            try
            {
                dataOut = new
                  BinaryWriter(new FileStream("inventory.dat",
                                              FileMode.Create));
            }
            catch (IOException exc)
            {
                Console.WriteLine(exc.Message + "\nCannot open file.");
                return;
            }

            // Записываем в файл демонстрационные данные 
            try
            {
                dataOut.Write("Молоток");
                dataOut.Write(10);
                dataOut.Write(3.95);

                dataOut.Write("Отвертка");
                dataOut.Write(18);
                dataOut.Write(1.50);

                dataOut.Write("Плоскогубцы");
                dataOut.Write(5);
                dataOut.Write(4.95);

                dataOut.Write("Пила");
                dataOut.Write(8);
                dataOut.Write(8.95);
            }
            catch (IOException exc)
            {
                Console.WriteLine(exc.Message + "\nWrite error.");
            }

            dataOut.Close();

            Console.WriteLine();

            // Теперь откроем файл инвентаризации для чтения информации
            try
            {
                dataIn = new
                    BinaryReader(new FileStream("inventory.dat",
                                 FileMode.Open));
            }
            catch (FileNotFoundException exc)
            {
                Console.WriteLine(exc.Message + "\nCannot open file.");
                return;
            }

            // Поиск элемента, введенного пользователем 
            Console.Write("Введите наименование для поиска: ");
            string what = Console.ReadLine();
            Console.WriteLine();

            try
            {
                for (; ; )
                {
                    // Считываем из базы данных
                    item = dataIn.ReadString();
                    onhand = dataIn.ReadInt32();
                    cost = dataIn.ReadDouble();

                    /* Если элемент в базе данных совпадает с элементом из запроса, отображаем найденную информацию*/
                    if (item.CompareTo(what) == 0)
                    {
                        Console.WriteLine(onhand + " " + item + " штук в наличии " +
                                          "Цена: {0:C} за каждую единицу", cost);
                        Console.WriteLine("Общая стоимость по наименованию {0}: {1:C}.",
                                          item, cost * onhand);
                        break;
                    }
                }
            }
            catch (EndOfStreamException)
            {
                Console.WriteLine("Элемент не найден");
            }
            catch (IOException exc)
            {
                Console.WriteLine(exc.Message + "Ошибка при чтении");
            }

            dataIn.Close();
        }
    }


    // Демонстрация использования класса MemoryStream

    class MemStrDemo
    {
        public static void TestMemoStory()
        {
            byte[] storage = new byte[255];

            // Создаем поток с ориентацией на память 
            MemoryStream memstrm = new MemoryStream(storage);

            // Помещаем объект memstrm в оболочки  Streamreader и Streamwriter. 
            StreamWriter memwtr = new StreamWriter(memstrm);
            StreamReader memrdr = new StreamReader(memstrm);

            // Записываем данные в память с помощью объекта memwtr. 
            for (int i = 0; i < 10; i++)
                memwtr.WriteLine("byte [" + i + "]: " + i);

            // Ставим в конце точку
            memwtr.Write('.');

            memwtr.Flush();

            Console.WriteLine("Считываем данные прямо из массива storage : ");

            // Отображаем напрямую содержимое памяти 
            foreach (char ch in storage)
            {
                if (ch == '.') break;
                Console.Write(ch);
            }

            Console.WriteLine("\nСчитываем данные посредством объекта memrdr: ");

            // Считываем данные из объекта memstrm используя средство чтения потоков 
            memstrm.Seek(0, SeekOrigin.Begin); // установка указателя позиции в начало потока  

            string str = memrdr.ReadLine();
            while (str != null)
            {
                str = memrdr.ReadLine();
                if (str.CompareTo(".") == 0) break;
                Console.WriteLine(str);
            }

        }
    }



    // Демонстрация использования классов StringReader и StringWriter 

    class StrRdrDemo
    {
        public static void TestStringRW()
        {
            // Создаем объект класса StringWriter 
            StringWriter strwtr = new StringWriter();

            // Записываем данные в  StringWriter-объект. 
            for (int i = 0; i < 10; i++)
                strwtr.WriteLine("Значение i равно: " + i);

            // Создаем объект класса StringReader 

            StringReader strrdr = new StringReader(strwtr.ToString());

            // Теперь считываем данные из StringReader-объекта. 
            string str = strrdr.ReadLine();
            while (str != null)
            {
                str = strrdr.ReadLine();
                Console.WriteLine(str);
            }

        }
    }


    // Демонстрация произвольного доступа к файлу 

    class RandomAccessDemo
    {
        public static void TestRandomAccsess()
        {
            FileStream f;
            char ch;

            try
            {
                f = new FileStream("random.dat", FileMode.Create);
            }
            catch (IOException exc)
            {
                Console.WriteLine(exc.Message);
                return;
            }

            // Записываем в файл алфавит      
            for (int i = 0; i < 26; i++)
            {
                try
                {
                    f.WriteByte((byte)('A' + i));
                }
                catch (IOException exc)
                {
                    Console.WriteLine(exc.Message);
                    return;
                }
            }

            try
            {
                // Теперь считываем отдельные значения
                f.Seek(0, SeekOrigin.Begin); // поиск первого байта 
                ch = (char)f.ReadByte();
                Console.WriteLine("Первое значение равно " + ch);

                f.Seek(1, SeekOrigin.Begin); // Поиск второго байта 
                ch = (char)f.ReadByte();
                Console.WriteLine("Второе значение равно " + ch);

                f.Seek(4, SeekOrigin.Begin); // Поиск пятого байта 
                ch = (char)f.ReadByte();
                Console.WriteLine("Пятое значение равно " + ch);

                Console.WriteLine();

                // Теперь считываем значения через одно
                Console.WriteLine("Выборка значений через одно: ");
                for (int i = 0; i < 26; i += 2)
                {
                    f.Seek(i, SeekOrigin.Begin); // переход к i-байту 
                    ch = (char)f.ReadByte();
                    Console.Write(ch + " ");
                }
            }
            catch (IOException exc)
            {
                Console.WriteLine(exc.Message);
            }

            Console.WriteLine();
            f.Close();
        }
    }


    // Программа усредняет список чисел, введенных пользователем 

    class AvgNums
    {
        public static void TestAvgNums()
        {
            string str;
            int n;
            double sum = 0.0;
            double avg, t;

            Console.Write("Сколько чисел вы собираетесь ввести: ");
            str = Console.ReadLine();
            try
            {
                n = Int32.Parse(str);
            }
            catch (FormatException exc)
            {
                Console.WriteLine(exc.Message);
                n = 0;
            }
            catch (OverflowException exc)
            {
                Console.WriteLine(exc.Message);
                n = 0;
            }

            Console.WriteLine("Введите " + n + " чисел");
            for (int i = 0; i < n; i++)
            {
                Console.Write(": ");
                str = Console.ReadLine();
                try
                {
                    t = Double.Parse(str);
                }
                catch (FormatException exc)
                {
                    Console.WriteLine(exc.Message);
                    t = 0.0;
                }
                catch (OverflowException exc)
                {
                    Console.WriteLine(exc.Message);
                    t = 0;
                }
                sum += t;
            }
            avg = sum / n;
            Console.WriteLine("Среднее равно " + avg);
        }
    }
}
