﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_10.Delegate
{ 
    public delegate T FunTwoArg<T>(T a, T b);
    class Delegate<T>
    {
        public delegate T Del(T a, T b);
       
        public T FunAr(T[] arr, T a0, Del f)
        {
            T temp = a0;
            for (int i = 0; i < arr.Length; i++)
            {
                temp = f(temp, arr[i]);
            }
            return (temp);
        }

    }
    public class Testing
    {
    public int max2(int a, int b)
      { return (a > b) ? a : b; }

    public double min2(double a, double b)
      { return (a < b) ? a : b; }

    public string sum2(string a, string b)
      { return a + b; }

    public float prod2(float a, float b)
      { return a * b; }

     public void TestFun()
        {
            int[] ar1 = { 3, 5, 7, 9 };
            double[] ar2 = { 3.5, 5.7, 7.9 };
            string[] ar3 = { "Мама ", "мыла ", "Машу ", "мылом." };
            float[] ar4 = { 5f, 7f, 9f, 11f };
            Delegate<int> d1 = new Delegate<int>();
            Delegate<int>.Del del1;
            del1 = this.max2;
            int max = d1.FunAr(ar1, ar1[0], del1);
            Console.WriteLine("max= {0}", max);
            Delegate<double> d2 = new Delegate<double>();
            Delegate<double>.Del del2;
            del2 = this.min2;
            double min = d2.FunAr(ar2, ar2[0], del2);
            Console.WriteLine("min= {0}", min);
            Delegate<string> d3 = new Delegate<string>();
            Delegate<string>.Del del3;
            del3 = this.sum2;
            string sum = d3.FunAr(ar3, "", del3);
            Console.WriteLine("concat= {0}", sum);
            Delegate<float> d4 = new Delegate<float>();
            Delegate<float>.Del del4;
            del4 = this.prod2;
            float prod = d4.FunAr(ar4, 1f, del4);
            Console.WriteLine("prod= {0}", prod);
           
            FunTwoArg <int> mydel;
            mydel = max2;
            max = mydel(17, 21);
            Console.WriteLine("max= {0}", max);

        }

    }
   

}
