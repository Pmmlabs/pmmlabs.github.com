﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_10.List
{
    public class Node<K, T> where K : IComparable<K>
    {
        public Node()
        {
            next = null; 
            key = default(K);
            item = default(T);
        }
        public K key;
        public T item;
        public Node<K, T> next;
    }

    public class OneLinkList<K, T> where K : IComparable<K>
    {
       protected Node<K, T> first, cursor;
    
        public void start()
          { 
            cursor = first; 
          }
        public void finish()
         {
           while (cursor.next != null)
             cursor = cursor.next;
        }
        public void forth()
        { 
            if (cursor.next != null)
                cursor = cursor.next;
        }
        public void add(K key, T item)
        {
            Node<K, T> newnode = new Node<K, T>();
            if (first == null)
            {
                first = newnode; cursor = newnode;
                newnode.key = key; newnode.item = item;
            }
            else
            {
                newnode.next = cursor.next; cursor.next = newnode;
                newnode.key = key; newnode.item = item;
            }
        }
        public bool findstart(K key)
        {
            Node<K, T> temp = first;
            while (temp != null)
            {
                if (temp.key.CompareTo(key) == 0)
                {
                    cursor = temp;
                    return (true);
                }
                temp = temp.next;
            }
            return (false);
        }
        public K Key()
        {
            return (cursor.key);
        }
        public T Item()
        {
            return (cursor.item);
        }



}
}