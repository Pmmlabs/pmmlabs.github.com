﻿using System;
using System.Collections.Generic;
using System.Text;
using IntStack =L_10.Stack.OneLinkStack<int>;
namespace L_10
{
    class Program
    {
        static void Main(string[] args)
        {
           //Test1Swap();
           //TestStacks();
           // TestPerson();
           // TestConstraint();
           // TestSum();
           // TestIntStack();
           // Delegate.Testing tst = new L_10.Delegate.Testing();
           // tst.TestFun();
        }
        static public void Test1Swap()
        {
            int x1 = 5, x2 = 7;
            Console.WriteLine("до обмена: x1={0}, x2={1}", x1, x2);
            Example1.Change.Swap<int>(ref x1, ref x2);
            Console.WriteLine("после обмена: x1={0}, x2={1}", x1, x2);
            string s1 = "Савл", s2 = "Павел";
            Console.WriteLine("до обмена: s1={0}, s2={1}", s1, s2);
            Example1.Change.Swap<string>(ref s1, ref s2);
            Console.WriteLine("после обмена: s1={0}, s2={1}", s1, s2);
            Person pers1 = new Person("Савлов", 25, 1500);
            Person pers2 = new Person("Павлов", 35, 2100);
            Console.WriteLine("до обмена: ");
            Console.WriteLine(pers1.ToString());
            Console.WriteLine(pers2.ToString());
            Example1.Change.Swap<Person>(ref pers1, ref pers2);
            Console.WriteLine("после обмена:");
            Console.WriteLine(pers1.ToString());
            Console.WriteLine(pers2.ToString());
        }
        static public void TestStacks()
        {
            Stack.OneLinkStack<int> stack1 = new Stack.OneLinkStack<int>();
            Stack.OneLinkStack<string> stack2 = new Stack.OneLinkStack<string>();
            Stack.ArrayUpStack<double> stack3 = new Stack.ArrayUpStack<double>(10);    
            stack1.put(11); 
            stack1.put(22);
            int x1 = stack1.item(), x2 = stack1.item();
            if ((x1 == x2) && (x1 == 22)) Console.WriteLine("OK!");
            stack1.remove();
            x2 = stack1.item();
            if ((x1 != x2) && (x2 == 11)) Console.WriteLine("OK!");
            stack1.remove();
            x2 = (stack1.empty()) ? 77 : stack1.item();
            if ((x1 != x2) && (x2 == 77)) Console.WriteLine("OK!");
            stack2.put("first"); stack2.put("second");
            stack2.remove(); string s = stack2.item();
            if (!stack2.empty()) Console.WriteLine(s);
            stack3.put(3.33);
            stack3.put(Math.Sqrt(Math.PI));
            double res = stack3.item();
            stack3.remove();
            res += stack3.item();
            Console.WriteLine("res= {0}", res);
        }
        static public void TestPerson()
        {
            Stack.OneLinkStack<int> stack1 = new Stack.OneLinkStack<int>();
            Stack.OneLinkStack<string> stack2 = new Stack.OneLinkStack<string>();
            Stack.ArrayUpStack<double> stack3 = new Stack.ArrayUpStack<double>(10);
              
            Stack.ArrayUpStack<Person> stack4 = new Stack.ArrayUpStack<Person>(7);
            stack2.put("Петров"); stack2.put("Васильев");
            stack2.put("Шустов");
            stack1.put(27); stack1.put(45); stack1.put(53);
            stack3.put(21550.5); stack3.put(12345.7);
            stack3.put(32458.8);
            stack4.put(new Person(stack2.item(), stack1.item(), stack3.item()));
              
            stack1.remove(); stack2.remove(); stack3.remove();
            stack4.put(new Person(stack2.item(), stack1.item(),stack3.item()));
               
            stack1.remove(); stack2.remove(); stack3.remove();
            stack4.put(new Person(stack2.item(), stack1.item(),stack3.item()));
               
            Person pers = stack4.item(); pers.PrintPerson();
            stack4.remove(); pers = stack4.item(); pers.PrintPerson();
            stack4.remove(); pers = stack4.item(); pers.PrintPerson();
            stack4.remove(); if (stack4.empty()) Console.WriteLine("OK!");
        }
        static public void TestConstraint()
        {
            List.OneLinkList<int, string> list1 = new List.OneLinkList<int, string>();
               
            list1.add(33, "thirty three");
            list1.add(22, "twenty two");
            if (list1.findstart(33)) 
                Console.WriteLine ("33 - найдено!");   
            else Console.WriteLine("33 - не найдено!");
            if (list1.findstart(22))
                Console.WriteLine("22 - найдено!");
            else Console.WriteLine("22 - не найдено!");
            if (list1.findstart(44))
                Console.WriteLine("44 - найдено!");
            else Console.WriteLine("44 - не найдено!");
            Person pers1 = new Person("Савлов", 25, 1500);
            Person pers2 = new Person("Павлов", 35, 2100);
            List.OneLinkList<string, Person> list2 = new List.OneLinkList <string, Person>();
              
            list2.add("Савл", pers1);
            list2.add("Павел", pers2);
            if (list2.findstart("Павел"))
                Console.WriteLine("Павел - найдено!");   
            else Console.WriteLine("Павел - не найдено!");
            if (list2.findstart("Савл"))
                Console.WriteLine("Савл - найдено!");   
            else Console.WriteLine("Савл - не найдено!");
            if (list2.findstart("Иоанн"))
                Console.WriteLine("Иоанн - найдено!");   
            else Console.WriteLine("Иоанн - не найдено!");
            Person pers3 = new Person("Иванов", 33, 3000);
            list2.add("Иоанн", pers3);
            list2.start();
            Person pers = list2.Item(); 
            pers.PrintPerson();
            list2.findstart("Иоанн"); 
            pers = list2.Item();
            pers.PrintPerson();
        }
        static public void TestSum()
        {
            Calc.SumList<string, int> list1 = new Calc.SumList<string, int>(new Calc.IntCalc());
              
            list1.add("Петр", 33); list1.add("Павел", 44);
            Console.WriteLine("sum= {0}", list1.Sum());
            Calc.SumList<string, double> list2 =new Calc.SumList<string, double>(new Calc.DoubleCalc());
               
            list2.add("Петр", 33.33);
            list2.add("Павел", 44.44);
            Console.WriteLine("sum= {0}", list2.Sum());
            Calc.SumList<string, string> list3 =new Calc.SumList<string, string>(new Calc.StringCalc());
               
            list3.add("Мама", " Мама мыла ");
            list3.add("Маша","Машу мылом!");
               
            Console.WriteLine("sum= {0}", list3.Sum());
        }
        


static public void TestIntStack()
{
   IntStack stack1 = new IntStack();
   IntStack stack2 = new IntStack();
   IntStack stack3 = new IntStack();
   stack1.put(11); stack1.put(22);
   int x1 = stack1.item(), x2 = stack1.item();
   if ((x1 == x2) && (x1 == 22)) Console.WriteLine("OK!");
   stack1.remove(); x2 = stack1.item();
   if ((x1 != x2) && (x2 == 11)) Console.WriteLine("OK!");
   stack1.remove(); x2 = (stack1.empty()) ? 77 : 
      stack1.item();
   if ((x1 != x2) && (x2 == 77)) Console.WriteLine("OK!");
   stack2.put(55); stack2.put(66);
   stack2.remove(); int s = stack2.item();
   if (!stack2.empty()) Console.WriteLine(s);
   stack3.put(333); stack3.put((int)Math.Sqrt(Math.PI));
   int res = stack3.item();
   stack3.remove(); res += stack3.item();
   Console.WriteLine("res= {0}", res);
}
    }
}
