﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_10.Example1
{
    class Change
    {
        static public void Swap<T>(ref T x1, ref T x2)
        {
            T temp;
            temp = x1; x1 = x2; x2 = temp;
        }
    }
}
