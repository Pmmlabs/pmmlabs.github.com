﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_10.Stack
{
    
    /// <summary>
    /// Абстрактный класс GenStack<T> задает контейнер с 
    /// доступом LIFO:	
    /// Функции:
    /// конструктор new: -> GenStack<T>
    /// запросы:
    /// item: GenStack -> T
    /// empty: GenStack -> Boolean
    /// процедуры:
    /// put: GenStack*T -> GenStack
    /// remove: GenStack -> GenStack
    /// Аксиомы:
    /// remove(put(s,x)) = s
    /// item(put(s,x)) = x
    /// empty(new)= true
    /// empty(put(s,x)) = false
    /// </summary>
    abstract public class GenStack<T>
    {
        /// <summary>
        /// require: not empty();
        /// </summary>
        /// <returns>элемент вершины(последний пришедший)</returns>
        abstract public T item();
        /// <summary>
        /// require: not empty();
        /// ensure: удален элемент вершины(последний пришедший)
        /// </summary>
        abstract public void remove();
        /// <summary>
        /// require: true; ensure: elem находится в вершине стека
        /// </summary>
        /// <param name="elem"></param>
        abstract public void put(T t);
        /// <summary>
        /// require: true;
        /// </summary>
        /// <returns>true если стек пуст, иначе false </returns>
        abstract public bool empty();
    }// class GenStack

}
