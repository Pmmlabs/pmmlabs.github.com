﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_10.Stack
{
    public class ArrayUpStack<T> : GenStack<T>
    {
        int SizeOfStack;
        T[] stack;
        int top;
        /// <summary>
        /// конструктор
        /// </summary>
        /// <param name="size">размер стека</param>
        public ArrayUpStack(int size)
        { SizeOfStack = size; stack = new T[SizeOfStack]; top = 0; }
        /// <summary>
        /// require: (top < SizeOfStack)
        /// </summary>
        /// <param name="x"> элемент, помещаемый в стек</param>
        public override void put(T x)
        { stack[top] = x; top++; }

        public override void remove()
        { top--; }
        public override T item()
        { return (stack[top - 1]); }
        public override bool empty()
        { return (top == 0); }
    }//class ArrayUpStack
}
