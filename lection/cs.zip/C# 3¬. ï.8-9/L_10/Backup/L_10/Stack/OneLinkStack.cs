﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_10.Stack
{
    /// <summary>
    /// Стек, построенный на односвязных элементах списка GenLinkable<T>
    /// </summary>
    public class OneLinkStack<T> : GenStack<T>
    {
        public OneLinkStack()
        {
            last = null;
        }
        GenLinkable<T> last; //ссылка на стек (вершину стека)
        public override T item()
        {
            return (last.Item);
        }//item		
        public override bool empty()
        {
            return (last == null);
        }//empty
        public override void put(T elem)
        {
            GenLinkable<T> newitem = new GenLinkable<T>();
            newitem.Item = elem; newitem.Next = last;
            last = newitem;
        }//put 		
        public override void remove()
        {
            last = last.Next;
        }//remove
    }//class OneLinkStack


    public class GenLinkable<T>
    {
        public T Item;
        public GenLinkable<T> Next;
        public GenLinkable()
        { 
            Item = default(T);
            Next = null; 
        }
    }

}
