﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_10.Calc
{
    public abstract class Calc<T>
    {
        public abstract T Add(T a, T b);
        public abstract T Sub(T a, T b);
        public abstract T Mult(T a, T b);
        public abstract T Div(T a, T b);
    }

    public class IntCalc : Calc<int>
    {
        public override int Add(int a, int b) { return (a + b); }
        public override int Sub(int a, int b) { return (a - b); }
        public override int Mult(int a, int b) { return (a * b); }
        public override int Div(int a, int b) { return (a / b); }
    }

    public class DoubleCalc : Calc<double>
    {
        public override double Add(double a, double b)
        { return (a + b); }
        public override double Sub(double a, double b)
        { return (a - b); }
        public override double Mult(double a, double b)
        { return (a * b); }
        public override double Div(double a, double b)
        { return (a / b); }
    }

    public class StringCalc : Calc<string>
    {
        public override string Add(string a, string b)
        { return (a + b); }
        public override string Sub(string a, string b)
        { return (a); }
        public override string Mult(string a, string b)
        { return (a); }
        public override string Div(string a, string b)
        { return (a); }
    }
    public class SumList<K, T> : List.OneLinkList<K, T> where K :IComparable<K>
    {
        Calc<T> calc;
        T sum;
        public SumList(Calc<T> calc)
        {
            this.calc = calc; 
            sum = default(T);
        }
        public new void add(K key, T item)
        {
            List.Node<K, T> newnode = new List.Node<K, T>();
            if (first == null)
            {
                first = newnode;
                cursor = newnode;
                newnode.key = key;
                newnode.item = item;
                sum = calc.Add(sum, item);
            }
            else
            {
                newnode.next = cursor.next;
                cursor.next = newnode;
                newnode.key = key;
                newnode.item = item;
                sum = calc.Add(sum, item);
            }
        }
        public T Sum()
        { 
            return (sum);
        }
    }//SumList



}
