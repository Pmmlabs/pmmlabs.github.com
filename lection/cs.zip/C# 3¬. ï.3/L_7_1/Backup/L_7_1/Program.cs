﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_7_1
{
    public class MyException : Exception
    {
        public MyException()
        { }
        public MyException(string message)
            : base(message)
        { }
        public MyException(string message, Exception e)
            :
           base(message, e)
        { }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Testing t = new Testing();
            t.TestPattern();
        }
    }
    class Excepts
    {
            Random rnd = new Random();
            int level = -10;
            bool Success; //true - нормальное завершение
            int count = 1; // число попыток выполнения
            const int maxcount = 3;

            void MakeJob()
            {
                Console.WriteLine("Подготовительные работы завершены");
            }

            bool CheckDanger()
            {
                //проверка качества и возможности продолжения работ
                int low = rnd.Next(level, 10);
                if (low > 6) return (false);
                return (true);
            }

            void MakeLastJob()
            {
                Console.WriteLine("Все работы завершены успешно");
            }


            public void Pattern()
            {
                do
                {
                    try
                    {
                        bool Danger = false;
                        Success = true;
                        MakeJob();
                        Danger = CheckDanger();
                        if (Danger)
                            throw (new MyException());
                        MakeLastJob();
                    }
                    catch (MyException me)
                    {
                        if (count > maxcount)
                            throw (new MyException("Три попытки были  безуспешны"));
                        Success = false; count++;
                        //корректировка ситуации
                        Console.WriteLine("Попытка исправить ситуацию!");
                        level += 1;
                    }
                } while (!Success);
            }
    }
  public class Testing
  {
     public void TestPattern()
      {
       Excepts ex1 = new Excepts();
   try
   {
      ex1.Pattern();
   }
   catch (Exception e)
   {
      Console.WriteLine("исключительная ситуация при вызове Pattern");
      Console.WriteLine(e.ToString());
   }
}

  }
  }
   

