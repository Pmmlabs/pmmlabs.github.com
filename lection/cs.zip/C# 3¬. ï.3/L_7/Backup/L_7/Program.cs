﻿using System;
using System.Collections.Generic;
using System.Text;


namespace L_7
{
    public struct Rational
    {
        public Rational(int a, int b)
        {
            if (b == 0) { m = 0; n = 1; }
            else
            {
                //приведение знака
                if (b < 0) { b = -b; a = -a; }
                //приведение к несократимой дроби
                int p = 1, m1 = a, n1 = b;
                m1 = Math.Abs(m1); n1 = Math.Abs(n1);
                if (n1 > m1) { p = m1; m1 = n1; n1 = p; }
                do
                {
                    p = m1 % n1; m1 = n1; n1 = p;
                } while (n1 != 0);
                p = m1;
                m = a / p; n = b / p;
            }
        }//Конструктор
        //поля и методы класса
        //Поля класса. Числитель и знаменатель рационального числа.
        int m, n;
        //закрытый конструктор
        private Rational(int a, int b, string t)
        {
            m = a; n = b;
        }
        //Константы класса 0 и 1 - Zero и One
        public static readonly Rational Zero, One;

        //статический конструктор
        static Rational()
        {
            Console.WriteLine("static constructor Rational");
            Zero = new Rational(0, 1, "private");
            One = new Rational(1, 1, "private");
        }//Статический конструктор


        /// <summary>
        /// Закрытый метод класса.
        /// Возвращает наибольший общий делитель чисел a,b
        /// </summary>
        /// <param name="a">первое число</param>
        /// <param name="b">второе число, положительное</param>
        /// <returns>НОД(a,b)</returns>
        int nod(int m, int n)
        {
            int p = 0;
            m = Math.Abs(m); n = Math.Abs(n);
            if (n > m) { p = m; m = n; n = p; }
            do
            {
                p = m % n; m = n; n = p;
            } while (n != 0);
            return (m);
        }//nod

        //печать рациональных чисел
        public void PrintRational(string name)
        {
            Console.WriteLine(" {0} = {1}/{2}", name, m, n);
        }
        //операции над рациональными числами

        //операция плюс
        public Rational Plus(Rational a)
        {
            int u, v;
            u = m * a.n + n * a.m; v = n * a.n;
            return (new Rational(u, v));
        }//Plus

        // перегрузка оператора
        public static Rational operator +(Rational r1, Rational r2)
        {
            return (r1.Plus(r2));
        }
        public Rational Minus(Rational a)
        {
            int u, v;
            u = m * a.n - n * a.m; v = n * a.n;
            return (new Rational(u, v));
        }//Minus
        public static Rational operator -(Rational r1, Rational r2)
        {
            return (r1.Minus(r2));
        }
        public Rational Mult(Rational a)
        {
            int u, v;
            u = m * a.m; v = n * a.n;
            return (new Rational(u, v));
        }//Mult
        public static Rational operator *(Rational r1, Rational r2)
        {
            return (r1.Mult(r2));
        }
        public Rational Divide(Rational a)
        {
            int u, v;
            u = m * a.n; v = n * a.m;
            return (new Rational(u, v));
        }//Divide

        public static Rational operator /(Rational r1, Rational r2)
        {
            return (r1.Divide(r2));
        }
        //равенство
        public static bool operator ==(Rational r1, Rational r2)
        {
            return ((r1.m == r2.m) && (r1.n == r2.n));
        }
        //неравенство
        public static bool operator !=(Rational r1, Rational r2)
        {
            return ((r1.m != r2.m) || (r1.n != r2.n));
        }
        //меньше
        public static bool operator <(Rational r1, Rational r2)
        {
            return (r1.m * r2.n < r2.m * r1.n);
        }
        //больше
        public static bool operator >(Rational r1, Rational r2)
        {
            return (r1.m * r2.n > r2.m * r1.n);
        }
        //меньше вещественного
        public static bool operator <(Rational r1, double r2)
        {
            return ((double)r1.m / (double)r1.n < r2);
        }
        //больше вещественного
        public static bool operator >(Rational r1, double r2)
        {
            return ((double)r1.m / (double)r1.n > r2);
        }
    }


    class Program
    {
        static public void TwoSemantics()
         {
           Rational r1 = new Rational(1,3), r2 = new Rational(3,5);
           Rational r3, r4;
           r3 = r1+r2; r4 = r3;
           if(r3 >1) r3 = r1+r3 + Rational.One; 
             else r3 = r2+r3 - Rational.One;
            r3.PrintRational("r3"); r4.PrintRational("r4");
          }
         


        static void Main(string[] args)
        {
            TwoSemantics();
        }
    }
}
