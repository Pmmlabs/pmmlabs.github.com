﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_6_2
{
    class Program
    {
        static void Main(string[] args)
        {
           // TestClientSupplier();
            //TestFoundDerived();
            TestFoundDerivedReal();
          //  TestStack();
        }
        static void TestClientSupplier()
        {
            Samples.ClassB objB = new Samples.ClassB("AA", 22, "BB", 33);
            objB.MethodB1();
            objB.MethodB2();
            objB.MethodB3();
        }
        static void TestFoundDerived()
        {
            Samples1.Found bs = new Samples1.Found ("father", 777);
            Console.WriteLine("Объект bs вызывает методы базового класса");
            bs.VirtMethod();
            bs.NonVirtMethod();
            bs.Analysis();
            bs.Work();
            Samples1.Derived der = new Samples1.Derived();
            Console.WriteLine("Объект der вызывает методы класса потомка");
            der.VirtMethod();
            der.NonVirtMethod();
            der.Analysis();
            der.Work();
          }
        static void TestFoundDerivedReal()
        {
            Samples2.Found bs = new Samples2.Found("father", 777);
            Console.WriteLine("Объект bs вызывает методы класса Found");
            bs.VirtMethod();
            bs.NonVirtMethod();
            bs.Analysis();
            bs.Work();
            Samples2.Derived der = new Samples2.Derived("child", 888, 555);
            Console.WriteLine("Объект der вызывает методы класса Derived");
            der.DerivedMethod();
            der.VirtMethod();
            der.NonVirtMethod();
            der.Analysis();
            der.Work();
            Samples2.ChildDerived chider = new Samples2.ChildDerived("grandchild", 999, 444);
            Console.WriteLine("Объект chider вызывает методы ChildDerived");
            chider.VirtMethod();
            chider.NonVirtMethod();
            chider.Analysis(5);
            chider.Work();
        }
        static void TestStack()
        {
            Stack.ListStack stack = new Stack.ListStack();
            stack.put(7); 
            stack.put(9);
            Console.WriteLine(stack.item());
            stack.remove(); 
            Console.WriteLine(stack.item());
            stack.put(11);
            stack.put(13);
            Console.WriteLine(stack.item());
            stack.remove();
            Console.WriteLine(stack.item());
            if (!stack.IsEmpty()) stack.remove();
            Console.WriteLine(stack.item());    
        }
    }
}
