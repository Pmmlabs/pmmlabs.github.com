﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_6_2.Samples2
{
    public class ChildDerived:Derived
    {
        public ChildDerived(string name, int cred, int deb)
            : base(name, cred, deb)
        { }
        public override void VirtMethod()
        {
            Console.WriteLine("внук: " + this.ToString());
        }
        public void Analysis(int level)
        {
            base.Analysis();
            Console.WriteLine("Анализ глубины {0}", level);
        }
  
  
    }
}
