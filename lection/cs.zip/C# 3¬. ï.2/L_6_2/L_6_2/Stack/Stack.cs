﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_6_2.Stack
{
    public abstract class Stack
    {
        public Stack()
        { }
        /// <summary>
        /// втолкнуть элемент item  в стек
        /// </summary>
        /// <param name="item"></param>
        public abstract void put(int item);
        /// <summary>
        /// удалить элемент в вершине стека
        /// </summary>
        public abstract void remove();
        /// <summary>
        /// прочитать элемент в вершине стека
        /// </summary>
        public abstract int item();
        /// <summary>
        /// определить, пуст ли стек
        /// </summary>
        /// <returns></returns>
        public abstract bool IsEmpty();
    }


}
