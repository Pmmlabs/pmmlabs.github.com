﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_6_2.Stack
{
    public class ListStack: Stack
{
   public ListStack()
   {	
      top = new Linkable();
   }
   Linkable top;
   /// <summary>
   /// втолкнуть элемент item  в стек
   /// </summary>
   /// <param name="item"></param>
   public override void put(int item)
   {
      Linkable newitem = new Linkable();
      newitem.info = item;
      newitem.next = top;
      top = newitem;
   }
   /// <summary>
   /// удалить элемент в вершине стека
   /// </summary>
   public override void remove()
   {
      top = top.next;
   }
   /// <summary>
   /// прочитать элемент в вершине стека
   /// </summary>
   public override int item()
   {
      return(top.info);
   }
   /// <summary>
   /// определить, пуст ли стек
   /// </summary>
   /// <returns></returns>
   public override bool IsEmpty()
   {
      return(top.next == null);
   }
}

    }

