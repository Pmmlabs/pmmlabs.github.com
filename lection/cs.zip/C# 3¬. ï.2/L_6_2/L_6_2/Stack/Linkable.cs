﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_6_2.Stack
{
    public class Linkable
    {
        public Linkable()
        { }
        public int info;
        public Linkable next;
    }

}
