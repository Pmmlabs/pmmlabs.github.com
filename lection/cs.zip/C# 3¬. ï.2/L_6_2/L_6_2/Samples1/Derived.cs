﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_6_2.Samples1
{
    public class Derived:Found
    {
    }
}
