﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L_6_2.Samples
{
    class ClassA
    {
        public string fieldA1;
        public int fieldA2;

        public ClassA(string f1, int f2)
        {
            fieldA1 = f1;
            fieldA2 = f2;
        }
        public void MethodA()
        {
            Console.WriteLine("Это класс А");
            Console.WriteLine("поле1={0},поле2={1}",fieldA1,fieldA2);
        }
        public static void StatMethod()
        {
            string s1 = "Статический метод класса A";
            string s2 = "Помните: 2*2=4";
            Console.WriteLine(s1+"*****"+s2);
        }
    }

}
