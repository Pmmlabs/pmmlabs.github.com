﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace L_6_1
{
    class Man {			          // 1
        const int l_name = 30;
        string name;
        int birth_year;
        double pay;
        public Man()            // конструктор по умолчанию
        {
            name = "Anonimous";
            birth_year = 0;
            pay = 0;
        }
        public Man(string s) 			                                // 2
        {
            name        = s.Substring(0, l_name-1);
            birth_year  = Convert.ToInt32(s.Substring(l_name, 4));
            pay         = Convert.ToDouble(s.Substring(l_name + 4));
            if (birth_year < 0) throw new FormatException();
            if (pay < 0)        throw new FormatException();
        }
        public override string ToString()	                            // 3
        {
            return string.Format( "Name: {0,30} birth: {1} pay: {2:F2}", 
                                  name, birth_year, pay);
        }
        public int Compare(string name) // сравнение фамилии
        {
            return (string.Compare(this.name, 0, 
					name + " ", 0, name.Length + 1, 
					StringComparison.OrdinalIgnoreCase));
        }
    	// --------------------  свойства класса --------------------------
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public int Birth_year
        {
            get { return birth_year; }
            set { if (value > 0) birth_year = value; 
                  else throw new FormatException(); }
        }
        public double Pay
        {
            get { return pay; }
            set { if (value > 0) pay = value;
                  else throw new FormatException(); }
        }
		// ------------------  операции класса ------------------------------
        public static double operator +(Man man1, double a)
        {
            man1.pay += a;
            return man1.pay;
        }
        public static double operator +(double a, Man man1)
        {
            man1.pay += a;
            return man1.pay;
        }
        public static double operator -(Man man1, double a)
        {
            man1.pay -= a;
            if ( man1.pay < 0 ) throw new FormatException();
            return man1.pay;
        }
    };
 class Program
    {
       
        static void Main()
        {
            Man[] dbase = new Man[100];
            int n = 0;
            try
            {
                StreamReader f = new StreamReader("dbase.txt");         // 4

                string s;
                int i = 0;

                while ((s = f.ReadLine()) != null)                      // 5
                {
                    dbase[i] = new Man(s);
                    Console.WriteLine(dbase[i]);
                    ++i;
                }
                n = i - 1;
                f.Close();
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(" Проверьте правильность имени файла!");
                return;
            }

            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Слишком большой файл!");
                return;
            }
            catch (FormatException)
            {
                Console.WriteLine("Недопустимая дата рождения или оклад");
                return;
            }

            catch (Exception e)
            {
                Console.WriteLine("Ошибка: " + e.Message);
                return;
            }

            int n_man = 0;
            double mean_pay = 0;
            Console.WriteLine("Введите фамилию сотрудника");
            string name;
            while ((name = Console.ReadLine()) != "")                   // 6
            {
                bool not_found = true;
                for ( int k = 0; k <= n; ++k )
                {
                    Man man = dbase[k];
                    if (man.Compare(name) == 0)
                    {
                        Console.WriteLine(man);
                        ++n_man; mean_pay += man.Pay;
					    not_found = false;
                    }
                }
                if (not_found) Console.WriteLine("Такого сотрудника нет");
                Console.WriteLine(
	"Введите фамилию сотрудника или Enter для окончания");
            }
            if (n_man > 0) 
			Console.WriteLine("Средний оклад: {0:F2}", mean_pay / n_man);
        }
    }
}
