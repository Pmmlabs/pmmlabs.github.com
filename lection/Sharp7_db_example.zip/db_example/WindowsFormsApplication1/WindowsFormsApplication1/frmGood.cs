﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frmGood : Form
    {
        int? _updateId = null;
        public frmGood()
        {
            InitializeComponent();

            this.Text = "Добавление товара";
            button1.Text = "Добавить";
            TxtName.Enabled = true;
            label1.Enabled = true;

        }

        public frmGood(int updateId, string name, double price)
        {
            InitializeComponent();
            _updateId = updateId;
            this.Text = "Изменение цены";
            button1.Text = "Изменить";
            TxtName.Text = name;
            txtPrice.Text = price.ToString("0.00");
            TxtName.Enabled = false;
            label1.Enabled = false;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            //проверку данных !!!!
            if (_updateId == null)
            {
                //добавление
                DBManager2.InsertGood(TxtName.Text, double.Parse(txtPrice.Text));
            }
            else
            {
                //редактирование
                DBManager2.UpdateGood(Convert.ToDouble(txtPrice.Text), (int)_updateId);
            }

        }
    }
}
