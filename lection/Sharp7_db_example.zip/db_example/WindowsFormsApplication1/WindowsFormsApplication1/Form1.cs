﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
        }
        private DataTable goodsTable = null;
        private void btnLoad_Click(object sender, EventArgs e)
        {
            goodsTable = DBManager1.GetGoodsTable();
            dataGridView1.DataSource = goodsTable;
            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            DBConnection.Close();
        }

        private void btnAcceptChanges_Click(object sender, EventArgs e)
        {
          //  goodsTable.AcceptChanges();
            DBManager1.UpdateDB(goodsTable);
           
        }

        private void btnRejectChanges_Click(object sender, EventArgs e)
        {
            goodsTable.RejectChanges();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DBConnection.Open();
            DBManager1.InitAdapter();
        }

        private void btnLoadGridFromDB_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = DBManager2.GetGoodsLst();

        }

        private void btnAddGood_Click(object sender, EventArgs e)
        {
            frmGood frm = new frmGood();
            if (frm.ShowDialog() == DialogResult.OK)
            {
               // dataGridView1.DataSource = DBManager2.GetGoodsLst(); // !!! -
                dataGridView1.Update();
            }
        }

        private void btnUpdateGood_Click(object sender, EventArgs e)
        {
            frmGood frm = new frmGood((int)dataGridView1.SelectedRows[0].Cells[0].Value, dataGridView1.SelectedRows[0].Cells[1].Value.ToString(), Convert.ToDouble(dataGridView1.SelectedRows[0].Cells[2].Value));
            if (frm.ShowDialog() == DialogResult.OK)
            {
                dataGridView1.DataSource = DBManager2.GetGoodsLst(); // !!! -
            }
        }

        private void btnDeleteGood_Click(object sender, EventArgs e)
        {
            DBManager2.DeleteGood((int)dataGridView1.SelectedRows[0].Cells[0].Value);
            dataGridView1.DataSource = DBManager2.GetGoodsLst(); // !!! -
        }

        
    }
}
