﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btmLoad = new System.Windows.Forms.Button();
            this.btnAcceptChanges = new System.Windows.Forms.Button();
            this.btnRejectChanges = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnDeleteGood = new System.Windows.Forms.Button();
            this.btnUpdateGood = new System.Windows.Forms.Button();
            this.btnAddGood = new System.Windows.Forms.Button();
            this.btnLoadGridFromDB = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(21, 23);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(442, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // btmLoad
            // 
            this.btmLoad.Location = new System.Drawing.Point(6, 19);
            this.btmLoad.Name = "btmLoad";
            this.btmLoad.Size = new System.Drawing.Size(159, 28);
            this.btmLoad.TabIndex = 1;
            this.btmLoad.Text = "Загрузить данные";
            this.btmLoad.UseVisualStyleBackColor = true;
            this.btmLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnAcceptChanges
            // 
            this.btnAcceptChanges.Location = new System.Drawing.Point(6, 53);
            this.btnAcceptChanges.Name = "btnAcceptChanges";
            this.btnAcceptChanges.Size = new System.Drawing.Size(159, 28);
            this.btnAcceptChanges.TabIndex = 2;
            this.btnAcceptChanges.Text = "Внести изменения в базу";
            this.btnAcceptChanges.UseVisualStyleBackColor = true;
            this.btnAcceptChanges.Click += new System.EventHandler(this.btnAcceptChanges_Click);
            // 
            // btnRejectChanges
            // 
            this.btnRejectChanges.Location = new System.Drawing.Point(6, 87);
            this.btnRejectChanges.Name = "btnRejectChanges";
            this.btnRejectChanges.Size = new System.Drawing.Size(159, 28);
            this.btnRejectChanges.TabIndex = 3;
            this.btnRejectChanges.Text = "Откатить изменения";
            this.btnRejectChanges.UseVisualStyleBackColor = true;
            this.btnRejectChanges.Click += new System.EventHandler(this.btnRejectChanges_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(159, 366);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(159, 28);
            this.btnClear.TabIndex = 4;
            this.btnClear.Text = "Очистить DataGrid";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btmLoad);
            this.groupBox1.Controls.Add(this.btnAcceptChanges);
            this.groupBox1.Controls.Add(this.btnRejectChanges);
            this.groupBox1.Location = new System.Drawing.Point(21, 189);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(182, 125);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Работа с DataSet";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnDeleteGood);
            this.groupBox2.Controls.Add(this.btnUpdateGood);
            this.groupBox2.Controls.Add(this.btnAddGood);
            this.groupBox2.Controls.Add(this.btnLoadGridFromDB);
            this.groupBox2.Location = new System.Drawing.Point(279, 189);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(182, 157);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Работа напрямую с БД";
            // 
            // btnDeleteGood
            // 
            this.btnDeleteGood.Location = new System.Drawing.Point(6, 121);
            this.btnDeleteGood.Name = "btnDeleteGood";
            this.btnDeleteGood.Size = new System.Drawing.Size(166, 28);
            this.btnDeleteGood.TabIndex = 3;
            this.btnDeleteGood.Text = "Удалить товар";
            this.btnDeleteGood.UseVisualStyleBackColor = true;
            this.btnDeleteGood.Click += new System.EventHandler(this.btnDeleteGood_Click);
            // 
            // btnUpdateGood
            // 
            this.btnUpdateGood.Location = new System.Drawing.Point(6, 87);
            this.btnUpdateGood.Name = "btnUpdateGood";
            this.btnUpdateGood.Size = new System.Drawing.Size(166, 28);
            this.btnUpdateGood.TabIndex = 2;
            this.btnUpdateGood.Text = "Редактировать цену";
            this.btnUpdateGood.UseVisualStyleBackColor = true;
            this.btnUpdateGood.Click += new System.EventHandler(this.btnUpdateGood_Click);
            // 
            // btnAddGood
            // 
            this.btnAddGood.Location = new System.Drawing.Point(6, 53);
            this.btnAddGood.Name = "btnAddGood";
            this.btnAddGood.Size = new System.Drawing.Size(166, 28);
            this.btnAddGood.TabIndex = 1;
            this.btnAddGood.Text = "Добавить товар";
            this.btnAddGood.UseVisualStyleBackColor = true;
            this.btnAddGood.Click += new System.EventHandler(this.btnAddGood_Click);
            // 
            // btnLoadGridFromDB
            // 
            this.btnLoadGridFromDB.Location = new System.Drawing.Point(6, 19);
            this.btnLoadGridFromDB.Name = "btnLoadGridFromDB";
            this.btnLoadGridFromDB.Size = new System.Drawing.Size(166, 28);
            this.btnLoadGridFromDB.TabIndex = 0;
            this.btnLoadGridFromDB.Text = "Загрузить данные";
            this.btnLoadGridFromDB.UseVisualStyleBackColor = true;
            this.btnLoadGridFromDB.Click += new System.EventHandler(this.btnLoadGridFromDB_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(473, 406);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btmLoad;
        private System.Windows.Forms.Button btnAcceptChanges;
        private System.Windows.Forms.Button btnRejectChanges;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnDeleteGood;
        private System.Windows.Forms.Button btnUpdateGood;
        private System.Windows.Forms.Button btnAddGood;
        private System.Windows.Forms.Button btnLoadGridFromDB;
    }
}

