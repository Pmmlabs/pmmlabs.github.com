﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    class DBManager2
    {
        public static List<Good> GetGoodsLst()
        {
            OleDbCommand command = new OleDbCommand("select * from Goods", DBConnection.Connection);
            OleDbDataReader reader = command.ExecuteReader();
            List<Good> result = new List<Good>();
            while (reader.Read())
            {
                result.Add(new Good()
                {
                    Id = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    Price = double.Parse(reader.GetValue(2).ToString()),
                });
            }
            reader.Close();
            return result;
        }

        public static void InsertGood(string name, double price)
        {
            OleDbCommand command = new OleDbCommand("insert into Goods(name, price) values (@name, @price)", DBConnection.Connection);
            command.Parameters.Add(new OleDbParameter("@name", name));
            command.Parameters.Add(new OleDbParameter("@price", price));
            command.ExecuteNonQuery();
        }

        public static void UpdateGood(double price, int id)
        {
            OleDbCommand command = new OleDbCommand(string.Format("update Goods set price = {0} where id = {1}", price.ToString().Replace(",", "."), id), DBConnection.Connection);
            command.ExecuteNonQuery();
        }

        public static void DeleteGood(int id)
        {
            OleDbCommand command = new OleDbCommand("delete from Goods where id = @id", DBConnection.Connection);
            command.Parameters.Add(new OleDbParameter("@id", id));
            command.ExecuteNonQuery();
        }
    }
}
