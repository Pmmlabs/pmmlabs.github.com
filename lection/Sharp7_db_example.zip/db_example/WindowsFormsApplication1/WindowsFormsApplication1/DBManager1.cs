﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public class DBManager1
    {
        static OleDbDataAdapter adapter;

        public static void InitAdapter()
        {
            adapter = new OleDbDataAdapter("select * from Goods", DBConnection.Connection);
            OleDbCommandBuilder commandBuilder = new OleDbCommandBuilder(adapter);
            adapter.InsertCommand = commandBuilder.GetInsertCommand(true);
            adapter.UpdateCommand = commandBuilder.GetUpdateCommand(true);
            adapter.DeleteCommand = commandBuilder.GetDeleteCommand(true);
        }
        public static DataTable GetGoodsTable()
        {
            DataTable result = new DataTable("Goods");
            adapter.Fill(result);
            return result;
        }

        public static void UpdateDB(DataTable dt)
        {
            adapter.Update(dt);
        }
    }
}
