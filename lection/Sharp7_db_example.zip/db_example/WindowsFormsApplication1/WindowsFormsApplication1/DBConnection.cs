﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    /// <summary>
    /// соединение с БД
    /// </summary>
    public static class DBConnection
    {
        /// <summary>
        /// строка, содержащая параметры для соединения
        /// </summary>
        private const string connectionString =
            "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=db1.mdb;User ID=Admin;Password=;";

        private static OleDbConnection connection = new OleDbConnection(connectionString);
        public static OleDbConnection Connection 
        {
            get { return connection; } 
        }

        public static void Open()
        {
            if (Connection.State != ConnectionState.Open)
            {
                Connection.Open();
            }
        }

        public static void Close()
        {
            if (Connection.State != ConnectionState.Closed)
            {
                Connection.Close();
            }
        }
    }
}
