﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private TextClass data;
        public MainWindow()
        {
            InitializeComponent();
            
        }
        public void LoadData()
        {
            data = new TextClass() { Text = "Hello!" };
            tbName.DataContext = data;
         //   data.Text = "Hi!";
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        private void btnInFile_Click(object sender, RoutedEventArgs e)
        {
            using (StreamWriter w = new StreamWriter("1.txt"))
            {
                w.WriteLine(data.Text);
                w.Close();
            }
        }
    }
}
