﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfApplication1
{
    public class TextClass
    {
        public string Text { get; set; }
    }
}
