
#include "Counter.h"

Counter Counter::operator ++()
{
 ++count;
return Counter(count);
}

Counter Counter::operator ++(int
{
++count;
return Counter(count);
}