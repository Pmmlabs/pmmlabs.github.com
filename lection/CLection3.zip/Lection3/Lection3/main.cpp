#include "Counter.h"
int main()
{ Counter c1,c2;
cout<<c1.get()<<endl;
cout<<c2.get()<<endl;
++c1;
c2=c1++;
cout<<c1.get()<<endl;
cout<<c2.get()<<endl;
return 0;
}