// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"
#include <math.h>
#include <stdio.h>
#include <tchar.h>

class Vector
{
	double x,y;
public:
	double getX() {return x;}
	double getY() {return y;}
	double getLength() const { return sqrt(x*x+y*y); }
	Vector operator + (Vector &v);
	Vector operator + (double z);
	friend Vector operator + (double z,Vector &v);
	bool operator > (Vector &v) {return getLength()>v.getLength();}
}