// stdafx.cpp : source file that includes just the standard includes
// Lection3a.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "Vector.h"
Vector Vector::operator + (Vector &v)
{
	return Vector (x+v.getX(), y+v.getY());
}
Vector Vector::operator + (double z)
{
	return Vector (x+z, y+z);
}
Vector operator + (double z, Vector &v)
{ 
	return Vector (z+v.getX(),z+v.getY();
}
// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
