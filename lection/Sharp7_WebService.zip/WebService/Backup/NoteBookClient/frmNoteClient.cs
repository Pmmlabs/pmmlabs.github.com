﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using NoteBookService;

namespace NoteBookClient
{
    public partial class frmNoteClient : Form
    {
        public frmNoteClient()
        {
            InitializeComponent();
            c = new NoteBookClient.ServiceReference1.NoteBookServiceSoapClient();
        }
        //web-сервис (через прокси-сборку, протокол soap)
        ServiceReference1.NoteBookServiceSoapClient c = null;
        //получание список заметок
        private void frmNoteClient_Load(object sender, EventArgs e)
        {

            dgvNotes.DataSource = c.GetNoteBook();
        }
        //добавление новой заметки
        private void btnAdd_Click(object sender, EventArgs e)
        {
            //форма добавления заметки
            NoteForm nf = new NoteForm();
            if (nf.ShowDialog() == DialogResult.OK)
            {
                //добавление заметки методом сервиса
                c.AddNote(nf.NoteElem);
                //получение списка заметок
                dgvNotes.DataSource = c.GetNoteBook(); 
            }
        }
        //редактирование заметки
        private void btnEdit_Click(object sender, EventArgs e)
        {
            //определение индекса редактируемой заметки
            if (dgvNotes.SelectedRows == null || dgvNotes.SelectedRows.Count == 0)
                return;
            int index = dgvNotes.SelectedRows[0].Index;
            //форма редактирования заметки
            NoteForm nf = new NoteForm();
            nf.NoteElem = c.GetNoteBook()[index];
            if (nf.ShowDialog() == DialogResult.OK)
            {
                //редактирование заметки через метод сервиса
                c.EditNote(nf.NoteElem, index);
                //получение списка заметок 
                dgvNotes.DataSource = c.GetNoteBook();
            }
        }
        //удаление заметки
        private void btnDelete_Click(object sender, EventArgs e)
        {
            //определение индекса удаляемой заметки
            if (dgvNotes.SelectedRows == null || dgvNotes.SelectedRows.Count == 0)
                return;
            int index = dgvNotes.SelectedRows[0].Index;
            //удаление заметки с помощью сервиса
            c.DeleteNote(index);
            //получение списка заметок
            dgvNotes.DataSource = c.GetNoteBook();
            
        }
        //получение списка заметок за определенную дату
        private void dtpDate_ValueChanged(object sender, EventArgs e)
        {
            dgvNotes.DataSource = c.GetNoteBookByDate(dtpDate.Value.Date);
        }
        //получение списка всех заметок
        private void btnAll_Click(object sender, EventArgs e)
        {
            dgvNotes.DataSource = c.GetNoteBook();
        }
    }
}
