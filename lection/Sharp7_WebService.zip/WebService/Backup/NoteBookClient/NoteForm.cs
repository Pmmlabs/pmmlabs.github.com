﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using NoteBookClient.ServiceReference1;

namespace NoteBookClient
{
    public partial class NoteForm : Form
    {
        //заметка (новая или редактируемая)
        public Note NoteElem = null;
        public NoteForm()
        {
            InitializeComponent();
        }
        //добавление (редактирование) заметки
        private void btnOk_Click(object sender, EventArgs e)
        {
            if (tbText.Text.Trim() == "")
            {
                MessageBox.Show("Введите текст заметки", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            NoteElem = new Note()
            {
                Date = dtpDate.Value.Date,
                NoteText = tbText.Text
            };
            DialogResult = DialogResult.OK;
        }
        //отмена
        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
        //загрузка данных о заметке в поля формы (для редактируемой заметки)
        private void NoteForm_Load(object sender, EventArgs e)
        {
            if (NoteElem != null)
            {
                tbText.Text = NoteElem.NoteText;
                dtpDate.Value = NoteElem.Date;
            }
        }


    }
}
