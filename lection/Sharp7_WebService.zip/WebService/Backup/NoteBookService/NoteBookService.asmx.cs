﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace NoteBookService
{
    /// <summary>
    /// Summary description for Service1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class NoteBookService : System.Web.Services.WebService
    {
        /// <summary>
        /// список заметок
        /// </summary>
        private NoteBook noteBook = new NoteBook();
        
        /// <summary>
        /// получить список заметок
        /// </summary>
        /// <returns>список заметок</returns>
        [WebMethod]
        public List<Note> GetNoteBook()
        {
            //загружаем список заметок
            noteBook = NoteBook.Load();
            return noteBook.NoteList;
        }
        
        /// <summary>
        /// получить список заметок за определенную дату
        /// </summary>
        /// <param name="date">дата</param>
        /// <returns>список заметок</returns>
        [WebMethod]
        public List<Note> GetNoteBookByDate(DateTime date)
        {
            //загружаем список заметок
            noteBook = NoteBook.Load();
            //выбираем заметки за указанную дату 
            return noteBook.NoteList.Where(entry => entry.Date == date).ToList();
        }
        /// <summary>
        /// добавить заметку
        /// </summary>
        /// <param name="note">заметка</param>
        [WebMethod]
        public void AddNote(Note note)
        {
            //загружаем список заметок
            noteBook = NoteBook.Load();
            //добавляем заметку
            noteBook.NoteList.Add(note);
            //сохраняем список
            noteBook.Save();
        }
        /// <summary>
        /// изменить заметку
        /// </summary>
        /// <param name="note">новая заметка</param>
        /// <param name="index">индекс в списке</param>
        [WebMethod]
        public void EditNote(Note note, int index)
        {
            //загружаем список заметок
            noteBook = NoteBook.Load();
            //заменяем заметку с указаным индексом
            noteBook.NoteList[index] = note;
            //сохраняем список
            noteBook.Save();
        }
        [WebMethod]
        public void DeleteNote(int index)
        {
            //загружаем список заметок
            noteBook = NoteBook.Load();
            //удаляем заметку с указанным индексом
            noteBook.NoteList.RemoveAt(index);
            //сохраняем список
            noteBook.Save();
        }
       

    }
}
