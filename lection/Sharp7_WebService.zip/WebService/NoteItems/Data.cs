﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Text;

namespace NoteBookService
{
    /// <summary>
    /// заметка
    /// </summary>
    [Serializable]
    public class Note
    {
        private DateTime date;
        /// <summary>
        /// дата заметки
        /// </summary>
        public DateTime Date 
        {
            get { return date; }
            set { date = value; }
        }
        private string noteText;
        /// <summary>
        /// тест заметки
        /// </summary>
        public string NoteText
        {
            get { return noteText; }
            set { noteText = value; }
        }
 
    }
    /// <summary>
    /// список заметок
    /// </summary>
    [Serializable]
    public class NoteBook
    {
        /// <summary>
        /// список заметок
        /// </summary>
        public List<Note> NoteList = new List<Note>();
        /// <summary>
        /// путь к файлу заметок
        /// </summary>
        [NonSerialized]
        const string filename = "C:\\notebook.xml";
        /// <summary>
        /// загрузка из xml-файла заметок (десериализация)
        /// </summary>
        /// <returns></returns>
        public static NoteBook Load()
        {
            NoteBook nb = new NoteBook();
            if (!File.Exists(filename)) return nb;
            XmlReader reader = new XmlTextReader(filename);
            XmlSerializer serializer = new XmlSerializer(typeof(NoteBook));
            nb = (NoteBook)serializer.Deserialize(reader);
            reader.Close();
            return nb;
        }
        /// <summary>
        /// сохранения список в xml-файл(сериализация)
        /// </summary>
        public void Save()
        {
            XmlWriter writer = new XmlTextWriter(filename, Encoding.Unicode);
            XmlSerializer serializer = new XmlSerializer(typeof(NoteBook));
            serializer.Serialize(writer, this);
            writer.Close();
        }
    }
}
