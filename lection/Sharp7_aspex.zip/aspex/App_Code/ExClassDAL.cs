﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ExClassDAL
/// </summary>
public class ExClassDAL
{
    static List<ExClass> result = null;
    private static List<ExClass> Result
    {
        get
        {
            if (result == null)
            {
                result = new List<ExClass>();
                result.Add(new ExClass() { Id = 1, Name = "a" });
                result.Add(new ExClass() { Id = 2, Name = "b" });
                result.Add(new ExClass() { Id = 3, Name = "c" });
            }
            return result;
        }
    }

    public List<ExClass> GetExClassesForFilter(int id, string name)
    {
        var res = GetExClasses(0, null);
        res.Insert(0, new ExClass() { Id = 0, Name = "All" });
        return res;
    }

    public List<ExClass> GetExClasses(int id, string name)
    {
        IEnumerable<ExClass> resGet = Result;
        if (id != 0)
        {
            resGet = resGet.Where(item => item.Id == id);
        }
        if (!string.IsNullOrEmpty(name) && name != "All")
        {
            resGet = resGet.Where(item => item.Name == name);
        }
        return resGet.ToList();
    }

    public static void insertExClass(int id, string name)
    {
        ExClass exCl = new ExClass()
        {
            Id = id,
            Name = name
        };
        Result.Add(exCl);

    }

    public static void UpdateExClass(int id, string name)
    {
        var exCl = Result.Where(item => item.Id == id).FirstOrDefault();
        if (exCl == null)
            return;
        exCl.Name = name;
    }

    public static void DeleteExClass(int id)
    {
        var exCl = Result.Where(item => item.Id == id).FirstOrDefault();
        if (exCl == null)
            return;
        Result.Remove(exCl);
    }


}