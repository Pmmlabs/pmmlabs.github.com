﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


/*
 >при изменении индекса combobox фильтра таблица gridview должна обновляться.
 посмотрите внимательно откно конфигурирования датасорса, на последней странице надо выбрать поле и прописать что оно связано с контролом, посмотрите это на моем примере в датасорс1 
 >delete не работает (автоматический delete gridview) - выбор строки не работает.
 я свойства GridView на msdn
 в GridView надо добавить тег DataKeyNames="id" т.е. прописать что является ключом, можно прямо тегом а можно через свойства гридвью
 >переход и передача параметров на другую страницу (запрос на связь двух таблиц через третью).
1) переход описан в GridView1_RowDataBound (привязка параметра) и в GridView1_RowCommand (сам переход) получение параметра на странице 
 * возможно через Request.Params["Id"] (например если нам этот параметр на форме отображать)
 * а если он нужен в датасорсе для селекта то можно так:
 * в тег <SelectParameters> у датасорса добавляем: (Name - это имя параметра в методе, а QueryStringField - имя в командной строке)
      <asp:QueryStringParameter Name="id" QueryStringField="Id" Type="Int32" />
   если еще один способ через сессии примерно так:
 * Page.Session["Id"] = id; сначала кладем потом достаем когда надо
 * 
 */
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
   
    }

    protected void DetailsView1_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
    {        
        ObjectDataSource2.Select();
        DropDownList1.DataBind();
     }
    protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e)
    {
         
        ObjectDataSource2.Select();
        DropDownList1.DataBind();
    }
    protected void GridView1_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
       
        ObjectDataSource2.Select();
        DropDownList1.DataBind();
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Button btn = e.Row.FindControl("btnGo") as Button;
            if (btn != null)
                btn.CommandArgument = ((ExClass)e.Row.DataItem).Id.ToString();
        }
    
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Go")
            Response.Redirect("Default2.aspx?Id=" + e.CommandArgument);
    }
}