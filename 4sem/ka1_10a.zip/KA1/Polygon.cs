﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KA1
{
    class Polygon
    {
        public List<Point> points { get; protected set; } //динамический массив точек 
        
        public Polygon()
        {
            points = new List<Point>();
        }
        
        public void AddPoint(int X, int Y)
        {
            points.Add(new Point(X, Y, points.Count));
        }
        //алгоритм генерации следующей перестановки
        public void nextPermutation()
        {
            for (int i = points.Count - 2; i > 0; --i)
            {
                if (points[i].n < points[i + 1].n)
                {
                    int min = i + 1;
                    for (int j = i + 1; j < points.Count; ++j)
                    {
                        if ((points[j].n < points[min].n) && (points[j].n > points[i].n))
                        {
                            min = j;
                        }
                    }
                    points.Swap(i, min);
                    points.Reverse(i + 1, points.Count - i - 1);
                    return;
                }
            }
            points = null;
        }

        /// <summary>
        /// метод проверяет, что в многоугольнике нет пересечений
        /// </summary>
        /// <returns>true - если пересечений нет</returns>
        private bool NoIntersections()
        {
            for(int i = 0; i < points.Count; ++i)
            {
                for(int j = i + 1; j < points.Count; ++j)
                {
                    if(Segment.Intersect(points[i], points[(i + 1) % points.Count], points[j], points[(j + 1) % points.Count]))
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// проверка на выпуклость (в этом методе самопересекающиеся многоугольники не рассматриваются, проверка 
        /// на самопересечения осуществляется методом NoIntersections)
        /// </summary>
        /// <returns>true - если многоугольник выпуклый</returns>
        private bool Convex()
        {
            int i, j, k; //номера проверяемых точек
            //движение по часовой - определитель все время должен быть отрицательным
            bool cw = false;
            //движение против часовой - определитель все время должен быть положительным
            bool ccw = false;
            int z; //определитель

            if (points.Count < 3)
                return false;

            for (i = 0; i < points.Count; ++i)
            {
                j = (i + 1) % points.Count;
                k = (i + 2) % points.Count;
                z = (points[j].X - points[i].X) * (points[k].Y - points[j].Y) -
                    (points[j].Y - points[i].Y) * (points[k].X - points[j].X);
                if (z < 0)
                {
                    if (ccw) return false;
                    cw = true;
                }
                else if (z > 0)
                {
                    if (cw) return false;
                    ccw = true;
                }
                else return false;
            }
            return true;
        }

        // Попытка создать выпуклый многоугольник
        public virtual bool TryCreateConvex(ref long progress, ref long total)
        {
            total = Utils.FactNaive(points.Count - 1);
            progress = 0;
            while(points != null)
            {
                if (NoIntersections() && Convex())
                    return true;
                nextPermutation();
                ++progress;
            }
            points = new List<Point>();
            progress = total;
            return false;
        }
    }
}
