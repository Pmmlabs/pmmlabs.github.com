﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
// Задание 1.
// 10а.Выпуклость многоугольника. На плоскости своими координатами заданы N точек. 
// Необходимо определить порядок их соединения для получения: ломаной в виде выпуклого многоугольника.

namespace KA1
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
