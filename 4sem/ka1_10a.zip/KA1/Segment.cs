﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KA1
{
    class Segment
    {
        public Point A { get; private set; }
        public Point B { get; private set; }
        public Segment(Point A, Point B)
        {
            this.A = A;
            this.B = B;
        }

        private static int Area(Point a, Point b, Point c)
        {
            return (b.X - a.X) * (c.Y - a.Y) - (b.Y - a.Y) * (c.X - a.X);
        }

        private static bool intersect_1(int a, int b, int c, int d)
        {
            if (a > b) Utils.Swap(ref a, ref b);
            if (c > d) Utils.Swap(ref c, ref d);
            return Math.Max(a, c) <= Math.Min(b, d);
        }
        
        /// <summary>
        /// метод проверяет, пересекаются ли отрезки ab и cd
        /// </summary>
        public static bool Intersect(Point a, Point b, Point c, Point d)
        {
            return intersect_1(a.X, b.X, c.X, d.X)
                && intersect_1(a.Y, b.Y, c.Y, d.Y)
                && Math.Abs(Math.Sign(Area(a, b, c)) - Math.Sign(Area(a, b, d))) == 2 //разные знаки у площадей
                && Math.Abs(Math.Sign(Area(c, d, a)) - Math.Sign(Area(c, d, b))) == 2;
        }
    }
}
