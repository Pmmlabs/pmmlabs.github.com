#ifndef TGUITREE_H
#define TGUITREE_H

#include "ttrietree.h"

class TGuiTree : public TTrieTree {
private:
    string fFilename;
    bool isModified;
    void setFilename(string s);

public:
    TGuiTree();
    bool isCreated;
    bool addWord(string word);
    bool delWord(string word);
    bool loadFromFile(string fname);
    //void saveFile();
    void saveToFile(string fname);
    void clearTree();
    string getFilename();
    bool getModified();
};

#endif // TGUITREE_H
