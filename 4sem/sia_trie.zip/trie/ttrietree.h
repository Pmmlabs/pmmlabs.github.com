#ifndef TTRIETREE_H
#define TTRIETREE_H

#include "tnode.h"

class TTrieTree {
private:
    TNode fRoot;

    void delNodes(TTrieTree *t);
public:
    //TTrieTree();
    bool add(string word);
    bool del(string word);
    void printToQLW(QListWidget *lw);
    void printToFile(string fname);
    bool search(QListWidget *lw, string pref);
    void clear();
    bool isEmpty();
    bool addFromFile(string fname);

    static bool checkWord(string word);

};

#endif // TTRIETREE_H
