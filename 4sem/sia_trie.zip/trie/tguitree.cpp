#include "tguitree.h"

TGuiTree::TGuiTree() {
    isModified = false;
    fFilename = "";
    //isCreated = false;
}

void TGuiTree::setFilename(string s) {
//    if (s != "")
//        fFilename = s;
}

string TGuiTree::getFilename() {
    return fFilename;
}



bool TGuiTree::getModified() {
    return isModified;
}

bool TGuiTree::addWord(string word) {
    bool tmp = this->add(word);
    isModified = tmp || isModified;
    return tmp;
}

bool TGuiTree::delWord(string word) {
    bool tmp= this->del(word);
    isModified = tmp || isModified;
    return tmp;
}

void TGuiTree::clearTree() {
    isModified = !this->isEmpty() || isModified;
    this->clear();

}

//was every word added ? true : false
bool TGuiTree::loadFromFile(string fname) {
    fFilename = fname;
    isModified = false;
    return this->addFromFile(fname);
}

//void TGuiTree::saveFile() {
//    isModified = false;
//    this->printToFile(fFilename);
//}

void TGuiTree::saveToFile(string fname) {
    fFilename = fname;
    isModified = false;
    this->printToFile(fname);
}
