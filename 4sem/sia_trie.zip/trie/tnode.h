#ifndef TNODE_H
#define TNODE_H

#include <map>
#include <algorithm>
#include <string>
#include <fstream>
#include <QListWidget>

using namespace std;

class TNode;

const char lowCh = 'a';
const char highCh = 'z';

typedef map<char, TNode> array;

class TNode {
private:
    array fMas;
    bool fEow;    
    //void getAllAndPrint(QListWidget *lw, string pref);
public:
    TNode();  //constructor

    void init();
    bool add(string word);
    bool del(string word, bool *isDel);
    void printReverse(QListWidget *lw, string &pref);
    void print(QListWidget *lw, string &word);
    void printToFile(ofstream &fout, string &word);

    void clear();
    bool delLetter(char c);

    bool hasNext(char c);
    void* getNext(char c);

    bool isEmpty();

    static string reverseStr(string const& inp);

};

#endif // TNODE_H
