#include "tnode.h"
#include <string>
#include <fstream>


string TNode::reverseStr(string const& inp) {
    string outp;
    int n = inp.length();
    for (int i = 0; i < n; i++)
        outp.push_back(inp[n-i-1]);
    return outp;
}

TNode::TNode() {
    fEow = false;
}

/*
void TNode::init() {
    fEow = false;
}
*/

bool TNode::add(string word) {
    bool result;
    if (word == "") {
        result = !fEow;
        fEow = true;        
    } else {
        char first = word[0];
        word = word.erase(0,1);
        result = fMas[first].add(word);
    }
    return result;
}

bool TNode::del(string word, bool *isDel) {
    bool result;
    if (word == "") {
        result = fEow;
        fEow = false;
    } else {
        if (hasNext(word[0])) {
            char first = word[0];
            word = word.erase(0,1);
            result = fMas[first].del(word, isDel);
            if (*isDel)
                fMas.erase(fMas.find(first));
        } else
            result = false;
    }
    *isDel = fMas.empty() && !fEow;
    return result;
}


void TNode::printReverse(QListWidget *lw, string &pref) {
    if (fEow)// && word != "")
        lw->addItem(QString::fromStdString(reverseStr(pref)));
    for (char c = lowCh; c <= highCh; c++) {
        if (fMas.find(c) != fMas.end()) {
            pref.push_back(c);
            fMas[c].printReverse(lw, pref);
            pref = pref.erase(pref.length()-1,1);
        }

    }
}

bool TNode::hasNext(char c) {
    return fMas.find(c) != fMas.end();
}

 void* TNode::getNext(char c) {
    return &fMas[c];
}

void TNode::print(QListWidget *lw, string &word) {
    if (fEow)
        lw->addItem(QString::fromStdString(word));
    for (char c = lowCh; c <= highCh; c++) {
        if (fMas.find(c) != fMas.end()) {
            word.push_back(c);
            fMas[c].print(lw, word);
            word = word.erase(word.length()-1,1);
        }
    }
}

bool TNode::isEmpty() {
    return (fMas.empty() && !fEow);
}

void TNode::clear() {
    fMas.clear();
    fEow = false;
}
bool TNode::delLetter(char c) {
    if (fMas.find(c) != fMas.end()) {
        fMas.erase(fMas.find(c));
        return true;
    } else
        return false;
}

void TNode::printToFile(ofstream &fout, string &word) {
    if (fEow)
        fout << reverseStr(word) << " ";
    for (char c = lowCh; c <= highCh; c++) {
        if (fMas.find(c) != fMas.end()) {
            word.push_back(c);
            fMas[c].printToFile(fout, word);
            word = word.erase(word.length()-1,1);
        }
    }

}
