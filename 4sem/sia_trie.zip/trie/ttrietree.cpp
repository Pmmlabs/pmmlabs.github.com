#include "ttrietree.h"

bool TTrieTree::checkWord(string str) {
    bool good = true;
    for (int i = 0; i < str.length() && good; i++)
        good = (str.at(i) >= lowCh && str.at(i) <= highCh);
    return good;
}

bool TTrieTree::add(string word) {
    bool result = checkWord(word);
    if (result)
        result = fRoot.add(word);
    return result;
}

bool TTrieTree::del(string word) {
    bool result = checkWord(word);
    if (result) {
        bool start = false;
        char fr = word[0];
        bool result = fRoot.del(word, &start);
        if (start && result) //added
            result = fRoot.delLetter(fr);
    }
    return result;
}

void TTrieTree::printToQLW(QListWidget *lw) {
    lw->clear();
    string s = "";
    fRoot.printReverse(lw, s);
}


bool TTrieTree::search(QListWidget *lw, string pref) {

    bool ok = checkWord(pref);
    TTrieTree *sub = this;
    int len = pref.length();
    int i = 0;
    while (ok && i < len) {
        //есть такая буква в массиве
        ok = sub->fRoot.hasNext(pref[i]);
        if (ok)
            sub = (TTrieTree*)sub->fRoot.getNext(pref[i]);
        i++;
    }
    if (ok)
        sub->fRoot.printReverse(lw, pref);
    return ok;
}



void TTrieTree::clear() {
    fRoot.clear();
    //eow! + added
}

bool TTrieTree::isEmpty() {
    return fRoot.isEmpty();
    //eow + added
}

void TTrieTree::printToFile(string fname) {
    ofstream fout(fname.c_str());
    string s = "";
    fRoot.printToFile(fout, s);
}

bool TTrieTree::addFromFile(string fname) {
    this->clear();
    bool result = true;
    ifstream fin(fname.c_str());
    string tmp;
    while(fin >> tmp) {
        if (!this->add(TNode::reverseStr(tmp)))
            result = false;
    }
    return result;
}
