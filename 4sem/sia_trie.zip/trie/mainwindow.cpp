#include "mainwindow.h"
#include "ui_mainwindow.h"



MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ttree = NULL;

    updateUi();

}

void MainWindow::updateUi() {
    //зависят от наличия дерева
    ui->actionSave->setEnabled(ttree != NULL);
    ui->actionSave_as->setEnabled(ttree != NULL);

    //зависят от поиска
    ui->resultWordList->setEnabled(ui->resultWordList->count() != 0);
    ui->actionClear_result->setEnabled(ui->resultWordList->count() != 0);
    ui->actionSave_result->setEnabled(ui->resultWordList->count() != 0);

    //изменение при добавлении/удалении
    ui->actionDel->setEnabled(ttree != NULL && !ttree->isEmpty());
    ui->actionAdd->setEnabled(ttree != NULL);
    ui->actionClear->setEnabled(ttree != NULL && !ttree->isEmpty());

    //зависят от количества элементов в дереве
    ui->actionFind_by_suffix->setEnabled(ttree != NULL && !ttree->isEmpty());
    ui->actionFind_word->setEnabled(ttree != NULL && !ttree->isEmpty());
}

MainWindow::~MainWindow()
{
    if (ttree != NULL)
        delete ttree;
    delete ui;
}


void MainWindow::addDelAction() {
    ui->resultWordList->clear();
    //ui->resultWordList->setEnabled(false);
    //ui->actionClear_result->setEnabled(false);
    //ui->actionSave_result->setEnabled(false);
}

void MainWindow::closeTree() {
    bool canClose = true;
    if (ttree->getModified()) {
        int ans = QMessageBox::question(this, "Save edited tree", "Save tree?", QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
        switch (ans) {
        case QMessageBox::Yes:
            ui->actionSave->triggered(true);
            canClose = !ttree->getModified();
            break;
        case QMessageBox::No:
            break;
        case QMessageBox::Cancel:
            canClose = false;
            break;
        }
    }
    if (canClose) {
        //ttree->clearTree();
        ui->fileWordList->clear();
        delete ttree;
        ttree = NULL;

        updateUi();


        ui->statusBar->showMessage("Tree was closed");
    }
}


void MainWindow::on_treeFind_clicked() {

}

void MainWindow::on_fillTree_clicked() {

}


void MainWindow::on_actionExit_triggered() {
    if (ttree != NULL)
        closeTree();
    if (ttree == NULL)
        MainWindow::closeEvent(0);
}

void MainWindow::on_actionSave_as_triggered() {
    QString fname = QFileDialog::getSaveFileName(this, "Save tree to file", "output.txt", "Textfile (*.txt);;All Files (*)");
    if (fname != "") {
        ttree->saveToFile(fname.toStdString());
        ui->statusBar->showMessage("Tree was saved to " + fname);
    }
}

void MainWindow::on_actionAdd_triggered() {
    bool mbOK;
    QString str = QInputDialog::getText(this, "Add word", "Enter word (no digits!)", QLineEdit::Normal, "", &mbOK);
    if (mbOK) {
        if (ttree->addWord(TNode::reverseStr(str.toStdString()))) {
            //ui->fileWordList->addItem(str);
            //очищаем поле результата и убираем кнопочки
            addDelAction();
            updateUi();

            ui->statusBar->showMessage("Item was added");

        ttree->printToQLW(ui->fileWordList);
        }
    }
}

void MainWindow::on_actionFind_by_suffix_triggered() {
    bool mbOK;
    QString str = QInputDialog::getText(this, "Search by suffix", "Enter suffix", QLineEdit::Normal, "", &mbOK);
    if (mbOK) {
        ui->resultWordList->clear();
        string suffix = str.toStdString();
        string prefix = TNode::reverseStr(suffix);
        bool goodSearch = false;
        goodSearch = ttree->search(ui->resultWordList, prefix);

        updateUi();


        QString msg = "Found " + QString::number(ui->resultWordList->count()) + " items";
        ui->statusBar->showMessage(msg);

    }
}

void MainWindow::on_actionDel_triggered() {
    bool mbOK;
    QString str = QInputDialog::getText(this, "Delete word", "Enter word", QLineEdit::Normal, "", &mbOK);
    if (mbOK) {
        if (ttree->delWord(TNode::reverseStr(str.toStdString())))
        {
        ttree->printToQLW(ui->fileWordList);

        //очищаем поле результата и убираем кнопочки
        addDelAction();
        updateUi();

        ui->statusBar->showMessage("Item was deleted");
        }
    }
}

void MainWindow::on_actionClear_triggered() {
    int ans = QMessageBox::critical(this, "Clear tree", "Are you sure?", "Yes", "No");
    if (ans == 0) {
        ui->fileWordList->clear();
        ttree->clearTree();


        ui->resultWordList->clear();
        updateUi();

        ui->statusBar->showMessage("Tree was cleared");
    }
}

void MainWindow::on_actionFind_word_triggered() {
    ui->actionFind_by_suffix->triggered(true);
}

void MainWindow::on_actionSave_triggered() {

    string fname = ttree->getFilename();
    if (fname != "") {
        ttree->saveToFile(fname);
        ui->statusBar->showMessage("Tree was saved to " + QString::fromStdString(ttree->getFilename()));
    } else
        ui->actionSave_as->triggered(true);


}

void MainWindow::on_actionAbout_triggered() {
    QMessageBox::about(this, "Trie Tree", "(c) Якунцев Никита, 2 к. МОиАИС, 2014");
}

void MainWindow::on_actionClear_result_triggered() {
    if (ui->resultWordList->isEnabled()) {
        int ans = QMessageBox::critical(this, "Clear result field", "Are you sure?", "Yes", "No");
        if (ans == 0) {
            ui->resultWordList->clear();

            updateUi();
            ui->statusBar->showMessage("Result was cleared");
        }
    }
}

void MainWindow::on_actionNew_triggered() {
    if (ttree != NULL)
        closeTree();
    //если закроылось удачно
    if (ttree == NULL) {
        ttree = new TGuiTree;

        //ui->fileWordList->clear();
        ui->resultWordList->clear();
        ui->statusBar->showMessage("New tree was created");
    }

    updateUi();
}

void MainWindow::on_actionSave_result_triggered() {
    QString fname = QFileDialog::getSaveFileName(this, "Save tree to file", "result.txt", "Textfile (*.txt);;All Files (*)");
    if (fname != "") {
        ofstream fout(fname.toStdString().c_str());
        for(int i = 0; i < ui->resultWordList->count(); i++)
            //pring to stream
            fout << ui->resultWordList->item(i)->text().toStdString() << " ";
        ui->statusBar->showMessage("Result was saved to " + fname);
    }
}

void MainWindow::on_actionOpen_triggered() {
    QString fname = QFileDialog::getOpenFileName(this, "Open file", "", "Textfile (*.txt);;All Files (*)");
    if (fname != "") {
        if (ttree != NULL)
            closeTree();
        //если закрылось удачно
        if (ttree == NULL) {
            ttree = new TGuiTree;
            ttree->loadFromFile(fname.toStdString());
            ttree->printToQLW(ui->fileWordList);
            //ttree->isCreated = true;
            ui->resultWordList->clear();

            ui->statusBar->showMessage("Loaded " + QString::number(ui->fileWordList->count()) + " items");

        }
        updateUi();
    }
}

void MainWindow::resizeEvent(QResizeEvent *event){
    int nw = this->width() / 2 - 10;
    int nh = this->geometry().height() - this->statusBar()->height() - 50;

    ui->fileWordList->resize(nw,nh);

    ui->resultWordList->setGeometry(ui->fileWordList->geometry().right(), ui->fileWordList->geometry().top(), nw, nh);

}
