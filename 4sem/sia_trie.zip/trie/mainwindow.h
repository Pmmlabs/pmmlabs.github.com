#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "tguitree.h"
#include <string>
#include <fstream>
#include <QInputDialog>
#include <QFileDialog>
#include <QMessageBox>
#include <QResizeEvent>

using namespace std;

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    TGuiTree *ttree;
    void setCreated(bool b);
    void closeTree();
    void addDelAction();

    
private slots:
    void on_treeFind_clicked();
    void on_fillTree_clicked();


    void on_actionExit_triggered();

    void on_actionSave_as_triggered();

    void on_actionAdd_triggered();

    void on_actionFind_by_suffix_triggered();

    void on_actionDel_triggered();

    void on_actionClear_triggered();

    void on_actionFind_word_triggered();

    void on_actionSave_triggered();

    void on_actionAbout_triggered();

    void on_actionClear_result_triggered();

    void on_actionNew_triggered();

    void on_actionSave_result_triggered();

    void on_actionOpen_triggered();

protected:
    void resizeEvent(QResizeEvent *event);

private:
    Ui::MainWindow *ui;
    void updateUi();
};

#endif // MAINWINDOW_H
