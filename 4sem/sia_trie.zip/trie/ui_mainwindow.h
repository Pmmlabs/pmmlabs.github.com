/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.0.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionNew;
    QAction *actionOpen;
    QAction *actionSave;
    QAction *actionSave_as;
    QAction *actionAdd;
    QAction *actionDel;
    QAction *actionClear;
    QAction *actionFind_word;
    QAction *actionFind_by_suffix;
    QAction *actionSave_result;
    QAction *actionAbout;
    QAction *actionExit;
    QAction *actionClear_result;
    QWidget *centralWidget;
    QListWidget *fileWordList;
    QListWidget *resultWordList;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QMenu *menuEdit;
    QMenu *menuSearch;
    QMenu *menuHelp;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(476, 344);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        actionNew = new QAction(MainWindow);
        actionNew->setObjectName(QStringLiteral("actionNew"));
        actionOpen = new QAction(MainWindow);
        actionOpen->setObjectName(QStringLiteral("actionOpen"));
        actionSave = new QAction(MainWindow);
        actionSave->setObjectName(QStringLiteral("actionSave"));
        actionSave_as = new QAction(MainWindow);
        actionSave_as->setObjectName(QStringLiteral("actionSave_as"));
        actionAdd = new QAction(MainWindow);
        actionAdd->setObjectName(QStringLiteral("actionAdd"));
        actionDel = new QAction(MainWindow);
        actionDel->setObjectName(QStringLiteral("actionDel"));
        actionClear = new QAction(MainWindow);
        actionClear->setObjectName(QStringLiteral("actionClear"));
        actionFind_word = new QAction(MainWindow);
        actionFind_word->setObjectName(QStringLiteral("actionFind_word"));
        actionFind_by_suffix = new QAction(MainWindow);
        actionFind_by_suffix->setObjectName(QStringLiteral("actionFind_by_suffix"));
        actionSave_result = new QAction(MainWindow);
        actionSave_result->setObjectName(QStringLiteral("actionSave_result"));
        actionSave_result->setEnabled(false);
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QStringLiteral("actionAbout"));
        actionExit = new QAction(MainWindow);
        actionExit->setObjectName(QStringLiteral("actionExit"));
        actionExit->setMenuRole(QAction::TextHeuristicRole);
        actionClear_result = new QAction(MainWindow);
        actionClear_result->setObjectName(QStringLiteral("actionClear_result"));
        actionClear_result->setEnabled(false);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        fileWordList = new QListWidget(centralWidget);
        fileWordList->setObjectName(QStringLiteral("fileWordList"));
        fileWordList->setGeometry(QRect(10, 21, 181, 251));
        resultWordList = new QListWidget(centralWidget);
        resultWordList->setObjectName(QStringLiteral("resultWordList"));
        resultWordList->setEnabled(false);
        resultWordList->setGeometry(QRect(280, 21, 181, 251));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 476, 20));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QStringLiteral("menuFile"));
        menuEdit = new QMenu(menuBar);
        menuEdit->setObjectName(QStringLiteral("menuEdit"));
        menuSearch = new QMenu(menuBar);
        menuSearch->setObjectName(QStringLiteral("menuSearch"));
        menuHelp = new QMenu(menuBar);
        menuHelp->setObjectName(QStringLiteral("menuHelp"));
        MainWindow->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuEdit->menuAction());
        menuBar->addAction(menuSearch->menuAction());
        menuBar->addAction(menuHelp->menuAction());
        menuFile->addAction(actionNew);
        menuFile->addAction(actionOpen);
        menuFile->addAction(actionSave);
        menuFile->addAction(actionSave_as);
        menuFile->addSeparator();
        menuFile->addAction(actionExit);
        menuEdit->addAction(actionAdd);
        menuEdit->addAction(actionDel);
        menuEdit->addSeparator();
        menuEdit->addAction(actionClear);
        menuSearch->addAction(actionFind_word);
        menuSearch->addAction(actionFind_by_suffix);
        menuSearch->addSeparator();
        menuSearch->addAction(actionSave_result);
        menuSearch->addAction(actionClear_result);
        menuHelp->addAction(actionAbout);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        actionNew->setText(QApplication::translate("MainWindow", "New", 0));
        actionOpen->setText(QApplication::translate("MainWindow", "Open", 0));
        actionSave->setText(QApplication::translate("MainWindow", "Save", 0));
        actionSave_as->setText(QApplication::translate("MainWindow", "Save as..", 0));
        actionAdd->setText(QApplication::translate("MainWindow", "Add", 0));
        actionDel->setText(QApplication::translate("MainWindow", "Del", 0));
        actionClear->setText(QApplication::translate("MainWindow", "Clear", 0));
        actionFind_word->setText(QApplication::translate("MainWindow", "Find word", 0));
        actionFind_by_suffix->setText(QApplication::translate("MainWindow", "Find by suffix", 0));
        actionSave_result->setText(QApplication::translate("MainWindow", "Save result", 0));
        actionAbout->setText(QApplication::translate("MainWindow", "About", 0));
        actionExit->setText(QApplication::translate("MainWindow", "Exit", 0));
        actionClear_result->setText(QApplication::translate("MainWindow", "Clear result", 0));
        menuFile->setTitle(QApplication::translate("MainWindow", "File", 0));
        menuEdit->setTitle(QApplication::translate("MainWindow", "Edit", 0));
        menuSearch->setTitle(QApplication::translate("MainWindow", "Search", 0));
        menuHelp->setTitle(QApplication::translate("MainWindow", "Help", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
