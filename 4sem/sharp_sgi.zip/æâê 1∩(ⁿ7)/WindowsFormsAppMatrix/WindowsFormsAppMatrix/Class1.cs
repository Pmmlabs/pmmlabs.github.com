﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication1
{
    class Matrix 
    {
        int size;
        double[,] matrix;
        public Matrix(int n)
        {
            size = n;
            matrix=new double[size,size];
        }
        public void GridToMatrix(DataGridView dgv)
        {
            DataGridViewCell txtCell;
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    txtCell = dgv.Rows[i].Cells[j];
                    string s = txtCell.Value.ToString();
                    if (s == "")
                        matrix[i, j] = .0;
                    else
                        matrix[i, j] = Double.Parse(s);
                }
            }
        }
        public void MatrixToGrid(DataGridView dgv)
        {
            int i;
            DataTable matr = new DataTable("matr");
            DataColumn[] cols = new DataColumn[size];
            for (i = 0; i < size; i++)
            {
                cols[i] = new DataColumn(i.ToString());
                matr.Columns.Add(cols[i]);
            }
            for (i = 0; i < size; i++)
            {
                DataRow newRow;
                newRow = matr.NewRow();
                matr.Rows.Add(newRow);
            }
            dgv.DataSource = matr;
            for (i = 0; i < size; i++)
                dgv.Columns[i].Width = 40;
            DataGridViewCell txtCell;
            for (i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    txtCell = dgv.Rows[i].Cells[j];
                    txtCell.Value = matrix[i, j].ToString();
                }
            }
        }

        public /**/void getRow(string line, int rowNum)
        {
            int k = 0;
            int i;
            double d;
            string subline = "";
            bool canParse = true;
            while (line.Length > 0 && canParse)
            {
                i = line.IndexOf(" ");
                if (i < 0)
                {
                    subline = line;
                    line = "";
                }
                else
                {
                    subline = line.Substring(0, i);
                    line = line.Substring(i + 1);
                    line.Trim();
                }
                canParse=Double.TryParse(subline,out d) && k<size;
                if (canParse)
                {
                    matrix[rowNum, k] = d;
                    k++; 
                }
            }
            //return (k==size);
        }

        public void Processing()
        {
            int i;
            int j;
            int nNeg = 0;
            double sNeg = .0;
            for(i=0;i<size;i++)
                for (j=0;j<size;j++)
                    if (matrix[i, j] < .0)
                    {
                        nNeg++;
                        sNeg += matrix[i, j];
                    }
            if (nNeg < size)
            {
                for (i = 0; i < size; i++)
                    for (j = 0; j < size; j++)
                        if (matrix[i, j] < .0)
                            matrix[i, j] *= matrix[i, j];
            }
            else
            {
                double average = sNeg / nNeg;
                for (i = 0; i < size; i++)
                    for (j = 0; j < size; j++)
                        if (matrix[i, j] > .0)
                            matrix[i, j] =average;
            }
        }

       /* public void MatrixToStrings(string[] output)
        {
           string[] output = new string[size];
            string str;
            for (int i = 0; i < size; i++)
            {
                str="";
                for (int j = 0; j < size; j++)
                    str = str + " " + matrix[i, j].ToString();
                output[i] = str;
            }
        }*/
        public void loadToFile(StreamWriter stW)
        {
            string str;
            for (int i = 0; i < size; i++)
            {
                str = "";
                for (int j = 0; j < size; j++)
                    str = str + " " + matrix[i, j].ToString();
                stW.WriteLine(str);
            }
        }
    }
}
