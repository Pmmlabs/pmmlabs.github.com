﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication1
{
    public partial class FMain : Form
    {
        public FMain()
        {
            InitializeComponent();
        }
        const string TASK = "Если количество отрицательных элементов <n,заменить эти элементы их квадратами; иначе заменить все положительные элементы средним арифметическим отрицательных.";
        private string fileName = string.Empty;

        private void aboutTaskToolStripMenuItem_Click(object sender, EventArgs e)
        {
            toolTipHelp.Show(TASK, labelTmp, 5000);
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fileName == "")
            {
                if (openFileDlg.ShowDialog() == DialogResult.OK)
                {
                    StreamReader stR = new StreamReader(openFileDlg.FileName);
                    fileName = openFileDlg.FileName;
                    textBoxIn.Text = stR.ReadToEnd();
                    stR.Close();
                }
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fileName == "")
            {
                if (saveFileDlg.ShowDialog() == DialogResult.OK)
                {
                    fileName = saveFileDlg.FileName;
                    StreamWriter stW = new StreamWriter(fileName, true, Encoding.GetEncoding(1251));
                    stW.WriteLine(textBoxIn.Text);
                    stW.Close();
                }
            }
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDlg = new SaveFileDialog();
            saveFileDlg.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            if (saveFileDlg.ShowDialog() == DialogResult.OK)
            {
                StreamWriter stWr = new StreamWriter(saveFileDlg.FileName, false, Encoding.GetEncoding(1251));
                stWr.WriteLine(textBoxIn.Text);
                stWr.Close();
            }
        }

        private void saveResultToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int size = dataGridViewOut.RowCount - 1;
            Matrix m = new Matrix(size);
            m.GridToMatrix(dataGridViewOut);
            SaveFileDialog saveFileDlg = new SaveFileDialog();
            saveFileDlg.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            if (saveFileDlg.ShowDialog() == DialogResult.OK)
            {
                StreamWriter stWr = new StreamWriter(saveFileDlg.FileName, false, Encoding.GetEncoding(1251));
                m.loadToFile(stWr);
                stWr.Close();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
      
        private void loadToGridToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] input = textBoxIn.Lines;
            int size = Int32.Parse(input[0]);
            Matrix m = new Matrix(size);
            string subline;
            for (int i = 0; i < size;i++ )
            {
                subline = input[i+1];
                m.getRow(subline, i);
            }
            m.MatrixToGrid(dataGridViewIn);
        }

        private void runToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int size = dataGridViewIn.RowCount - 1;
            Matrix m = new Matrix(size);
            m.GridToMatrix(dataGridViewIn);
            m.Processing();
            m.MatrixToGrid(dataGridViewOut);
        }

        private void clearResultToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataTable matr = new DataTable("matr");
            int size = dataGridViewOut.RowCount-1;
            DataColumn[] cols = new DataColumn[size];

            for (int i = 0; i < size; i++)
            {
                cols[i] = new DataColumn(i.ToString());
                matr.Columns.Add(cols[i]);
            }

            for (int i = 0; i < size; i++)
            {
                DataRow newRow;
                newRow = matr.NewRow();
                matr.Rows.Add(newRow);
            }
            dataGridViewOut.DataSource = matr;
        }

    }
}
/*int i;
DataTable matr = new DataTable("matr");
DataColumn[] cols = new DataColumn[size];

for (i = 0; i < size; i++)
{
    cols[i] = new DataColumn(i.ToString());
    matr.Columns.Add(cols[i]);
}

for (i = 0; i < size; i++)
{
    DataRow newRow;
    newRow = matr.NewRow();
    matr.Rows.Add(newRow);
}
dataGridViewIn.DataSource = matr;
for (i = 0; i < size; i++)
    dataGridViewIn.Columns[i].Width = 40;*/