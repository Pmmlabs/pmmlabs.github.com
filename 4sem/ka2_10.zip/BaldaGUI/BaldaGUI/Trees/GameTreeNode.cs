﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaldaGUI.Trees
{
    public class GameTreeNode
    {
        internal string value { get; set; }
        internal GameTreeNode parent { get; set; }
        internal LinkedList<GameTreeNode> children;
        internal char letter;
        internal Position position;

        public GameTreeNode(string value, GameTreeNode parent, char letter, Position position) : this(value, parent)
        {
            this.letter = letter;
            this.position = position;
        }

        /*
        public List<GameTreeNode> Ancestors
        {
            get
            {
                GameTreeNode ancestor = this;
                List<GameTreeNode> list = new List<GameTreeNode>();
                do
                {
                    list.Add(ancestor);
                    ancestor = ancestor.parent;
                } while (ancestor != null);
                return list;
            }
        }
        */

        public void FillBoard(GameBoard gb)
        {
            GameTreeNode ancestor = this;
            while(ancestor != null)
            {
                gb[ancestor.position].Letter = ancestor.letter;
                ancestor = ancestor.parent;
            }
        }

        public void ClearBoard(GameBoard gb)
        {
            GameTreeNode ancestor = this;
            while (ancestor != null)
            {
                gb[ancestor.position].Letter = '\0';
                ancestor = ancestor.parent;
            }
        }

        public GameTreeNode(string value, GameTreeNode parent)
        {
            this.value = value;
            this.parent = parent;
            children = new LinkedList<GameTreeNode>();
        }

        public void AddChild(string word)
        {
            children.AddLast(new GameTreeNode(word, this));
        }

        public void AddChild(string word, char letter, Position position)
        {
            children.AddLast(new GameTreeNode(word, this, letter, position));
        }

        public GameTreeNode(string value) : this(value, null) { }
        public GameTreeNode() : this("") { }

        /// <summary>
        /// метод проверяет, использовалось ли слово в данной игре
        /// то есть проверяет, находилось ли слово в ветке, идущей от корня до этого звена
        /// </summary>
        /// <param name="word">проверяемое слово</param>
        /// <returns>содержалось ли слово</returns>
        public bool Contains(string word)
        {
            GameTreeNode ancestor = this;
            while(ancestor != null)
            {
                if(ancestor.value == word)
                {
                    return true;
                }
                else
                {
                    ancestor = ancestor.parent;
                }
            }
            return false;
        }
    }
}
