﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaldaGUI
{
    public class PostfNode : BaseNode
    {
        public PostfNode()
        {
            point = false;
            next = new PostfNode[RusAlphabetStr.Length];
        }

        public override bool AddWord(ref string word)
        {
            if (word == "")
            {
                bool result = !point;
                point = true;
                return result;
            }
            
            int lastLetter = IndexOfChar(word[word.Length - 1]);

            if (next[lastLetter] == null)
                next[lastLetter] = new PostfNode();
            word = word.Substring(0, word.Length - 1);

            return next[lastLetter].AddWord(ref word);
        }

        public override bool Find(ref string word)
        {
            PostfNode curr = this;
            PostfNode next;
            int i = word.Length - 1;

            while (i != -1 && (next = (PostfNode)curr.next[BaseNode.IndexOfChar(word[i])]) != null)
            {
                curr = next;
                --i;
            }
            return curr.point && i == -1;
        }

        public override bool Delete(ref string word)
        {
            if (word == "")
            {
                point = false;
                return true;
            }
            
            int lastLetter = IndexOfChar(word[word.Length - 1]); // index of las(T) letter

            word = word.Substring(0, word.Length - 1);
            bool result = next[lastLetter] != null &&
                 next[lastLetter].Delete(ref word);

            if (result && next[lastLetter].IsEmpty)
                next[lastLetter] = null;
            return result;
        }
    }

    public class PostfTrieTree : BaseTrieTree
    {
        public override void AddWord(string word)
        {
            if (!BaseNode.CheckWord(word))
                throw new Exception("Недопустимое слово");

            if (!_root)
                _root = new PostfNode();
            bool result = _root.AddWord(ref word);
            if (result)
                modified = true;
        }

        public override BaseNode FindStart(ref string word)
        {
            PostfNode curr = (PostfNode)_root;
            int i = word.Length - 1;

            while (i != -1 && curr.next[BaseNode.IndexOfChar(word[i])] != null)
            {
                curr = (PostfNode)curr.next[BaseNode.IndexOfChar(word[i])];
                --i;
            }

            return i == -1 ? curr : null;
        }
        
        public override void SaveToFile(string filename)
        {
            if (!_root)
                throw new Exception("Пустое дерево");

            string contents = "";
            _root.ForEachWord(w => contents = w + contents + " ", "");
            File.WriteAllText(filename, contents);
            modified = false;
            _currentFilename = filename;
        }
    }
}
