﻿using System;
using System.Linq;
using System.IO;

namespace BaldaGUI
{
    public class PrefNode : BaseNode
    {    
        public PrefNode()
        {
            point = false;
            next = new PrefNode[RusAlphabetStr.Length];
        }        

        public override bool AddWord(ref string word)
        {
            if (word == "")
            {
                bool result = !point;
                point = true;
                return result;
            }

            int firstLetter = IndexOfChar(word[0]);

            if (next[firstLetter] == null)
                next[firstLetter] = new PrefNode();
            word = word.Substr(1);

            return next[firstLetter].AddWord(ref word);
        }

        public override bool Find(ref string word)
        {
            PrefNode curr = this;
            PrefNode next;
            int i = 0;

            while (i != word.Length && (next = (PrefNode)curr.next[BaseNode.IndexOfChar(word[i])]) != null)
            {
                curr = next;
                ++i;
            }
            return curr.point && i == word.Length;
        }

        public override bool Delete(ref string word)
        {
            if (word == "")
            {
                point = false;
                return true;
            }

            int f = IndexOfChar(word[0]);

            word = word.Substr(1);
            bool result = next[f] != null && next[f].Delete(ref word);

            if (result && next[f].IsEmpty)
                next[f] = null;
            return result;
        }
    }

    public class PrefTrieTree : BaseTrieTree
    {
        public override void AddWord(string word)
        {
            if (!BaseNode.CheckWord(word))
                throw new Exception("Недопустимое слово");

            if (!_root)
                _root = new PrefNode();
            bool result = _root.AddWord(ref word);
            if (result)
                modified = true;
        }

        public override BaseNode FindStart(ref string word)
        {
            PrefNode curr = (PrefNode)_root;
            int i = 0;

            while (curr.next[BaseNode.IndexOfChar(word[i])] != null && i != word.Length)
            {
                curr = (PrefNode)curr.next[BaseNode.IndexOfChar(word[i])];
                ++i;
            }

            return i == word.Length ? curr : null;
        }

        public override void SaveToFile(string filename)
        {
            if (!_root)
                throw new Exception("Пустое дерево");

            string contents = "";
            _root.ForEachWord(w => contents += w + " ", "");
            File.WriteAllText(filename, contents);
            modified = false;
            _currentFilename = filename;
        }
    }
}