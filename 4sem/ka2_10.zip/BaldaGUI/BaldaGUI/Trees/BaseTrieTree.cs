﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaldaGUI
{
    public delegate void DoForEachWord(string word);
    public static class Extensions
    {
        public static bool Between(this char c, char l, char r)
        {
            return c >= l && c <= r;
        }

        public static string Substr(this string s, int index)
        {
            return s == "" ? "" : s.Substring(index);
        }
    }


    public class BaseNode
    {
        public static HashSet<char> RusAlphabet = new HashSet<char>("абвгдеёжзийклмнопрстуфхцчшщъыьэюя");
        public static string RusAlphabetStr = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя";
        protected bool _point;
        protected BaseNode[] _next;

        public bool point
        {
            get { return _point; }
            set { _point = value; }
        }

        public static implicit operator bool(BaseNode n)
        {
            return n != null;
        }

        public BaseNode[] next
        {
            get { return _next; }
            set { _next = value; }
        }

        public bool IsEmpty
        {
            get
            {
                if (point)
                    return false;
                return next.All(n => n == null);
            }
        }

        internal static int IndexOfChar(char c)
        {
            if (BaseNode.RusAlphabet.Contains(c))
                return BaseNode.RusAlphabetStr.IndexOf(c);
            throw new Exception();
        }

        protected static char IndexToChar(int index)
        {
            if (index > 0 && index < BaseNode.RusAlphabetStr.Length)
                return RusAlphabetStr[index];
            throw new Exception();
        }

        public BaseNode()
        {

        }

        public static bool CheckWord(string word)
        {
            return word != "" && word.All(c => BaseNode.RusAlphabet.Contains(c));
        }

        public void ForEachWord(DoForEachWord operation, string currentWord)
        {
            if (point)
                operation(currentWord);
            for (int i = 0; i < next.Length; i++)
            {
                if (next[i])
                    next[i].ForEachWord(operation, currentWord + IndexToChar(i));
            }
        }

        public virtual bool AddWord(ref string word)
        {
            throw new NotImplementedException();
        }

        public virtual bool Find(ref string word)
        {
            throw new NotImplementedException();
        }

        public virtual BaseNode FindStart(ref string word)
        {
            throw new NotImplementedException();
        }

        public virtual bool Delete(ref string word)
        {
            throw new NotImplementedException();
        }
    }

    public class BaseTrieTree
    {
        protected BaseNode _root;
        protected bool _modified;
        protected string _currentFilename;

        public delegate void OnModifiedSettingTrue();
        public OnModifiedSettingTrue onModifiedTrue = null;

        public BaseTrieTree(OnModifiedSettingTrue onModifiedSettingTrue = null)
        {
            _modified = false;
            _currentFilename = "";
            onModifiedTrue = onModifiedSettingTrue;
        }

        public string currentFilename
        {
            get { return _currentFilename; }
        }

        public bool modified
        {
            get { return _modified; }
            protected set
            {
                if (value && onModifiedTrue != null)
                    onModifiedTrue();
                _modified = value;

            }
        }

        public static implicit operator bool(BaseTrieTree t)
        {
            return t != null;
        }

        public bool IsEmpty
        {
            get { return _root == null; }
        }

        public void Clear()
        {
            if (!IsEmpty)
                modified = true;
            _root = null;
            _currentFilename = "";
        }

        public bool Find(string word)
        {
            return _root && BaseNode.CheckWord(word) && _root.Find(ref word);
        }

        public bool Delete(string word)
        {
            bool result = _root && BaseNode.CheckWord(word) && _root.Delete(ref word);

            if (result && _root.IsEmpty)
                Clear();
            if (result)
                modified = true;
            return result;
        }

        public void ForEachWord(DoForEachWord operation)
        {
            if (_root)
                _root.ForEachWord(operation, "");
        }


        public virtual void AddWord(string word)
        {
            throw new NotImplementedException();
        }

        public virtual BaseNode FindStart(ref string word)
        {
            throw new NotImplementedException();
        }

        public virtual void SaveToFile(string filename)
        {
            throw new NotImplementedException();
        }

        public bool LoadFromFile(string filename)
        {
            try
            {
                string contents = File.ReadAllText(filename);
                Clear();
                foreach (string s in contents.Split('\0', '\n', '\r'))
                    if (s != "") AddWord(s);
                _currentFilename = filename;
                modified = false;
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }

    }
}
