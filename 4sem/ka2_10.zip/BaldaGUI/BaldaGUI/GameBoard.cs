﻿using BaldaGUI.Trees;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaldaGUI
{
    /// <summary>
    /// класс ячейки таблицы
    /// </summary>
    public class Cell
    {
        public char Letter { get; internal set; }
        public bool IsVisited { get; internal set; }

        public Cell() : this('\0', false) { }
        public Cell(char letter) : this(letter, false) { }

        public Cell(char letter, bool isVisited)
        {
            Letter = letter;
            IsVisited = isVisited;
        }

        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if (!(obj is Cell)) return false;
            return ((Cell)obj).Letter == Letter && ((Cell)obj).IsVisited == IsVisited;
        }

        /*
        public override int GetHashCode()
        {
            return (Letter + 1) * (Letter + 2) + (IsVisited ? 1 : 0);
        }
        */

        public bool IsEmpty()
        {
            return Letter == '\0';
        }

    }

    /// <summary>
    /// координаты на таблице
    /// </summary>
    public class Position
    {
        public const int MAX = 10;
        public int I { get; private set; }
        public int J { get; private set; }
        public Position(int i, int j)
        {
            I = i;
            J = j;
        }
        public override int GetHashCode()
        {
            return MAX * I + J;
        }

        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if (!(obj is Position)) return false;
            return I == ((Position)obj).I && J == ((Position)obj).J;
        }

        public override string ToString()
        {
            return "(" + I + ", " + J + ")";
        }

        public Position Up
        {
            get { return new Position(I - 1, J); }
        }

        public Position Down
        {
            get { return new Position(I + 1, J); }
        }

        public Position Left
        {
            get { return new Position(I, J - 1); }
        }

        public Position Right
        {
            get { return new Position(I, J + 1); }
        }

    }

    /*
    static class HashExtensions
    {
        public static int TrueHash(this HashSet<Position> set)
        {
            int P = 1;
            int Pi = 11;
            int res = 0;
            foreach (Position p in set)
            {
                res = p.GetHashCode() * (P = P * Pi);
            }
            return res;
        }
    }
    */

    public class GameBoard
    {

        public int Size { get; private set; }
        public Cell[,] Field { get; private set; }

        public GameBoard(int size)
        {
            Field = new Cell[size, size];
            for (int i = 0; i < Field.GetLength(0); ++i)
            {
                for (int j = 0; j < Field.GetLength(1); ++j)
                {
                    Field[i, j] = new Cell();
                }
            }
            Size = size;
        }

        public GameBoard(int size, string word) : this(size)
        {
            if (word != "")
            {
                for (int i = 0; i < size; ++i)
                {
                    Field[size / 2, i] = new Cell(word[i % word.Length]);
                }
            }
        }

        public string CenterWord
        {
            get
            {
                string centerWord = "";
                for (int i = 0; i < Size; ++i)
                {
                    centerWord += Field[Size / 2, i].Letter;
                }
                return centerWord;
            }
        }

        public override string ToString()
        {
            string res = "";
            for(int i = 0; i < Field.GetLength(0); ++i)
            {
                for(int j = 0; j < Field.GetLength(1); ++j)
                {
                    res += Field[i, j].Letter + "/" + (Field[i, j].IsVisited ? "T" : "F") + " ";
                }
                res += Environment.NewLine;
            }
            return res;
        }
        
        public GameBoard(string word) : this(word.Length, word) { }

        public Cell this[Position index]
        {
            get { return Field[index.I, index.J]; }
            set { Field[index.I, index.J] = value; }
        }


        /// <summary>
        /// проверяет, что позиция находится в границах поля
        /// </summary>
        private bool InBounds(Position position)
        {
            return position.I >= 0 && position.J >= 0 && position.I < Size && position.J < Size;
        }

        /// <summary>
        /// проверяет смежную позицию
        /// </summary>
        private bool CheckСontiguous(Position position)
        {
            return InBounds(position) && this[position].IsEmpty();
        }

        /// <summary>
        /// проверяет, что я могу добавить букву на этой позиции в проверяемое слово
        /// </summary>
        private bool CheckNotVisited(Position position)
        {
            return InBounds(position) && !this[position].IsEmpty() && !this[position].IsVisited;
        }
        
        /// <summary>
        /// метод получает все смежные позиции
        /// </summary>
        public HashSet<Position> Contiguous
        {
            get
            {
                HashSet<Position> contiguous = new HashSet<Position>();
                for (int i = 0; i < Size; ++i)
                {
                    for (int j = 0; j < Size; ++j)
                    {
                        Position position = new Position(i, j);
                        if (!this[position].IsEmpty())
                        {
                            if (CheckСontiguous(position.Up)) contiguous.Add(position.Up);
                            if (CheckСontiguous(position.Down)) contiguous.Add(position.Down);
                            if (CheckСontiguous(position.Left)) contiguous.Add(position.Left);
                            if (CheckСontiguous(position.Right)) contiguous.Add(position.Right);
                        }
                    }
                }
                return contiguous;
            }
        }

        /// <summary>
        /// проверяет, что переданный суффикс существует в дереве
        /// </summary>
        private bool CheckTail(ref string word, PostfTrieTree postfTrie)
        {
            return postfTrie.FindStart(ref word) != null;
        }

        /// <summary>
        /// проверяет, что всё слово существует в дереве
        /// </summary>
        private bool CheckWholeWord(ref string word, PrefTrieTree prefTrie)
        {
            return prefTrie.Find(word);
        }

        /// <summary>
        /// метод ищет начало слова
        /// </summary>
        /// <param name="curr">текущая позиция</param>
        /// <param name="prefTrie">префиксное трай-дерево</param>
        /// <param name="words">таблица всех слов, полученных во всех играх</param>
        /// <param name="usedWords">текущее звено в игре</param>
        /// <param name="word">текущее слово</param>
        /// <param name="isFounded">нашел слово или нет</param>
        private void SearchStart(Position start, Position curr, PrefTrieTree prefTrie, HashSet<string> words, GameTreeNode usedWords, ref string word, ref bool isFounded)
        {
            word = this[curr].Letter + word;
            this[curr].IsVisited = true;
            if(CheckWholeWord(ref word, prefTrie))
            {
                if (!usedWords.Contains(word))
                {
                    words.Add(word);
                    usedWords.AddChild(word, this[start].Letter, start);
                    isFounded = true;
                }
            }

            if (CheckNotVisited(curr.Up))
                SearchStart(start, curr.Up, prefTrie, words, usedWords, ref word, ref isFounded);
            if (CheckNotVisited(curr.Down))
                SearchStart(start, curr.Down, prefTrie, words, usedWords, ref word, ref isFounded);
            if (CheckNotVisited(curr.Left))
                SearchStart(start, curr.Left, prefTrie, words, usedWords, ref word, ref isFounded);
            if (CheckNotVisited(curr.Right))
                SearchStart(start, curr.Right, prefTrie, words, usedWords, ref word, ref isFounded);

            this[curr].IsVisited = false;
            word = word.Substring(1, word.Length - 1);
        }

        /// <summary>
        /// метод ищет конец слова, запускает поиск начала
        /// </summary>
        /// <param name="start">позиция, на которую добавили букву</param>
        /// <param name="curr">текущая позиция</param>
        /// <param name="prefTrie">префиксное трай-дерево</param>
        /// <param name="postfTrie">постфиксное трай-дерево</param>
        /// <param name="words">таблица всех слов, полученных во всех играх</param>
        /// <param name="usedWords">текущее звено в игре</param>
        /// <param name="word">текущее слово</param>
        /// <param name="isFounded">нашел слово или нет</param>
        private void SearchWords(Position start, Position curr, PrefTrieTree prefTrie, PostfTrieTree postfTrie, HashSet<string> words, GameTreeNode usedWords, ref string word, ref bool isFounded)
        {
            word += this[curr].Letter;
            this[curr].IsVisited = true;
            if(CheckTail(ref word, postfTrie))
            {
                //в обратную сторону
                if (CheckNotVisited(start.Up))
                    SearchStart(start, start.Up, prefTrie, words, usedWords, ref word, ref isFounded);
                if (CheckNotVisited(start.Down))
                    SearchStart(start, start.Down, prefTrie, words, usedWords, ref word, ref isFounded);
                if (CheckNotVisited(start.Left))
                    SearchStart(start, start.Left, prefTrie, words, usedWords, ref word, ref isFounded);
                if (CheckNotVisited(start.Right))
                    SearchStart(start, start.Right, prefTrie, words, usedWords, ref word, ref isFounded);             
            }

            if (CheckNotVisited(curr.Up))
                SearchWords(start, curr.Up, prefTrie, postfTrie, words, usedWords, ref word, ref isFounded);
            if (CheckNotVisited(curr.Down))
                SearchWords(start, curr.Down, prefTrie, postfTrie, words, usedWords, ref word, ref isFounded);
            if (CheckNotVisited(curr.Left))
                SearchWords(start, curr.Left, prefTrie, postfTrie, words, usedWords, ref word, ref isFounded);
            if (CheckNotVisited(curr.Right))
                SearchWords(start, curr.Right, prefTrie, postfTrie, words, usedWords, ref word, ref isFounded);

            this[curr].IsVisited = false;
            word = word.Substring(0, word.Length - 1);

        }

        /// <summary>
        /// метод, запускающий поиск
        /// </summary>
        /// <param name="k">количество ходов</param>
        /// <param name="prefTrie">префиксное трай-дерево</param>
        /// <param name="postfTrie">постфиксное трай-дерево</param>
        /// <param name="words">таблица всех слов, полученных во всех играх</param>
        /// <param name="progress">количество перебранных вариантов</param>
        /// <param name="total">количество всех вариантов</param>
        public void StartSearch(int k, PrefTrieTree prefTrie, PostfTrieTree postfTrie, HashSet<string> words, out int progress, out int total)
        {
            string centerWord = CenterWord;
            GameTreeNode usedWords = new GameTreeNode(centerWord, null, centerWord[0], new Position(Size / 2, 0));
            progress = 0;
            total = 0;
            if(k > Size * Size - Size)
            {
                k = Size * Size - Size;
            }
            GetWords(k, words, usedWords, prefTrie, postfTrie, ref progress, ref total);
        }
        
        public void GetWords(int k, HashSet<string> words, GameTreeNode startNode, PrefTrieTree prefTrie, PostfTrieTree postfTrie, ref int progress, ref int total)
        {
            Queue<GameTreeNode> queue = new Queue<GameTreeNode>();
            queue.Enqueue(startNode);
            while(queue.Count != 0)
            {
                k--;
                total++;
                GameTreeNode gameNode = queue.Dequeue();

                gameNode.FillBoard(this);
                var contiguous = Contiguous;
                foreach (var p in contiguous)
                {
                    foreach (char c in BaseNode.RusAlphabetStr)
                    {
                        this[p].Letter = c;
                        string word = "";
                        bool isFounded = false;
                        SearchWords(p, p, prefTrie, postfTrie, words, gameNode, ref word, ref isFounded);
                        if (k > 0 && isFounded)
                        {
                            foreach(var child in gameNode.children)
                            {
                                queue.Enqueue(child);
                            }
                        }
                    }
                    this[p].Letter = '\0';
                }

                gameNode.ClearBoard(this);
                progress++;
            }
        }
    }
}
