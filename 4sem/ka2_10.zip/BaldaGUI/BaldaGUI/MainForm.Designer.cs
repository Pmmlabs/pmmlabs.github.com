﻿namespace BaldaGUI
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gameGrid = new System.Windows.Forms.DataGridView();
            this.sizeTrackBar = new System.Windows.Forms.TrackBar();
            this.lbCount = new System.Windows.Forms.Label();
            this.tbWord = new System.Windows.Forms.TextBox();
            this.btWord = new System.Windows.Forms.Button();
            this.lbWords = new System.Windows.Forms.ListBox();
            this.lbWord = new System.Windows.Forms.Label();
            this.labelSteps = new System.Windows.Forms.Label();
            this.btSteps = new System.Windows.Forms.Button();
            this.tbSteps = new System.Windows.Forms.TextBox();
            this.openTrieFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btAbort = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gameGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sizeTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // gameGrid
            // 
            this.gameGrid.AllowUserToAddRows = false;
            this.gameGrid.AllowUserToDeleteRows = false;
            this.gameGrid.AllowUserToResizeColumns = false;
            this.gameGrid.AllowUserToResizeRows = false;
            this.gameGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gameGrid.ColumnHeadersVisible = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gameGrid.DefaultCellStyle = dataGridViewCellStyle1;
            this.gameGrid.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.gameGrid.Enabled = false;
            this.gameGrid.Location = new System.Drawing.Point(12, 12);
            this.gameGrid.Name = "gameGrid";
            this.gameGrid.ReadOnly = true;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gameGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gameGrid.RowHeadersVisible = false;
            this.gameGrid.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.gameGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.gameGrid.Size = new System.Drawing.Size(350, 350);
            this.gameGrid.TabIndex = 10;
            // 
            // sizeTrackBar
            // 
            this.sizeTrackBar.Location = new System.Drawing.Point(12, 368);
            this.sizeTrackBar.Maximum = 4;
            this.sizeTrackBar.Minimum = 1;
            this.sizeTrackBar.Name = "sizeTrackBar";
            this.sizeTrackBar.Size = new System.Drawing.Size(331, 45);
            this.sizeTrackBar.TabIndex = 1;
            this.sizeTrackBar.Value = 2;
            this.sizeTrackBar.ValueChanged += new System.EventHandler(this.sizeTrackBar_ValueChanged);
            // 
            // lbCount
            // 
            this.lbCount.AutoSize = true;
            this.lbCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbCount.Location = new System.Drawing.Point(346, 368);
            this.lbCount.Name = "lbCount";
            this.lbCount.Size = new System.Drawing.Size(16, 17);
            this.lbCount.TabIndex = 2;
            this.lbCount.Text = "5";
            // 
            // tbWord
            // 
            this.tbWord.Location = new System.Drawing.Point(77, 399);
            this.tbWord.Name = "tbWord";
            this.tbWord.Size = new System.Drawing.Size(79, 20);
            this.tbWord.TabIndex = 3;
            this.tbWord.TextChanged += new System.EventHandler(this.tbWord_TextChanged);
            this.tbWord.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbWord_KeyPress);
            // 
            // btWord
            // 
            this.btWord.Location = new System.Drawing.Point(162, 399);
            this.btWord.Name = "btWord";
            this.btWord.Size = new System.Drawing.Size(37, 23);
            this.btWord.TabIndex = 4;
            this.btWord.Text = "OK";
            this.btWord.UseVisualStyleBackColor = true;
            this.btWord.Click += new System.EventHandler(this.btWord_Click);
            // 
            // lbWords
            // 
            this.lbWords.FormattingEnabled = true;
            this.lbWords.Location = new System.Drawing.Point(368, 12);
            this.lbWords.Name = "lbWords";
            this.lbWords.Size = new System.Drawing.Size(204, 381);
            this.lbWords.TabIndex = 8;
            // 
            // lbWord
            // 
            this.lbWord.AutoSize = true;
            this.lbWord.Location = new System.Drawing.Point(34, 404);
            this.lbWord.Name = "lbWord";
            this.lbWord.Size = new System.Drawing.Size(41, 13);
            this.lbWord.TabIndex = 2;
            this.lbWord.Text = "Слово:";
            // 
            // labelSteps
            // 
            this.labelSteps.AutoSize = true;
            this.labelSteps.Location = new System.Drawing.Point(205, 402);
            this.labelSteps.Name = "labelSteps";
            this.labelSteps.Size = new System.Drawing.Size(42, 13);
            this.labelSteps.TabIndex = 5;
            this.labelSteps.Text = "Шагов:";
            // 
            // btSteps
            // 
            this.btSteps.Location = new System.Drawing.Point(296, 399);
            this.btSteps.Name = "btSteps";
            this.btSteps.Size = new System.Drawing.Size(56, 23);
            this.btSteps.TabIndex = 7;
            this.btSteps.Text = "Решить";
            this.btSteps.UseVisualStyleBackColor = true;
            this.btSteps.Click += new System.EventHandler(this.btSteps_Click);
            // 
            // tbSteps
            // 
            this.tbSteps.Location = new System.Drawing.Point(253, 399);
            this.tbSteps.Name = "tbSteps";
            this.tbSteps.Size = new System.Drawing.Size(37, 20);
            this.tbSteps.TabIndex = 6;
            this.tbSteps.TextChanged += new System.EventHandler(this.tbSteps_TextChanged);
            this.tbSteps.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSteps_KeyPress);
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(368, 399);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(134, 23);
            this.progressBar.TabIndex = 9;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::BaldaGUI.Properties.Resources.help;
            this.pictureBox1.Location = new System.Drawing.Point(12, 403);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(16, 16);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btAbort
            // 
            this.btAbort.Enabled = false;
            this.btAbort.Location = new System.Drawing.Point(508, 399);
            this.btAbort.Name = "btAbort";
            this.btAbort.Size = new System.Drawing.Size(64, 23);
            this.btAbort.TabIndex = 12;
            this.btAbort.Text = "Прервать";
            this.btAbort.UseVisualStyleBackColor = true;
            this.btAbort.Click += new System.EventHandler(this.btAbort_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 431);
            this.Controls.Add(this.btAbort);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.labelSteps);
            this.Controls.Add(this.btSteps);
            this.Controls.Add(this.tbSteps);
            this.Controls.Add(this.lbWord);
            this.Controls.Add(this.lbWords);
            this.Controls.Add(this.btWord);
            this.Controls.Add(this.tbWord);
            this.Controls.Add(this.lbCount);
            this.Controls.Add(this.sizeTrackBar);
            this.Controls.Add(this.gameGrid);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "Балда";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.gameGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sizeTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView gameGrid;
        private System.Windows.Forms.TrackBar sizeTrackBar;
        private System.Windows.Forms.Label lbCount;
        private System.Windows.Forms.TextBox tbWord;
        private System.Windows.Forms.Button btWord;
        private System.Windows.Forms.ListBox lbWords;
        private System.Windows.Forms.Label lbWord;
        private System.Windows.Forms.Label labelSteps;
        private System.Windows.Forms.Button btSteps;
        private System.Windows.Forms.TextBox tbSteps;
        private System.Windows.Forms.OpenFileDialog openTrieFileDialog;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btAbort;
    }
}

