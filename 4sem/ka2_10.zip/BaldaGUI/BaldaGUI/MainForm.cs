﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;


//Леденев, 3 курс, 9 группа
//Поиск в ширину для игры «Балда». Все слова, которые можно получить через k-ходов.
namespace BaldaGUI
{
    public partial class MainForm : Form
    {
        GameBoard gb;
        int trackValue = 5;
        int steps;
        bool loaded;
        bool performing;
        PrefTrieTree prefTrie;
        PostfTrieTree postfTrie;
        int progress;
        int total;
        HashSet<string> words;
        Thread th;

        public MainForm()
        {
            loaded = false;
            performing = false;
            InitializeComponent();
            Application.Idle += OnIdle;
            gb = new GameBoard(5);
            CreateGrid();
        }

        private void CreateGrid()
        {
            gameGrid.Columns.Clear();
            DataGridViewColumn column;
            for (int i = 0; i < gb.Size; ++i)
            {
                column = new DataGridViewTextBoxColumn();
                column.ReadOnly = true;
                column.DataPropertyName = i.ToString();
                column.Name = i.ToString();
                column.Width = gameGrid.Width / gb.Size;
                gameGrid.Columns.Add(column);
            }
            
            DataGridViewRow row = new DataGridViewRow();
            row.Height = gameGrid.Width / gb.Size;
            gameGrid.RowTemplate = row;

            for (int i = 0; i < gb.Size; ++i)
            {
                gameGrid.Rows.Add();
            }

            for (int i = 0; i < gb.Size; ++i)
            {
                for (int j = 0; j < gb.Size; ++j)
                {
                    gameGrid[j, i].Value = gb.Field[i, j].Letter;
                }
            }
        }


        public void OnIdle(object sender, EventArgs e)
        {
            lbCount.Text = trackValue.ToString();

            progressBar.Maximum = total;
            try
            {
                progressBar.Value = progress;
            }
            catch { }

            if (th != null && th.IsAlive)
            {
                btSteps.Enabled = false;
                btAbort.Enabled = true;
                performing = true;
            }
            else
            {
                btSteps.Enabled = gb.CenterWord != "" && tbSteps.Text.Length != 0;
            }
            if(th != null && !th.IsAlive && performing)
            {
                performing = false;
                if (th.ThreadState != ThreadState.Aborted)
                {
                    if (words.Count != 0)
                    {
                        foreach (string s in words)
                        {
                            lbWords.Items.Add(s);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Слов не найдено!", "Конец", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                else
                {
                    btAbort.Enabled = false;
                    words = new HashSet<string>();
                }
                btSteps.Enabled = true;
                btAbort.Enabled = false;
            }
        }

        private void sizeTrackBar_ValueChanged(object sender, EventArgs e)
        {
            trackValue = sizeTrackBar.Value * 2 + 1;
            gb = new GameBoard(trackValue, tbWord.Text);
            CreateGrid();
        }

        private void btWord_Click(object sender, EventArgs e)
        {
            if (tbWord.Text != "")
            {
                gb = new GameBoard(trackValue, tbWord.Text);
                CreateGrid();
            }
        }

        private void tbSteps_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) && tbSteps.Text.Length < 2 ||
                                  e.KeyChar == 8 && tbSteps.Text.Length <= 2))
                e.Handled = true;
        }

        private void tbSteps_TextChanged(object sender, EventArgs e)
        {
            if (tbSteps.Text.Length != 0 && (!int.TryParse(tbSteps.Text, out steps) || tbSteps.Text.Length > 1))
            {
                try
                {
                    tbSteps.Text = tbSteps.Text.Remove(tbSteps.Text.IndexOf(Clipboard.GetText()), Clipboard.GetText().Length);
                }
                catch { }
            }
        }

        private void btSteps_Click(object sender, EventArgs e)
        {
            lbWords.Items.Clear();
            int k = Convert.ToInt32(tbSteps.Text);
            prefTrie = prefTrie ?? new PrefTrieTree();
            postfTrie = postfTrie ?? new PostfTrieTree();
            if (!loaded && (!prefTrie.LoadFromFile("word_rus.txt") & !postfTrie.LoadFromFile("word_rus.txt")))
            {
                while (openTrieFileDialog.FileName == "")
                {
                    if (MessageBox.Show("Словарь не был загружен. Найдите словарь вручную!",
                                    "Предупреждение!", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) != DialogResult.Cancel)
                    {
                        openTrieFileDialog.ShowDialog();
                        loaded = false;
                    }
                }
                prefTrie.LoadFromFile(openTrieFileDialog.FileName);
                postfTrie.LoadFromFile(openTrieFileDialog.FileName);
            }
            loaded = true;
            words = new HashSet<string>();
            gb = new GameBoard(trackValue, tbWord.Text);
            th = new Thread(() => gb.StartSearch(k, prefTrie, postfTrie, words, out progress, out total));
            th.Start();
        }

        private void tbWord_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(BaseNode.RusAlphabet.Contains(Char.ToLower(e.KeyChar)))
            {
                e.KeyChar = Char.ToLower(e.KeyChar);
            }

            if(!BaseNode.RusAlphabet.Contains(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbWord_TextChanged(object sender, EventArgs e)
        {
            foreach(char c in tbWord.Text)
            {
                if(!BaseNode.RusAlphabet.Contains(c))
                {
                    tbSteps.Text = tbSteps.Text.Remove(tbSteps.Text.IndexOf(Clipboard.GetText()), Clipboard.GetText().Length);
                }
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (th != null)
                th.Abort();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Поиск в ширину для игры «Балда». Все слова, которые можно получить через k-ходов.", "Условие задачи", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void btAbort_Click(object sender, EventArgs e)
        {
            th.Abort();
        }
    }
}
