﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication1

{
    public partial class Form1 : Form
    {
        const string SPACE = " ";
        private string fileName = string.Empty;

        public Form1()
        {
            InitializeComponent();
            textBoxIn.Text = "";
            textBoxOut.Text = "";
            Application.Idle += new EventHandler(Application.Idle);
        }
        private void Application_Idle(Object sender, EventArgs e)
        {
            textBoxOut.Visible = (textBoxOut.Text != "");
            saveToolStripMenuItem.Enabled = (textBoxIn.Text != "");
            saveAsToolStripMenuItem.Enabled = (textBoxIn.Text != "");
            runToolStripMenuItem.Enabled = (textBoxIn.Text != "");
            saveResultAsToolStripMenuItem.Enabled = (textBoxOut.Text != "");
            clearToolStripMenuItem.Enabled = (textBoxOut.Text != "");
        }
        public bool entry(string line, string word)
        {
            int i = 0;
            string subline;
            bool res = false;
            while ((line.Length > 0) && (res == false))
            {
                i = line.IndexOf(SPACE);
                if (i < 0)
                {
                    subline = line;
                    line = "";
                }
                else
                {
                    subline = line.Substring(0, i);
                    line = line.Substring(i + 1);
                    line.Trim();
                }
                res = subline.Equals(word, StringComparison.OrdinalIgnoreCase);
            }
            return res;
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fileName == "")
            {
                if (openFileDlg.ShowDialog() == DialogResult.OK)
                {
                    StreamReader stR = new StreamReader(openFileDlg.FileName);
                    fileName = openFileDlg.FileName;
                    textBoxIn.Text = stR.ReadToEnd();
                    stR.Close();
                }
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fileName == "")
            {
                if (saveFileDlg.ShowDialog() == DialogResult.OK)
                {
                    fileName = saveFileDlg.FileName;
                    StreamWriter stW = new StreamWriter(fileName, true, Encoding.GetEncoding(1251));
                    stW.WriteLine(textBoxIn.Text);
                    stW.Close();
                }
            }
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDlg = new SaveFileDialog();
            saveFileDlg.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            if (saveFileDlg.ShowDialog() == DialogResult.OK)
            {
                StreamWriter stWr = new StreamWriter(saveFileDlg.FileName, false, Encoding.GetEncoding(1251));
                stWr.WriteLine(textBoxIn.Text);
                stWr.Close();
            }
        }

        private void runToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //string line = "";
            //string setWrd = "";
            label.Visible = true;
            textBoxWrd.Visible = true;
            buttonOK.Visible = true;
            /*setWrd = textBoxWrd.Text;
            textBoxOut.Clear();
            int k=0;
            for (int i = 0; i < textBoxIn.Lines.Count(); i++)
            {
                line=textBoxIn.Lines[i];
                if (entry(line,setWrd))
                {
                    textBoxOut.Lines[k] = line;
                    k++;
                }
            }*/
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            string setWrd = "";
            string[] input = textBoxIn.Lines;
            string[] output = new string [textBoxIn.Lines.Count()];
            setWrd = textBoxWrd.Text;
            textBoxOut.Text="";
            int k = 0;
            foreach (string line in input)
            {
                if (entry(line, setWrd))
                {
                    output[k] = line;
                    k++;
                }
            }
            textBoxOut.Lines = output;
        }

        private void saveResultAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDlg = new SaveFileDialog();
            saveFileDlg.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            if (saveFileDlg.ShowDialog() == DialogResult.OK)
            {
                StreamWriter stWr = new StreamWriter(saveFileDlg.FileName, false, Encoding.GetEncoding(1251));
                stWr.Write(textBoxOut.Text);
                stWr.Close();
            }
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBoxOut.Text = string.Empty;
            label.Visible = false;
            textBoxWrd.Text = "";
            textBoxWrd.Visible = false;
            buttonOK.Visible = false;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        const string TASK = "Дан текстовый файл. Создать новый файл, состоящий из тех строк файла, которые содержат заданное слово.";
        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            toolTipHelp.Show(TASK, labelTmp, 5000);
        }

    }
}
