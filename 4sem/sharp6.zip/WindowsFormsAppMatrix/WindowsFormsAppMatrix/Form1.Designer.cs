﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.matrixToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearAllStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutTaskToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTipHelp = new System.Windows.Forms.ToolTip(this.components);
            this.labelTmp = new System.Windows.Forms.Label();
            this.dataGridViewIn = new System.Windows.Forms.DataGridView();
            this.dataGridViewOut = new System.Windows.Forms.DataGridView();
            this.labelSize = new System.Windows.Forms.Label();
            this.textBoxSize = new System.Windows.Forms.TextBox();
            this.labeValue = new System.Windows.Forms.Label();
            this.textBoxValue = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOut)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.matrixToolStripMenuItem,
            this.projectToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(440, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // matrixToolStripMenuItem
            // 
            this.matrixToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inputToolStripMenuItem});
            this.matrixToolStripMenuItem.Name = "matrixToolStripMenuItem";
            this.matrixToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.matrixToolStripMenuItem.Text = "Matrix";
            // 
            // inputToolStripMenuItem
            // 
            this.inputToolStripMenuItem.Name = "inputToolStripMenuItem";
            this.inputToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.inputToolStripMenuItem.Text = "Input...";
            this.inputToolStripMenuItem.Click += new System.EventHandler(this.inputToolStripMenuItem_Click);
            // 
            // projectToolStripMenuItem
            // 
            this.projectToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.runToolStripMenuItem,
            this.clearAllStripMenuItem,
            this.toolStripMenuItem2,
            this.exitToolStripMenuItem});
            this.projectToolStripMenuItem.Name = "projectToolStripMenuItem";
            this.projectToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.projectToolStripMenuItem.Text = "Project";
            // 
            // runToolStripMenuItem
            // 
            this.runToolStripMenuItem.Name = "runToolStripMenuItem";
            this.runToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.runToolStripMenuItem.Text = "Run";
            this.runToolStripMenuItem.Click += new System.EventHandler(this.runToolStripMenuItem_Click);
            // 
            // clearAllStripMenuItem
            // 
            this.clearAllStripMenuItem.Name = "clearAllStripMenuItem";
            this.clearAllStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.clearAllStripMenuItem.Text = "Clear All";
            this.clearAllStripMenuItem.Click += new System.EventHandler(this.clearAllStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(118, 22);
            this.toolStripMenuItem2.Text = "...";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutTaskToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutTaskToolStripMenuItem
            // 
            this.aboutTaskToolStripMenuItem.Name = "aboutTaskToolStripMenuItem";
            this.aboutTaskToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.aboutTaskToolStripMenuItem.Text = "About Task";
            this.aboutTaskToolStripMenuItem.Click += new System.EventHandler(this.aboutTaskToolStripMenuItem_Click);
            // 
            // labelTmp
            // 
            this.labelTmp.AutoSize = true;
            this.labelTmp.Location = new System.Drawing.Point(81, 33);
            this.labelTmp.Name = "labelTmp";
            this.labelTmp.Size = new System.Drawing.Size(0, 13);
            this.labelTmp.TabIndex = 1;
            // 
            // dataGridViewIn
            // 
            this.dataGridViewIn.AllowUserToOrderColumns = true;
            this.dataGridViewIn.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dataGridViewIn.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewIn.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewIn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewIn.Location = new System.Drawing.Point(21, 77);
            this.dataGridViewIn.Name = "dataGridViewIn";
            this.dataGridViewIn.RowHeadersWidth = 35;
            this.dataGridViewIn.Size = new System.Drawing.Size(200, 200);
            this.dataGridViewIn.StandardTab = true;
            this.dataGridViewIn.TabIndex = 2;
            this.dataGridViewIn.Visible = false;
            // 
            // dataGridViewOut
            // 
            this.dataGridViewOut.AllowUserToOrderColumns = true;
            this.dataGridViewOut.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewOut.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewOut.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewOut.Location = new System.Drawing.Point(216, 77);
            this.dataGridViewOut.Name = "dataGridViewOut";
            this.dataGridViewOut.RowHeadersWidth = 35;
            this.dataGridViewOut.Size = new System.Drawing.Size(200, 200);
            this.dataGridViewOut.TabIndex = 3;
            this.dataGridViewOut.Visible = false;
            // 
            // labelSize
            // 
            this.labelSize.AutoSize = true;
            this.labelSize.Location = new System.Drawing.Point(87, 44);
            this.labelSize.Name = "labelSize";
            this.labelSize.Size = new System.Drawing.Size(141, 13);
            this.labelSize.TabIndex = 4;
            this.labelSize.Text = "Задайте размер матрицы:";
            this.labelSize.Visible = false;
            // 
            // textBoxSize
            // 
            this.textBoxSize.Location = new System.Drawing.Point(234, 41);
            this.textBoxSize.Name = "textBoxSize";
            this.textBoxSize.Size = new System.Drawing.Size(35, 20);
            this.textBoxSize.TabIndex = 5;
            this.textBoxSize.Visible = false;
            this.textBoxSize.TextChanged += new System.EventHandler(this.textBoxSize_TextChanged);
            // 
            // labeValue
            // 
            this.labeValue.AutoSize = true;
            this.labeValue.Location = new System.Drawing.Point(87, 44);
            this.labeValue.Name = "labeValue";
            this.labeValue.Size = new System.Drawing.Size(102, 13);
            this.labeValue.TabIndex = 7;
            this.labeValue.Text = "Задайте значение:";
            this.labeValue.Visible = false;
            // 
            // textBoxValue
            // 
            this.textBoxValue.Location = new System.Drawing.Point(234, 41);
            this.textBoxValue.Name = "textBoxValue";
            this.textBoxValue.Size = new System.Drawing.Size(35, 20);
            this.textBoxValue.TabIndex = 8;
            this.textBoxValue.Visible = false;
            this.textBoxValue.TextChanged += new System.EventHandler(this.textBoxValue_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(440, 301);
            this.Controls.Add(this.textBoxValue);
            this.Controls.Add(this.labeValue);
            this.Controls.Add(this.textBoxSize);
            this.Controls.Add(this.labelSize);
            this.Controls.Add(this.dataGridViewOut);
            this.Controls.Add(this.dataGridViewIn);
            this.Controls.Add(this.labelTmp);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Matrix";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOut)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem projectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem runToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearAllStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTipHelp;
        private System.Windows.Forms.Label labelTmp;
        private System.Windows.Forms.ToolStripMenuItem aboutTaskToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem matrixToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inputToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridViewIn;
        private System.Windows.Forms.DataGridView dataGridViewOut;
        private System.Windows.Forms.Label labelSize;
        private System.Windows.Forms.TextBox textBoxSize;
        private System.Windows.Forms.Label labeValue;
        private System.Windows.Forms.TextBox textBoxValue;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
    }
}

