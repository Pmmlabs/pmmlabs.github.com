﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        const string TASK = "Удвоить строки, содержащие заданное значение.";
        int size=0;
        int value = 0;
        private void aboutTaskToolStripMenuItem_Click(object sender, EventArgs e)
        {
            toolTipHelp.Show(TASK, labelTmp, 5000);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBoxSize_TextChanged(object sender, EventArgs e)
        {
            int i;
            size = Int32.Parse(textBoxSize.Text);
            DataTable matr = new DataTable("matr");
            DataColumn[] cols = new DataColumn[size];

            for (i = 0; i < size; i++)
            {
                cols[i] = new DataColumn(i.ToString());
                matr.Columns.Add(cols[i]);
            }

            for (i = 0; i < size; i++)
            {
                DataRow newRow;
                newRow = matr.NewRow();
                matr.Rows.Add(newRow);
            }
            dataGridViewIn.DataSource = matr;
            for (i = 0; i < size; i++)
                dataGridViewIn.Columns[i].Width = 40;
            dataGridViewIn.Visible = true;
            dataGridViewIn.Focus();
        }

        private void textBoxValue_TextChanged(object sender, EventArgs e)
        {
            value = Int32.Parse(textBoxValue.Text);
            makeMatrix m = new makeMatrix(size);
            m.GridToMatrix(dataGridViewIn);
            m.DoubleStr(value);
            dataGridViewOut.Visible = true;
            m.MatrixToGrid(dataGridViewOut);
        }

        private void runToolStripMenuItem_Click(object sender, EventArgs e)
        {
            labelSize.Visible = false;
            textBoxSize.Visible = false;
            labeValue.Visible = true;
            textBoxValue.Visible = true;
            textBoxValue.Focus();
        }

        private void clearAllStripMenuItem_Click(object sender, EventArgs e)
        {
            labeValue.Visible =false;
            textBoxValue.Visible = false;
            dataGridViewIn.Visible = false;
            dataGridViewOut.Visible = false;
            labelSize.Visible = false;
            textBoxSize.Visible = false;
        }

        private void inputToolStripMenuItem_Click(object sender, EventArgs e)
        {
            labelSize.Visible = true;
            textBoxSize.Visible = true;
            textBoxSize.Focus();
        }


    }
}
