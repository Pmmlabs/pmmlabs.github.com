﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;

namespace WindowsFormsApplication1
{
    class makeMatrix
    {
        int nStr, 
            nCol;
        int[,] matrix;

        public makeMatrix(int n)
        {
            nStr = n;
            nCol = n;
            matrix = new int[n, n];
        }
        public void GridToMatrix(DataGridView dgv)
        {
            DataGridViewCell txtCell;
            for (int i = 0; i < nStr; i++)
            {
                for (int j = 0; j < nCol; j++)
                {
                    txtCell = dgv.Rows[i].Cells[j];
                    string s = txtCell.Value.ToString();
                    if (s == "")
                        matrix[i, j] = 0;
                    else
                        matrix[i, j] = Int32.Parse(s);
                }
            }
        }
        public void MatrixToGrid(DataGridView dgv)
        {
            int i;
            DataTable matr = new DataTable("matr");
            DataColumn[] cols = new DataColumn[nCol];
            for (i = 0; i < nCol; i++)
            {
                cols[i] = new DataColumn(i.ToString());
                matr.Columns.Add(cols[i]);
            }
            for (i = 0; i < nStr; i++)
            {
                DataRow newRow;
                newRow = matr.NewRow();
                matr.Rows.Add(newRow);
            }
            dgv.DataSource = matr;
            for (i = 0; i < nCol; i++)
                dgv.Columns[i].Width = 40;
            DataGridViewCell txtCell;
            for (i = 0; i < nStr; i++)
            {
                for (int j = 0; j < nCol; j++)
                {
                    txtCell = dgv.Rows[i].Cells[j];
                    txtCell.Value = matrix[i, j].ToString();
                }
            }
        }
        public void DoubleStr(int val)
        {
            int i, j;
            bool ok;
            i = 0;
            int[,] m;
            while (i < nStr)
            {
                ok = true;
                j = 0;
                while (j < nCol && ok)
                {
                    if (matrix[i, j] == val)
                        ok = false;
                    j++;
                }
                if (!ok)
                {
                    nStr++;
                    m = new int[nStr, nCol];
                    for (int p = 0; p < nStr; p++)
                        for (int q = 0; q < nCol; q++)
                        {
                            if (p <= i)
                                m[p, q] = matrix[p, q];
                            else
                                m[p, q] = matrix[p-1, q];
                        }
                    matrix = new int[nStr, nCol];
                    matrix = m;
                    i++;
                }
                i++;
            }
        }
    }
}
