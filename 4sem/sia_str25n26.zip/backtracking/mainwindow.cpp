#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    lab = new Labirint(5, 5, ui->labirintTableWidget);
   /* lab->loadFromFile("input.txt");
    lab->setStart(Point(2, 1));
    lab->setFinish(Point(4, 6));
    lab->solve(Point(2, 1), 1);
    lab->drawWay(0);
    */
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_labirintTableWidget_cellClicked(int row, int column) {
    lab->printToTable();
    ui->waysListWidget->clear();
    lab->clearWays();

    if (ui->rbStart->isChecked()) {
        if (ui->labirintTableWidget->item(row, column)->backgroundColor() != Qt::black) {
            //clear old state
            ui->labirintTableWidget->item(lab->getStart().y, lab->getStart().x)->setText(" ");
            Point newStart = Point(column, row);
            //set new state
            lab->setStart(newStart);
            ui->labirintTableWidget->item(newStart.y, newStart.x)->setText("S");
        }
        return;
    }
    if (ui->rbFinish->isChecked()) {
        if (ui->labirintTableWidget->item(row, column)->backgroundColor() != Qt::black) {
            //clear old state
            ui->labirintTableWidget->item(lab->getFinish().y, lab->getFinish().x)->setText(" ");
            Point newFinish = Point(column, row);
            //set new state
            lab->setFinish(newFinish);
            ui->labirintTableWidget->item(newFinish.y, newFinish.x)->setText("F");
        }
        return;
    }
    if (ui->rbWall->isChecked() && Point(column, row) != lab->getStart() && Point(column, row) != lab->getFinish()) {
        ui->labirintTableWidget->item(row, column)->setBackgroundColor(Qt::black);

        lab->loadFromTable();
        return;
    }
    if (ui->rbNone->isChecked() && Point(column, row) != lab->getStart() && Point(column, row) != lab->getFinish()) {
        ui->labirintTableWidget->item(row, column)->setBackgroundColor(Qt::white);

        lab->loadFromTable();
        return;
    }
}

void MainWindow::on_actionGenerate_triggered() {
    ui->waysListWidget->clear();
    lab->clearWays();
    lab->generate();
    ui->statusBar->showMessage("Labirint " + QString::number(lab->getH()) +
                               "x" + QString::number(lab->getW()) + " was generated");
}

void MainWindow::on_actionSolve_triggered() {
    ui->waysListWidget->clear();
    lab->clearWays();
    Way tmp;
    tmp.push_back(lab->getStart());
    lab->solve(lab->getStart(), 1, tmp);
    int numberOfWays = lab->getNumberOfWays();
    ui->statusBar->showMessage("Found " + QString::number(numberOfWays) + " ways");
    lab->printListOfWays(ui->waysListWidget);
}



void MainWindow::on_waysListWidget_itemClicked(QListWidgetItem *item) {
    lab->printToTable();
    lab->drawWay(ui->waysListWidget->currentRow());
}

void MainWindow::on_actionClear_way_triggered() {
    lab->printToTable();
}

void MainWindow::on_actionLoad_from_file_triggered() {
    string filename = "";
    QString fname = QFileDialog::getOpenFileName(this, "Open file", "", "Textfile (*.txt);;All Files (*)");
    if (fname != "") {
        ui->waysListWidget->clear();
        lab->clearWays();
        filename = fname.toStdString();
        delete lab;

        lab = new Labirint(1, 1, ui->labirintTableWidget);
        lab->loadFromFile(filename);

        lab->printToTable();

        ui->statusBar->showMessage("Labirint was load from file");
    } else
        ui->statusBar->showMessage("Labirint wasn't load from file");
}

void MainWindow::on_waysListWidget_doubleClicked(const QModelIndex &index) {

}

void MainWindow::on_waysListWidget_itemDoubleClicked(QListWidgetItem *item) {

}
