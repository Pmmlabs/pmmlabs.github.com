#include "labirint.h"

void Labirint::initTable(){
    table->setRowCount(height+2);
    table->setColumnCount(width+2);

    for (int i = 0; i < height+2; i++)
        for (int j = 0; j < width+2; j++)
            table->setItem(i, j, new QTableWidgetItem(" "));
}

void Labirint::addWay() {
    int step = 1;
    Way currWay;
    Point curr = start;
    currWay.push_back(curr);
    while (curr != finish) {
        step++;
        for (int i = 0; i < 4; i++) {
            if (grid[curr.y + dy[i]][curr.x + dx[i]].step == step) {
                curr.y += dy[i];
                curr.x += dx[i];
                currWay.push_back(curr);
                break;
            }
        } //for
    } //while
    ways.push_back(currWay); //finish вроде
}

Labirint::Labirint() {
    width = 1;
    height = 1;
    table = NULL;
    start = Point(0, 0);
    finish = Point(0, 0);
}

void Labirint::setBorders() {
    //set the borders
    for (int i = 0; i < height+2; i++) {
        grid[i][0].val = WALL;
        grid[i][0].step = 0;
        grid[i][width+2 - 1].val = WALL;
        grid[i][width+2 - 1].step = 0;
    }
    for (int j = 0; j < width+2; j++) {
        grid[0][j].val = WALL;
        grid[0][j].step = 0;
        grid[height+2 - 1][j].val = WALL;
        grid[height+2 - 1][j].step = 0;
    }
}

Labirint::Labirint(int _height, int _width, QTableWidget *_table) {
    height = _height;
    width = _width;
    start = Point(0, 0);
    finish = Point(0, 0);

    table = _table;
    this->initTable();
    this->setBorders();
}

int Labirint::getH() {
    return height;
}

int Labirint::getW() {
    return width;
}

void Labirint::setStart(Point _start) {
    start = _start;
}

void Labirint::setFinish(Point _finish) {
    finish = _finish;
}

Point Labirint::getStart() {
    return start;
}

Point Labirint::getFinish() {
    return finish;
}

void Labirint::loadFromFile(string fname) {
    fstream fin(fname.c_str());
    fin >> height >> width;
    for (int i = 1; i <= height; i++)
        for (int j = 1; j <= width; j++) {
            fin >> grid[i][j].val;
            grid[i][j].step = 0;
        }
    this->printToTable();
}

void Labirint::loadFromTable() {
    for (int i = 0; i < height+2; i++)
        for (int j = 0; j < width+2; j++) {
            QColor cl = table->item(i, j)->backgroundColor();
            if (cl == Qt::black) {
                grid[i][j].val = WALL;
            } else
                if (cl == Qt::white) {
                    grid[i][j].val = BLANK;
                }
        }
}

void Labirint::printToTable() {
    table->clear();
    this->initTable();
    this->setBorders();
    for (int i = 0; i < height+2; i++) {
        for (int j = 0; j < width+2; j++) {
            if (grid[i][j].val == WALL)
                table->item(i, j)->setBackground(Qt::black);
            else
                table->item(i, j)->setBackground(Qt::white);
        }
    }
    table->item(start.y, start.x)->setText("S");
    table->item(finish.y, finish.x)->setText("F");
}

void Labirint::generate() {
    //ofstream fout("input3.txt");
    int newH, newW;
    do {
        newH = rand() % 11;
        newW = rand() % 11;
    } while ((newH < 5 || newH > 11) && (newW < 3 || newW > 11));
    //fout << newH << " " << newW << " ";
    height = newH;
    width = newW;
    start = Point(0, 0);
    finish = Point(0, 0);

    //table->clear();
    //this->initTable();

    for (int i = 1; i <= height; i++) {
        for (int j = 1; j <= width; j++) {
            int tmp;
            do {
                tmp = rand() % 3;
            } while (tmp == 0);
            grid[i][j].val = -1 * tmp;
            grid[i][j].step = 0;
            //fout << grid[i][j].val << " ";

        }
    }
    this->printToTable();

}

int Labirint::getNumberOfWays() {
    return ways.size();
}

void Labirint::solve(Point p, int k, Way& currWay) {
    //помечаем клетку текущим шагом
    grid[p.y][p.x].step = k;
    if (p == finish)
        ways.push_back(currWay);
    else {
        for (int i = 0; i < 4; i++)
            //если есть проход и там еще не были, то идем туда
            if (grid[p.y + dy[i]][p.x + dx[i]].val == BLANK &&
                    grid[p.y + dy[i]][p.x + dx[i]].step == 0) {
                currWay.push_back(Point(p.x+dx[i], p.y+dy[i]));
                solve(Point(p.x + dx[i], p.y + dy[i]), k+1, currWay);
                currWay.resize(currWay.size()-1);
            }
    }
    grid[p.y][p.x].step = 0;
}

void Labirint::drawWay(int way) {
    int j = 0;
    for (int i = 0; i < ways[way].size(); i++) {
        //ways[way][i].x

        table->item(ways[way][i].y, ways[way][i].x)->setBackgroundColor(Qt::green);
        table->item(ways[way][i].y, ways[way][i].x)->setText(QString::number(j++));
    }
    table->item(ways[way][0].y, ways[way][0].x)->setText("S");
    table->item(ways[way][ways[way].size()-1].y, ways[way][ways[way].size()-1].x)->setText("F");
}

void Labirint::printListOfWays(QListWidget *qlw) {
    for (int i = 0; i < ways.size(); i++)
        qlw->addItem(QString::number(i+1) + ". L: " + QString::number(ways[i].size()));
}

void Labirint::clearWays() {
    ways.clear();
}


bool Point::operator ==(const Point &a) const {
    return (this->x == a.x && this->y == a.y);
}

bool Point::operator !=(const Point &a) const {
    return (this->x != a.x || this->y != a.y);
}



