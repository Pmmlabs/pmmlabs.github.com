#ifndef LABIRINT_H
#define LABIRINT_H

#include <vector>
#include <string>
#include <fstream>
#include <QTableWidget>
#include <QListWidget>

using namespace std;

const int WALL   = -1;         // непроходимая ячейка
const int BLANK  = -2;         // свободная непомеченная ячейка

const int MAX_SIZE = 30;

struct Point {
    int x;
    int y;
    Point() {}
    Point(int _x, int _y) : x(_x), y(_y) {}       //constructor
    bool operator== (const Point& a) const;
    bool operator!= (const Point& a) const;
};

struct Cell {
    int val;
    int step;
};

typedef vector<Point> Way;
typedef vector<Way> Ways;



class Labirint {
private:
    int width; // ширина рабочего поля
    int height; // высота рабочего поля
    Ways ways; //все пути

    Cell grid[MAX_SIZE+2][MAX_SIZE+2]; //рабочее поле
    Point start;
    Point finish;

    QTableWidget* table;
    void initTable();

    void addWay();

    void setBorders();

    //Way currentWay;

    const int dx[4] = {1, 0, -1, 0};   // смещения, соответствующие соседям ячейки
    const int dy[4] = {0, 1, 0, -1};   // справа, снизу, слева и сверху
public:
    Labirint();
    Labirint(int _height, int _width, QTableWidget* _table);

    int getW();
    int getH();

    void setStart(Point _start);
    void setFinish(Point _finish);

    Point getStart();
    Point getFinish();

    void loadFromFile(string fname);
    void loadFromTable();
    void printToTable();

    void generate();

    int getNumberOfWays();

    void solve(Point p, int k, Way &currWay);

    void drawWay(int way);

    void printListOfWays(QListWidget* qlw);

    void clearWays();

};

#endif // LABIRINT_H
