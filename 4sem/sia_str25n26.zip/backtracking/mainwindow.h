#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFileDialog>
#include "labirint.h"

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    
private slots:
    void on_labirintTableWidget_cellClicked(int row, int column);

    void on_actionGenerate_triggered();

    void on_actionSolve_triggered();

    void on_waysListWidget_itemDoubleClicked(QListWidgetItem *item);

    void on_waysListWidget_itemClicked(QListWidgetItem *item);

    void on_actionClear_way_triggered();

    void on_actionLoad_from_file_triggered();

    void on_waysListWidget_doubleClicked(const QModelIndex &index);

private:
    Ui::MainWindow *ui;
    Labirint* lab;
};

#endif // MAINWINDOW_H
