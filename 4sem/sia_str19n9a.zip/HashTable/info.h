#ifndef INFO_H
#define INFO_H

#include "key.h"
#include <fstream>
#include <sstream>
#include <QTableWidget>

const int MAX_TESTS = 7;
const int MAX_EXAMS = 5;
const int MARK_TO_FIND = 2;

class Info {
private:
    Key studentNumber;
    string studentName;
    string tests; //format 0010101 where 1 is passed test
    string exams; //format 44253 where exams[i] is mark for i-th exam

public:
    Info();
    Info(Key& aStudentNumber, string& aStudentName, string& aTests, string& aExams);

    Key& getStudentNumber();
    string& getStudentName();
    string& getTests();
    string& getExams();
    //void setStudentName(string aStudentName);
    //void setInfoKey(Key aKey); //for future functionality
    //void setTests(Tests& aTests);
    //void setExams(Exams& aExams);

    string toString();

    void saveToFile(ofstream& fout);
    bool loadFromFile(string tmp); //parse with tryStringToInfo

    void showToGrid(QTableWidget* grid, int row);

    static bool isGoodInput(string inp, int size);
    static bool tryStringToInfo(string input, Info& outputInfo);

};

#endif // INFO_H
