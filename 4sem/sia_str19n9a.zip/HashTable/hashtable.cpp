#include "hashtable.h"

HashTable::HashTable() {
    table.resize(TABLE_SIZE+1);
    count = 0;
    for (int i = 1; i <= TABLE_SIZE; i++) {
        table[i].info = NULL;
        table[i].next = 0;
    }
}

HashTable::~HashTable() {
    clear();
}

void HashTable::clear() {
    if (count > 0) {
        for (int i = 1; i <= TABLE_SIZE; i++) {
            delete table[i].info;
            table[i].info = NULL;
            table[i].next = 0;
        }
        count = 0;
    }
}

int HashTable::hashFunc(Key aKey) {
    return abs(aKey.hashFunc()) % TABLE_SIZE + 1;
}

int HashTable::getIndex(Key aKey, int &p) {
    p = 0;
    int res = hashFunc(aKey);
    int first = res;
    bool ok = false;
    while (!ok && res != 0) {
        if (table[res].info != NULL && table[res].info->getStudentNumber() == aKey)
            ok = true;
        else {
            p = res;
            res = abs(table[res].next);
        }
    } //while

    if (!ok)
        if (table[first].next < 0)
            p = first;
    return res;
}

bool HashTable::add(Info aInfo) {
    bool res = true;
    if (count == TABLE_SIZE)
        res = false;
    else {
        int a, pa;
        a = getIndex(aInfo.getStudentNumber(), pa);
        if (a > 0)
            res = false;
        else {
            count++;
            if (table[pa].info == NULL) {
                table[pa].info = new Info;
                *(table[pa].info) = aInfo;
                table[pa].next = abs(table[pa].next);
            } else {
                a = pa;
                do {
                    a = a % TABLE_SIZE + 1;
                } while (table[a].info != NULL);
                table[a].info = new Info;
                *(table[a].info) = aInfo;
                table[pa].next = a;
            }
        } //else a>0
    } //else count
    return res;
}

bool HashTable::del(Key aKey) {
    bool res;
    if (count > 0) {
        int a, pa;
        a = getIndex(aKey, pa);
        res = a > 0;
        if (res) {
            delete table[a].info;
            table[a].info = NULL;
            count--;
            if (pa == 0)
                table[a].next = -table[a].next;
            else
                table[pa].next = table[a].next;
        } //if res
    } else
        res = false;
    return res;
}

bool HashTable::find(Key aKey, Info &outputInfo) {
    bool res;
    int a, pa;
    a = getIndex(aKey, pa);
    res = a > 0;
    if (res)
        outputInfo = *(table[a].info);
    return res;
}

int HashTable::getCount() const {
    return count;
}

void HashTable::saveToFile(string fname) {
    ofstream fout(fname.c_str());
    if (count > 0)
        for (int i = 1; i <= TABLE_SIZE; i++)
            if (table[i].info != NULL)
                table[i].info->saveToFile(fout);
    fout.close();
}

bool HashTable::loadFromFile(string fname) {
    ifstream fin(fname.c_str());
    bool res = true;
    clear();
    string tmp;
    while(getline(fin, tmp)) {
        Info tmpInfo;
        res = res && tmpInfo.loadFromFile(tmp) && add(tmpInfo);

    }
    fin.close();
    return res;
}

bool HashTable::isEmpty() {
    return count == 0;
}

void HashTable::showToGrid(QTableWidget *grid) {
    if (count == 0) {
        grid->setRowCount(1);
        grid->clear();
    } else
        grid->setRowCount(count);
    int j = 0;
    for (int i = 1; i <= TABLE_SIZE; i++)
        if (table[i].info != NULL) {
            table[i].info->showToGrid(grid, j);
            j++;
        }


}
