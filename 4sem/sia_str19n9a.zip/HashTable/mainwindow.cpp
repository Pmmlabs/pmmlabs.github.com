#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    table = new GuiHashTable(ui->tableWidget);
    updateUi();
}

MainWindow::~MainWindow()
{
    if (table != NULL)
        delete table;
    delete ui;
}

void MainWindow::updateUi() {
    //зависят от наличия хеш-таблицы
    ui->actionSave->setEnabled(table != NULL);
    ui->actionSave_as->setEnabled(table != NULL);

    

    //изменение при добавлении/удалении
    ui->actionDel->setEnabled(table != NULL && !table->isEmpty());
    ui->actionAdd->setEnabled(table != NULL);
    ui->actionClear->setEnabled(table != NULL && !table->isEmpty());

    //зависят от количества элементов в таблице
    ui->actionFind->setEnabled(table != NULL && !table->isEmpty());
}

void MainWindow::closeTable() {
    bool canClose = true;
    if (table->isModified()) {
        int ans = QMessageBox::question(this, "Save edited table", "Save table?", QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
        switch (ans) {
        case QMessageBox::Yes:
            ui->actionSave->triggered(true);
            canClose = !table->isModified();
            break;
        case QMessageBox::No:
            break;
        case QMessageBox::Cancel:
            canClose = false;
            break;
        }
    }
    if (canClose) {
        table->clear();
        delete table;
        table = NULL;
        updateUi();
        ui->statusBar->showMessage("Table was closed");
    }
}

void MainWindow::resizeEvent(QResizeEvent *event){
    int nw = this->width() - 15;
    int nh = this->geometry().height() - this->statusBar()->height() - 50;

    ui->tableWidget->resize(nw, nh);


}

void MainWindow::on_actionNew_triggered() {
    if (table != NULL)
        closeTable();
    //если закроылось удачно
    if (table == NULL) {
        table = new GuiHashTable(ui->tableWidget);

        ui->statusBar->showMessage("New hash table was created");
    }

    updateUi();
}

void MainWindow::on_actionOpen_triggered() {
    QString fname = QFileDialog::getOpenFileName(this, "Open file", "", "Textfile (*.txt);;All Files (*)");
    if (fname != "") {
        if (table != NULL)
            closeTable();
        //если закрылось удачно
        if (table == NULL) {
            table = new GuiHashTable(ui->tableWidget);
            //!!!!!!
            if (table->loadFromFile(fname.toStdString()))
                ui->statusBar->showMessage("Loaded " + QString::number(table->getCount()) + " items");
            else
                QMessageBox::critical(this, "Error", "Some items wasn't loaded");

        }
        updateUi();
    }
}

void MainWindow::on_actionSave_triggered() {

    string fname = table->getFilename();
    if (fname != "") {
        table->saveToFile(fname);
        ui->statusBar->showMessage("Table was saved to " + QString::fromStdString(fname));
    } else
        ui->actionSave_as->triggered(true);
}

void MainWindow::on_actionSave_as_triggered() {
    string name = table->getFilename();
    ///!!!
    QString fname = QFileDialog::getSaveFileName(this, "Save table to file", QString::fromStdString(name), "Textfile (*.txt);;All Files (*)");
    if (fname != "") {
        table->saveToFile(fname.toStdString());
        ui->statusBar->showMessage("Table was saved to " + fname);
    }
}

void MainWindow::on_actionExit_triggered() {
    if (table != NULL)
        closeTable();
    if (table == NULL)
        MainWindow::closeEvent(0);
}

void MainWindow::GetDialogOutput() {
    bool result;
    Info* info = new Info;
    myDialog->getOptions(*info);
    table->add(*info);
}

void MainWindow::on_actionAdd_triggered() {
    bool mbOK;

    Dialog dialog2(this);

    Info info;

    if (dialog2.exec() == QDialog::Accepted) {

        dialog2.getOptions(info);
        if (table->addInfo(info))
            ui->statusBar->showMessage("Item added");
        else
            ui->statusBar->showMessage("Item wasn't added");
    }
    updateUi();

}

void MainWindow::on_actionDel_triggered() {
    bool mbOK;
    QString str = QInputDialog::getText(this, "Delete by student number", "Enter student number", QLineEdit::Normal, "", &mbOK);
    if (mbOK) {
        if (Key::isCorrectKey(str.toStdString())) {
            if (table->delInfo(str.toStdString())) {
                //очищаем поле результата и убираем кнопочки
                updateUi();
                ui->statusBar->showMessage("Item was deleted");
            } else
                QMessageBox::critical(this, "Error", "Item wasn't deleted");
        } else
            QMessageBox::critical(this, "Error", "Number is incorrect");
    }
}

void MainWindow::on_actionClear_triggered() {
    int ans = QMessageBox::critical(this, "Clear table", "Are you sure?", "Yes", "No");
    if (ans == 0) {
        table->clear();
        updateUi();

        ui->statusBar->showMessage("Table was cleared");
    }
}


void MainWindow::on_actionFind_triggered() {
    bool mbOK;
    QString str = QInputDialog::getText(this, "Search by number", "Enter number", QLineEdit::Normal, "", &mbOK);
    bool goodKey = Key::isCorrectKey(str.toStdString());
    if (mbOK) {
        if (goodKey) {
            Info result;
            bool goodSearch = table->find(str.toStdString(), result);
            if (goodSearch) {
                Dialog dialog2(this);
                dialog2.setReadOnly();
                dialog2.showData(result);
                dialog2.exec();
                //ui->statusBar->showMessage("Item was found");
            } else
                QMessageBox::critical(this, "Error", "Item wasn't found");
        } else
            QMessageBox::critical(this, "Error", "Key is incorrect");
    }
}
void MainWindow::on_actionAbout_triggered() {
    QMessageBox::about(this, "Hash", "(c) Якунцев Никита, 2 к. МОиАИС, 2014");
}
