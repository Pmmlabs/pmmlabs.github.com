#include "dialog.h"
#include "ui_dialog.h"


Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    connect(ui->cancelButton, SIGNAL(clicked()), SLOT(reject()));

    for (int i = 0; i < MAX_TESTS; i++)
        ui->testsTable->setItem(0, i, new QTableWidgetItem(" "));
    for (int i = 0; i < MAX_EXAMS; i++)
        ui->examsWidget->setItem(0, i, new QTableWidgetItem(" "));
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_cancelButton_clicked() {

}

void Dialog::on_addInfoButton_clicked() {
    bool ok = true;

    if (!Key::isCorrectKey(ui->numberEdit->text().toStdString())) {
        ui->numberEdit->clear();
        ui->numberEdit->setFocus();
        QMessageBox::critical(this, "Error", "Wrong key: only " + QString::number(KEY_LENGTH) + " digits!");
        return;
    }
    if (ui->nameEdit->text().trimmed() == "" || !ui->nameEdit->text().contains(" ")) {
        ui->nameEdit->clear();
        ui->nameEdit->setFocus();
        QMessageBox::critical(this, "Error", "Wrong name: Format: name + space + surname");
        return;
    }

    string testsStr = "";
    for (int i = 0; i < MAX_TESTS; i++)
        testsStr += ui->testsTable->item(0, i)->text().toStdString();
    if (!Info::isGoodInput(testsStr, MAX_TESTS)) {
        ui->testsTable->clear();
        ui->testsTable->setFocus();
        QMessageBox::critical(this, "Error", "Wrong data: only 1 or 0 available");
        return;
    }

    string examsStr = "";
    for (int i = 0; i < MAX_EXAMS; i++)
        examsStr += ui->examsWidget->item(0, i)->text().toStdString();
    if (!Info::isGoodInput(examsStr, MAX_EXAMS)) {
        ui->examsWidget->clear();
        ui->examsWidget->setFocus();
        QMessageBox::critical(this, "Error", "Wrong data: only 2 to 5 available");
        return;
    }

    if (ok) {
        string str = ui->numberEdit->text().toStdString() + " " +
                ui->nameEdit->text().toStdString() + " " +
                testsStr + " " +
                examsStr;
        Info::tryStringToInfo(str, tmpInfo);
        accept();
    }
}

void Dialog::getOptions(Info &outInfo) {
    outInfo = tmpInfo;
}

void Dialog::setReadOnly() {
    ui->addInfoButton->setVisible(false);
    ui->cancelButton->setText("Close");
    ui->nameEdit->setReadOnly(true);
    ui->numberEdit->setReadOnly(true);
    ui->testsTable->setEnabled(false);
    ui->examsWidget->setEnabled(false);
}

void Dialog::showData(Info &inInfo) {
    this->setWindowTitle(QString::fromStdString("Student " + inInfo.getStudentNumber().getKey()));
    ui->numberEdit->setText(QString::fromStdString(inInfo.getStudentNumber().getKey()));
    ui->nameEdit->setText(QString::fromStdString(inInfo.getStudentName()));

    int failedTests = 0;
    for (int i = 0; i < MAX_TESTS; i++) {
        QTableWidgetItem* it = ui->testsTable->takeItem(0, i);
        it->setText(QString::fromLocal8Bit(&inInfo.getTests()[i], 1));
        ui->testsTable->setItem(0, i, it);
        if (inInfo.getTests()[i] == '0')
            failedTests++;
    }

    for (int i = 0; i < MAX_EXAMS; i++) {
        QTableWidgetItem* it = ui->examsWidget->takeItem(0, i);
        it->setText(QString::fromLocal8Bit(&inInfo.getExams()[i], 1));
        ui->examsWidget->setItem(0, i, it);
        if (inInfo.getExams()[i] == '2')
            failedTests++;
    }
    ui->failsLabel->setText(QString::number(failedTests) + " failed items");
}
