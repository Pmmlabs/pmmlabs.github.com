#ifndef HASHTABLE_H
#define HASHTABLE_H

#include <vector>
#include "info.h"

//#define NULL 0;

const int TABLE_SIZE = 101;

struct Cell {
    Info* info;
    int next;
};

typedef vector <Cell> Table;

class HashTable {
private:
    Table table;
    int count;
protected:
    int hashFunc(Key aKey);
    int getIndex(Key aKey, int& p);
public:
    HashTable();
    ~HashTable();
    virtual void clear();
    bool add(Info aInfo);
    bool find(Key aKey, Info& outputInfo);
    bool del(Key aKey);
    bool isEmpty();
    int getCount() const;
    virtual void saveToFile(string fname);
    virtual bool loadFromFile(string fname);
    ///TODO
    void showToGrid(QTableWidget* grid);
};

#endif // HASHTABLE_H
