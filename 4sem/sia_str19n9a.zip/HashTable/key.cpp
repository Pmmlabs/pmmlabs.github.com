#include "key.h"

Key::Key() {
    key = "";
}

Key::Key(string aKey) {
    key = aKey;
}

string Key::getKey() const {
    return key;
}

bool Key::operator== (const Key& a) const {
    return this->key == a.getKey();
}

bool Key::operator!= (const Key& a) const {
    return this->key != a.getKey();
}

bool Key::isCorrectKey(string aKey) {
    bool res = aKey.length() == KEY_LENGTH;
    if (res) {
        for (unsigned int i = 0; i < aKey.length() && res; i++) {
            if (!isdigit(aKey[i]))
                res = false;
        }
    }
    return res;
}

int Key::hashFunc() {
        int nHash = 0;
        string tmpKey = key;
        for (unsigned int i = 0; i < tmpKey.length(); i++)
            nHash = (nHash<<5) + nHash + tmpKey[i];
        return abs(nHash);
}
