#include "info.h"
#include <vector>

Info::Info() {
    studentName = "";
    //studentNumber inits in default Key constructor
    for (int i = 0; i < MAX_TESTS; i++)
        tests.push_back('0');
    for (int i = 0; i < MAX_EXAMS; i++)
        exams.push_back('0');
}

Info::Info(Key& aStudentNumber, string& aStudentName, string& aTests, string& aExams) {
    studentNumber = aStudentNumber;
    studentName = aStudentName;
    tests = aTests;
    exams = aExams;
}

Key& Info::getStudentNumber() {
    return studentNumber;
}

string& Info::getStudentName() {
    return studentName;
}

string& Info::getTests() {
    return tests;
}

string& Info::getExams() {
    return exams;
}

string Info::toString() {
    string res = "";
    res  = studentNumber.getKey() + "\t" +
            studentName + "\t" +
            tests + "\t" +
            exams + "\t";
    return res;
}

bool Info::tryStringToInfo(string input, Info &outputInfo) {
    bool res = !input.empty();
    //split the input string
    vector <string> vecStr;
    if (res) {
        //put all words to vecStr (Split analog)
        stringstream ss(input);
        string tmpString;
        while(ss >> tmpString) {
           vecStr.push_back(tmpString);
        }

        //vecStr.push_back();
        res = vecStr.size() == 5;
    }
    //check words length
    if (res) {
        
        res = Key::isCorrectKey(vecStr[0]) &&
                Info::isGoodInput(vecStr[3], MAX_TESTS) &&
                Info::isGoodInput(vecStr[4], MAX_EXAMS);
              //vecStr[3].length() == MAX_TESTS &&
              //vecStr[4].length() == MAX_EXAMS;
    }
    //if everything is ok
    if (res) {
        outputInfo.studentNumber = vecStr[0];
        outputInfo.studentName = vecStr[1] + " " + vecStr[2];
        outputInfo.tests = vecStr[3];
        outputInfo.exams = vecStr[4];
    }
    return res;
}

void Info::saveToFile(ofstream &fout) {
    fout << this->toString() << endl;
}

bool Info::loadFromFile(string tmp) { //ifstream &fin) {
    //string tmp;
    //fin >> tmp;
    //getline(fin, tmp);
    return tryStringToInfo(tmp, *this);
}

void Info::showToGrid(QTableWidget *grid, int row) {
    grid->setItem(row, 0, new QTableWidgetItem(QString::fromStdString(studentNumber.getKey())));
    grid->setItem(row, 1, new QTableWidgetItem(QString::fromStdString(studentName)));
    grid->setItem(row, 2, new QTableWidgetItem(QString::fromStdString(tests)));
    grid->setItem(row, 3, new QTableWidgetItem(QString::fromStdString(exams)));
}

bool Info::isGoodInput(string inp, int size) {
    bool res = inp.length() == size;
    for (int i = 0; i < inp.length() && res; i++)
        if (!isdigit(inp[i]))
            res = false;
        else
            if (size == MAX_TESTS) {
                if (inp[i] != '1' && inp[i] != '0')
                    res = false;

            } else
                if (inp[i] < '2' || inp[i] > '5')
                    res = false;
    return res;
}

