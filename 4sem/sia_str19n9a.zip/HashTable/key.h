#ifndef KEY_H
#define KEY_H

#include <string>
#include <cstdlib>
#include <cmath>

using namespace std;

const int KEY_LENGTH = 7;

class Key {
private:
    string key;
public:
    Key();
    Key(string aKey);

    string getKey() const;
    bool operator== (const Key& a) const;
    bool operator!= (const Key& a) const;
    static bool isCorrectKey(string aKey);
    int hashFunc();
};

#endif // KEY_H
