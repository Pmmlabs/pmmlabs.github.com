#include "guihashtable.h"

GuiHashTable::GuiHashTable() {
    grid = NULL;
    filename = "";
    modified = false;
}

GuiHashTable::GuiHashTable(QTableWidget *aGrid) {
    grid = aGrid;
    filename = "";
    modified = false;
    aGrid->setHorizontalHeaderLabels(QStringList() << "Number" << "Name" << "Tests" << "Exams");
}

void GuiHashTable::clear() {
    if (!isEmpty()) {
        HashTable::clear();
        setModified(true);
    }
}

bool GuiHashTable::addInfo(Info aInfo) {
    bool res = add(aInfo);
    if (res)
        setModified(true);
    return res;
}

bool GuiHashTable::delInfo(Key aKey) {
    bool res = del(aKey);
    if (res)
       setModified(true);
    return res;
}

bool GuiHashTable::loadFromFile(string fname) {
    bool res = HashTable::loadFromFile(fname);
    filename = fname;
    //if (res)
        //setModified(false);
    //если произошли ошибки во время добавления, не отобразится инфа
    modified = false;
    showToGrid(grid);
    return res;
}

void GuiHashTable::saveToFile(string fname) {
    HashTable::saveToFile(fname);
    filename = fname;
    modified = false;
}

void GuiHashTable::setModified(bool b) {
    modified = b;
    showToGrid(grid);
}

bool GuiHashTable::isModified() {
    return modified;
}

string GuiHashTable::getFilename() {
    return filename;
}
