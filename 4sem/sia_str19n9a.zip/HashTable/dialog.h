#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include "info.h"
#include <QMessageBox>
#include <QString>

namespace Ui {
    class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit Dialog(QWidget *parent = 0);
    void getOptions(Info &outInfo);
    void setReadOnly();
    void showData(Info &inInfo);
    ~Dialog();
    
private slots:
    void on_cancelButton_clicked();

    void on_addInfoButton_clicked();

private:
    Ui::Dialog *ui;
    Info tmpInfo;
};

#endif // DIALOG_H
