#ifndef GUIHASHTABLE_H
#define GUIHASHTABLE_H

#include "hashtable.h"

class GuiHashTable : public HashTable {
private:
    QTableWidget* grid;
    string filename;
    bool modified;
    void setModified(bool b);
public:
    GuiHashTable();
    GuiHashTable(QTableWidget* aGrid);

    void clear();
    bool addInfo(Info aInfo);
    bool delInfo(Key aKey);
    bool loadFromFile(string fname);
    void saveToFile(string fname);
    bool isModified();
    string getFilename();
};

#endif // GUIHASHTABLE_H
