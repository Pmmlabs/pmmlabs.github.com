#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "guihashtable.h"
#include <QResizeEvent>
#include <QMessageBox>
#include <QFileDialog>
#include <QInputDialog>

#include "dialog.h"

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    GuiHashTable* table;
    void closeTable();
    ~MainWindow();

protected:
    void resizeEvent(QResizeEvent *event);

public slots:
    void GetDialogOutput();
    
private slots:
    void on_actionNew_triggered();

    void on_actionOpen_triggered();

    void on_actionSave_triggered();

    void on_actionSave_as_triggered();

    void on_actionExit_triggered();

    void on_actionAdd_triggered();

    void on_actionDel_triggered();

    void on_actionClear_triggered();

    void on_actionFind_triggered();

    void on_actionAbout_triggered();

private:
    Ui::MainWindow *ui;
    Dialog* myDialog;
    void updateUi();
};

#endif // MAINWINDOW_H
