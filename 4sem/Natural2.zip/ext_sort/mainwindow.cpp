#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    fl = new File();
    configureUi();
    connect(ui->actionProcess, SIGNAL(triggered()), this, SLOT(process()));
}

void MainWindow::configureUi() {
    ui->twCompare->clear();
    ui->twRead->clear();
    ui->twTime->clear();
    ui->twCycle->clear();

    ui->twCompare->setHorizontalHeaderLabels(QStringList() << "File Size" << "Random File" << "Reverse File");
    ui->twRead->setHorizontalHeaderLabels(QStringList() << "File Size" << "Random File" << "Reverse File");
    ui->twTime->setHorizontalHeaderLabels(QStringList() << "File Size" << "Random File" << "Reverse File");
    ui->twCycle->setHorizontalHeaderLabels(QStringList() << "File Size" << "Random File" << "Reverse File");

    ui->twCycle->setGeometry(ui->twTime->geometry());

    ui->twTime->horizontalHeader()->setDefaultSectionSize(ui->tabWidget->width() / ui->twTime->columnCount());
    ui->twCompare->horizontalHeader()->setDefaultSectionSize(ui->tabWidget->width() / ui->twTime->columnCount());
    ui->twRead->horizontalHeader()->setDefaultSectionSize(ui->tabWidget->width() / ui->twTime->columnCount());
    ui->twCycle->horizontalHeader()->setDefaultSectionSize(ui->tabWidget->width() / ui->twTime->columnCount());
}

void MainWindow::process() {
    const int SIZE = 8;
    int sizes[SIZE] = {10, 100, 500, 1000, 10000, 50000, 100000, 1000000};
    //const int SIZE = 1;
    //int sizes[SIZE];
    ///TODO Input to sizes[0]
    ///
    int tmp = QInputDialog::getInt(this, "Input num of tests", "Input num of tests", 1, 1, SIZE);
    if (tmp == 1) {
        sizes[0] = QInputDialog::getInt(this, "Input num of elements", "Input num of elements", 10, 1, 1000000);
    }
    int maxSize = tmp;

    configureUi();

    ui->twCompare->setRowCount(maxSize);
    ui->twRead->setRowCount(maxSize);
    ui->twTime->setRowCount(maxSize);
    ui->twCycle->setRowCount(maxSize);

//    ui->twCompare->setUpdatesEnabled(true);
//    ui->twRead->setUpdatesEnabled(true);
//    ui->twTime->setUpdatesEnabled(true);



    for (int i = 0;  i < maxSize; i++) {

        ui->twCompare->setItem(i, 0, new QTableWidgetItem(QString::number(sizes[i])));
        ui->twRead->setItem(i, 0, new QTableWidgetItem(QString::number(sizes[i])));
        ui->twTime->setItem(i, 0, new QTableWidgetItem(QString::number(sizes[i])));
        ui->twCycle->setItem(i, 0, new QTableWidgetItem(QString::number(sizes[i])));
        qApp->processEvents();

        fl->generateRandom(sizes[i]);
        fl->newSort();

        ui->twCompare->setItem(i, 1, new QTableWidgetItem(QString::number(fl->getCompares())));
        ui->twRead->setItem(i, 1, new QTableWidgetItem(QString::number(fl->getReads())));
        ui->twTime->setItem(i, 1, new QTableWidgetItem(QString::number((fl->getTime()))));
        ui->twCycle->setItem(i, 1, new QTableWidgetItem(QString::number((fl->getCycleCount()))));
        qApp->processEvents();

        fl->generateReverse(sizes[i]);
        fl->newSort();
        ui->twCompare->setItem(i, 2, new QTableWidgetItem(QString::number(fl->getCompares())));
        ui->twRead->setItem(i, 2, new QTableWidgetItem(QString::number(fl->getReads())));
        ui->twTime->setItem(i, 2, new QTableWidgetItem(QString::number((fl->getTime()))));
        ui->twCycle->setItem(i, 2, new QTableWidgetItem(QString::number((fl->getCycleCount()))));
        qApp->processEvents();

    }


}

MainWindow::~MainWindow() {
    delete fl;
    delete ui;
}

void MainWindow::on_pbGenerate_clicked() {
    sz = ui->sbSize->value();
    ui->lwRandom->clear();
    ui->lwSorted->clear();
    fl->generateRandom(sz);
    //fl->generateReverse(sz);
    ifstream fin(fl->getFilename().c_str());
    int data;
    for (int i = 0; i < sz; i++) {
        fin >> data;
        ui->lwRandom->addItem(QString::number(data));
    }
    fin.close();

}

void MainWindow::on_pbSort_clicked() {
    ifstream fin(fl->getFilename().c_str());
    //fl->sort();
    fl->newSort();
    int data;
    for (int i = 0; i < sz; i++) {
        fin >> data;
        ui->lwSorted->addItem(QString::number(data));
    }
    fin.close();

}
