#include "file.h"

File::File() {
    time = 0;
    compCount = 0;
    readCount = 0;
    cycleCount = 0;
}

void File::generateRandom(int maxSize) {
    remove(name.c_str());
    string fname = "tmp";
    ofstream fout (fname.c_str());
    int sz = maxSize;// rand() % maxSize + 15;
    fout << " " << rand() % 3333;
    for (int i = 1; i < sz; i++)
        fout << " " << rand() % 3333;
    fout.close();
    this->name = fname;
}

void File::generateReverse(int maxSize) {
    remove(name.c_str());
    string fname = "tmp";
    ofstream fout (fname.c_str());
    int sz = maxSize;// rand() % maxSize;
    fout << " " << sz;
    for (int i = sz-1; i > 0; i--)
        fout << " " << i;
    fout.close();
    this->name = fname;
}

string File::getFilename() {
    return this->name;
}

int File::getCompares() {
    return this->compCount;
}

int File::getReads() {
    return this->readCount;
}

int File::getCycleCount() {
    return this->cycleCount;
}

double File::getTime() {
    return this->time;
}


void File::setName(string &_name) {
    name = _name;
}


void File::newSort() {
    time = 0;
    compCount = 0;
    readCount = 0;
    cycleCount = 0;


    f = MyFile(name);
    string name1 = "nmsort_1";
    string name2 = "nmsort_2";
    f1 = MyFile(name1);
    f2 = MyFile(name2);

    int t1 = clock();
    do {
        cycleCount++;
        newDistribute();
        newMerge();
    } while (count > 1);
    int t2 = clock();
    this->time = 1.0*(t2 - t1) / CLOCKS_PER_SEC;

    f1.deleteFile();
    f2.deleteFile();
}

int File::getLast() {
    int result = INT_MAX;
    if (f.getLast() < result && !f.isEosec())
        result = f.getLast();
}

void File::newDistribute() {

    readCount++;

    f.openRead();
    f1.openWrite();
    f2.openWrite();


    if (!f.isEof()) {
        compCount += f.copySec(f1);
        count++;
        f.nextSec();
    }
    if (!f.isEof()){
        compCount += f.copySec(f2);
        count++;
        f.nextSec();
    }
    int dest = 1;
    while (!f.isEof()) {
        compCount++;
        if (dest == 1) {
            //продолжение серии
            if (f.getLast() >= f1.getLast()) {
                compCount += f.copySec(f1);
                f.nextSec();
            }
            compCount += f.copySec(f1);
            f.nextSec();
            dest = 2;
        } else {
            //продолжение серии
            if (f.getLast() >= f2.getLast()) {
                compCount += f.copySec(f2);
                f.nextSec();
            }
            compCount += f.copySec(f2);
            f.nextSec();
            dest = 1;
        }

    }
    f.closeFile();
    f1.closeFile();
    f2.closeFile();
}

void File::newMerge() {

    f.openWrite();
    f1.openRead();
    f2.openRead();

    this->readCount += 2;



    count = 0;

    while (!f1.isEof() && !f2.isEof()) {
        while (!f1.isEosec() && !f2.isEosec()) {
            this->compCount++;
            if (f1.getLast() <= f2.getLast()) {
                f1.copy(f);
            } else {
                f2.copy(f);
            }
        }

        if (!f1.isEosec()) {
            compCount += f1.copySec(f);
        }
        if (!f2.isEosec()) {
            compCount += f2.copySec(f);
        }
        f1.nextSec();
        f2.nextSec();


        count++;
    }

    //add if exists in 1 and 2
    while (!f1.isEof()) {
        compCount += f1.copySec(f);
        count++;
    }
    while (!f2.isEof()) {
        compCount += f2.copySec(f);;
        count++;
    }

    f.closeFile();
    f1.closeFile();
    f2.closeFile();
}
