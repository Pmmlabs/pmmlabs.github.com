#include "myfile.h"

MyFile::MyFile() {
}

MyFile::MyFile(string _s) {
    this->flast = 0;
    fname = _s;
    eof = true;
    feosec = true;
}

void MyFile::closeFile() {
    fclose(f);
}

int MyFile::copy(MyFile& f2) {
    int res = 0;
    fprintf(f2.getFile(), "%c", ' ');
    fprintf(f2.getFile(),"%d",this->flast);
    f2.setFlast(this->flast);

    this->eof = feof(f);

    if (!eof) {
        res++;
        fscanf(f,"%d",&flast);
    }
    feosec = (this->eof || (f2.getLast() > flast));
    return res;
}

int MyFile::copySec(MyFile& f2) {
    int res = 0;
    while (!feosec) {
        res += copy(f2);
    }
    return res;
}

void MyFile::deleteFile() {
    remove(this->fname.c_str());
}

bool MyFile::isEmpty() {
    long sz;
    fseek(f, 0, SEEK_END);
    sz = ftell(f);
    fseek(f, 0, SEEK_SET);

    return sz == 0;
}

void MyFile::nextSec() {
    this->feosec = eof;
}

void MyFile::openRead() {
    f = fopen(fname.c_str(),"rb");
    eof = this->isEmpty();
    feosec = eof;

    if (!eof)
        fscanf(f,"%d",&flast);
}

void MyFile::openWrite() {
    f = fopen(fname.c_str(),"wb");
}

bool MyFile::isEosec() {
    return this->feosec;
}

bool MyFile::isEof() {
    return this->eof;
}

FILE* MyFile::getFile() {
    return f;
}

string MyFile::getName() {
    return fname;
}

int MyFile::getLast() {
    return this->flast;
}

void MyFile::setFlast(int _i) {
    flast = _i;
}
