﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/*
 * Реализовать задачу как консольный проект. Использовать статические массивы. Функция, реализующая 
 * поставленную задачу, должна иметь параметры, передаваемые  различными способами, должна возвращать 
 * результат – массив, остальные данные передаются и возвращаются параметрами: размер исходного массива – 
 * по значению, исходный массив – по ссылке ref, размер массива – результата – по ссылке  out.
 * 
 * 2. В данной матрице размером n * n для каждой строки найти все простые числа.*/
namespace task4
{
    
    class Factor
    {
    // функция проверяет, простое ли это число
        static public bool is_simple(int num)
        {
            int j=2; // проходим по всем возможным множителям
            while (j < num && ((num % j) != 0)) // и проверяем, является ли он множителем
            {
                j++; // если нет - то шанс быть простым числом есть, продолжаем цикл.
            }
            return j == num || 1==num; //если мы вышли по первому условию, то простое.
        }                       // также простым числом является единица.
    // функция нахождения простых чисел в строке размера size с номером n_str
        static int[] find_simple(int size, int n_str, ref int[,] in_arr, out int numfactors)
        {
            int[] facts = new int[80]; // Размер 80 взят произвольно
            numfactors = 0; // сначала считаем, что простых чисел - ноль.
            for (int i = 0; i < size; i++) //проходим по всей строке
                if (is_simple(in_arr[n_str, i])) // если число простое, 
                {
                    facts[numfactors] = in_arr[n_str, i]; // добавляем его в выходной массив
                    numfactors++; // и увеличиваем счетчик простых чисел 
                }
            return facts;
        }

        public static void Main()
        {
            const int n = 5;
            int numfactors;
            int[,] in_arr = new int[n, n];
            // Заполнение матрицы произвольным образом
            int[] factors;
            Random rnd = new Random();

            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    in_arr[i, j] = rnd.Next(100);
            // печать матрицы
            Console.WriteLine("Произвольно заданная матрица:");
            for (int i = 0; i < in_arr.GetLength(0); i++)
            {
                for (int j = 0; j < in_arr.GetLength(1); j++)
                    Console.Write("\t" + in_arr[i, j]);
                Console.WriteLine();
            }

            // поиск простых чисел в матрице
            for (int j = 0; j < n; j++)
            { // проходим по всем строкам
                factors = find_simple(n, j, ref in_arr, out numfactors);
                Console.WriteLine("Простые числа из {0}-й строки: ", j+1);
                if (numfactors != 0)
                { // если простые числа есть, печатаем их
                    for (int i = 0; i < numfactors; i++)
                        Console.Write(factors[i] + " ");
                } // если нет, то выводим сообщение
                else Console.Write("Таких нет");
                Console.WriteLine();
            }
        }
    }
}

