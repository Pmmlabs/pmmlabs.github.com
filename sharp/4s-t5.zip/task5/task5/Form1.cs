﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
/*6.	Прямая на плоскости может быть задана уравнением ax + by = c, 
 * где a, b одновременно не равны нулю, a, b, c – целые. Пусть даны коэффициенты 
 * нескольких прямых a1, b1, c1, a2, b2, c2, ..., an, bn, cn. Определить, имеются ли 
 * среди этих прямых три прямые, пересекающиеся в одной точке.*/
namespace task5
{
    public partial class Form1 : Form
    {
        int m;
        static int maxn = 10;
        TextBox[,] tb = new TextBox[maxn,3];
        public Form1()
        {
            InitializeComponent();
            Label[] Labels = new Label[maxn];
            for (m = 0; m < 3; m++)
            {
                Labels[m] = new Label();
                Labels[m].Left = 1;
                Labels[m].Top = 25 *m;
                Labels[m].Width = 40;
                this.Controls.Add(Labels[m]);
                for (int j = 0; j < 3; j++)
                { 
                    tb[m,j] = new TextBox();
                    tb[m,j].Left = 80*j + 50;
                    tb[m,j].Top = 25 * m+ 50;
                    tb[m,j].Size = new System.Drawing.Size(75, 23);
                    this.Controls.Add(tb[m,j]);
                }
            }
            m--;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            m++;
            if (m<maxn) for (int j = 0; j < 3; j++)
            {
                tb[m, j] = new TextBox();
                tb[m, j].Left = 80 * j + 50;
                tb[m, j].Top = 25 * m + 50;
                tb[m, j].Size = new System.Drawing.Size(75, 23);
                this.Controls.Add(tb[m, j]);
                button1.Top += 9;
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int[] a = new int[m+1]; // Создание соответствующих массивов нужной размерности
            int[] b = new int[m+1];
            int[] c = new int[m+1];
            for (int t = 0; t <= m; t++)
            {
                a[t] = Convert.ToInt32(tb[t, 0].Text);
                b[t] = Convert.ToInt32(tb[t, 1].Text);
                c[t] = Convert.ToInt32(tb[t, 2].Text);
            }
            bool OK = false;  // нашли или нет
            float x;  // абсцисса точки пересечения первых двух прямых
            for (int i = 0; i < m - 1 && !OK; ++i) //передвигаем а
                for (int j = i + 1; j < m && !OK; ++j) //передвигаем b
                {
                    if (b[i] * a[j] != b[j] * a[i])
                    {
                        x = (b[i] * c[j] - b[j] * c[i]) / (b[i] * a[j] - b[j] * a[i]); // вычисление абсциссы точки пересечения первых двух прямых
                        for (int k = j + 1; k <= m && !OK; ++k) // передвигаем c
                        // если прямые не параллельны, есть смысл
                        {                                // сравнить значения 3-й и 1-й функций в найденной точке х
                            OK = ((c[k] - a[k] * x) / b[k] == (c[i] - a[i] * x) / b[i]); // тогда 3 прямые и пересекутся
                        }
                    }
                }
            if (OK) label2.Text = "Cреди этих прямых имеются три прямые пересекающиеся в одной точке";
            else label2.Text = "Cреди этих прямых нет трех прямых, пересекающихся в одной точке";
        }
    }
}
