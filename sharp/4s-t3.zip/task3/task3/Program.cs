﻿/*6.	Прямая на плоскости может быть задана уравнением ax + by = c, где a, b одновременно не равны нулю, a, b, c – целые. Пусть даны коэффициенты нескольких прямых a1, b1, c1, a2, b2, c2, ..., an, bn, cn. Определить, имеются ли среди этих прямых три прямые, пересекающиеся в одной точке.*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            do // Ввод N
            {
                Console.WriteLine("Введите количество линий (не меньше трех) :");
                n = int.Parse(Console.ReadLine());
            } while (n < 3); // Защита от ввода числа, меньше чем 3
            int[] a = new int[n]; // Создание соответствующих массивов нужной размерности
            int[] b = new int[n];
            int[] c = new int[n];
            for (int i = 0; i < n; ++i)
                do  // Ввод данных в массивы
                {
                    Console.WriteLine("Ввод " + (i + 1) + " уравнения (a, b одновременно не равны нулю) :");
                    Console.Write("Введите a: "); a[i] = int.Parse(Console.ReadLine());
                    Console.Write("Введите b: "); b[i] = int.Parse(Console.ReadLine());
                    Console.Write("Введите c: "); c[i] = int.Parse(Console.ReadLine());
                } while (a[i] == 0 && b[i] == 0);  // a и b не равны нулю одновременно
            // Вывод имеющихся массивов в виде "a;b;c"
            Console.WriteLine("Исходный массив:");
            for (int i = 0; i < n; ++i)
                Console.Write("\t" + a[i] + ";" + b[i] + ";" + c[i]);
            Console.WriteLine();
            // Поиск пересекающихся прямых
            bool OK = false;  // нашли или нет
            float x;  // абсцисса точки пересечения первых двух прямых
            for (int i = 0; i < n - 2 && !OK; ++i) //передвигаем а
                for (int j = i + 1; j < n - 1 && !OK; ++j) //передвигаем b
                 if (b[i] * a[j] != b[j] * a[i])  // если прямые не параллельны, есть смысл 
		{
                    x = (b[i] * c[j] - b[j] * c[i]) / (b[i] * a[j] - b[j] * a[i]); // вычисление абсциссы точки пересечения первых двух прямых
                    for (int k = j + 1; k < n && !OK; ++k) // передвигаем c
                                                       // сравнить значения 3-й и 1-й функций в найденной точке х
                            OK = ((c[k] - a[k] * x) / b[k] == (c[i] - a[i] * x) / b[i]); // тогда 3 прямые и пересекутся
                        
                }
            if (OK) Console.WriteLine("Cреди этих прямых имеются три прямые пересекающиеся в одной точке");
            else Console.WriteLine("Cреди этих прямых нет трех прямых, пересекающихся в одной точке");
                  }
    }
}
