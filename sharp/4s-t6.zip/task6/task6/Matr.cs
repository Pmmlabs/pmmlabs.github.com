﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;

namespace task6
{
    class Matr
    {
        int FRow,     //количество строк
            FCol;     //количество столбцов
        int[,] Fmatrix; // обрабатываемая матрица

        public Matr(int n)
        {
            FRow = n;   
            FCol = n;
            Fmatrix = new int[FCol, FCol]; 
        }

        //заполнение матрицы из DataGridView
        public void GridToMatrix(DataGridView Grid)
        {
            DataGridViewCell Cell;
            for(int i=0; i<FRow; i++)
            {
                for(int j=0; j<FCol;j++)
                {
                    Cell = Grid.Rows[i].Cells[j];
                    string s = Cell.Value.ToString();
                    if (s == "")
                        Fmatrix[i, j] = 0;
                    else
                    Fmatrix[i, j] = Int32.Parse(s);
                }
            }
        }

        //вывод матрицы в DataGridView
        public void MatrixToGrid(DataGridView Grid)
        {
            //установка размеров
            int i;
            DataTable matr = new DataTable("matrix");
            DataColumn[] cols = new DataColumn[FCol];

            for (i = 0; i < FCol; i++)
            {
                cols[i] = new DataColumn(i.ToString());
                matr.Columns.Add(cols[i]);
            }


            for (i = 0; i < FRow; i++)
            {
                DataRow newRow;
                newRow = matr.NewRow();
                matr.Rows.Add(newRow);
            }
            Grid.DataSource = matr;
           
            for (i = 0; i < FCol; i++)
                Grid.Columns[i].Width = 50;

            // занесение значений
            DataGridViewCell Cell;
            for ( i = 0; i < FRow; i++)
            {
                for (int j = 0; j < FCol; j++)
                {
                   Cell=Grid.Rows[i].Cells[j];
                   Cell.Value= Fmatrix[i, j] ;
                }
            }
        }

       
        public void AddColumn()
        {
            int i, j,max;
            
            int[,] Newmatrix = new int[FRow, FCol+1];   
            for (j = 0; j < FCol; j++)
            {
                max = int.MinValue;
                for (i = 0; i < FRow; i++)
                {
                    if (max < Fmatrix[i, j]) max = Fmatrix[i, j];
                    Newmatrix[i, j] = Fmatrix[i, j];
                }
                Newmatrix[j, FCol] = max;
            }
            
            Fmatrix = new int[FRow, FCol+1];
            for (i = 0; i < FRow; i++)
                for (j = 0; j < FCol+1; j++)
                    Fmatrix[i, j] = Newmatrix[i, j];
            FCol++;
        }
    }
}
