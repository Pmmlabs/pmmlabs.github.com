﻿/*
 * 19. Добавить в конец с столбец, содержащий максимумы всех столбцов.
 * */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace task6
{

    
    public partial class Form1 : Form
    {
        int N;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //установка размера матрицы и DataGridView
            int i;
            if (textBox1.Text == "")
                N = 0;
            else
                N = Int32.Parse(textBox1.Text);
            DataTable matr = new DataTable("matrix");
            DataColumn[] cols = new DataColumn[N];

            for (i = 0; i < N; i++)
            {
                cols[i] = new DataColumn(i.ToString());
                matr.Columns.Add(cols[i]);
            }


            for (i = 0; i < N; i++)
            {
                DataRow newRow;
                newRow = matr.NewRow();
                matr.Rows.Add(newRow);
            }
            dataGridView1.DataSource = matr;
            for (i = 0; i < N; i++)
                dataGridView1.Columns[i].Width = 50;


        }

     
     
        private void button3_Click(object sender, EventArgs e)
        {
         
            Matr Mtr = new Matr(N);
            Mtr.GridToMatrix(dataGridView1);
            Mtr.AddColumn();
            Mtr.MatrixToGrid(dataGridView1);
        }
    }
    
}
