﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/****************************************************************************************/
/* 13.	Дан массив из N точек на прямой. Найти такую точку из данного массива,          */
/* сумма расстояний от которой до остальных его точек минимальна/максимальна,           */
/*  и саму эту сумму.                                                                   */
/****************************************************************************************/
namespace Z3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write ("Введите размер массива n=");
            int n = 0;
            bool err = false;
            try
            {
                n = int.Parse(Console.ReadLine());  //размер массива
            }
            catch (FormatException exc) { Console.WriteLine(exc.Message); err = true; }
            catch (OverflowException exc) { Console.WriteLine(exc.Message); err = true; }
            if (!err && n <= 0) { err = true; Console.WriteLine("Размер массива не может быть меньше или равен нулю"); }
            if (!err)
            {
                int[] mas = new int[n];
                for (int i = 0; i < n && !err; i++)
                {
                    Console.Write("mas[{0}]=",i+1); //ввод массива
                    try { mas[i] = int.Parse(Console.ReadLine()); }
                    catch (FormatException exc) { Console.WriteLine(exc.Message); err = true; }
                    catch (OverflowException exc) { Console.WriteLine(exc.Message); err = true; }
                }
                if (!err)
                {
                    int MinDistance = 0;
                    int MaxDistance = 0;
                    int MinPoint = 0;
                    int MaxPoint = 0;
                    for (int i = 1; i < n; i++)
                    {
                        MinDistance += Math.Abs(mas[i] - mas[0]);
                        MaxDistance += Math.Abs(mas[i] - mas[0]);
                    }
                    for (int i = 1; i < n; i++)
                    {
                        int Distance = 0;
                        for (int j = 0; j < n; j++)
                        {
                            if (j != i)
                                Distance += Math.Abs(mas[i] - mas[j]);        
                        }
                        if (Distance < MinDistance) { MinDistance = Distance; MinPoint = i; };
                        if (Distance > MaxDistance) { MaxDistance = Distance; MaxPoint = i; };
                    }
                    Console.WriteLine("Точка с минимальной суммой расстояний - №{0} (сумма {1})", MinPoint + 1, MinDistance);
                    Console.WriteLine("Точка с максимальной суммой расстояний - №{0} (сумма {1})", MaxPoint + 1, MaxDistance);
                }
            }
            Console.WriteLine();
            if (err) Console.WriteLine ("Программа не выполнена. ");
            Console.WriteLine("Нажмите любую клавишу для завершения...");
            Console.ReadKey();
        }
    }
}
