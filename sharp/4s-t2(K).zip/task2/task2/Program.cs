﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

//Вычислить значения функции, заданной с помощью ряда Тейлора, на интервале от X0 до Xn 
//с шагом h c заданной точностью ε. Результаты вывести в виде таблицы. 

namespace task2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите Х0: ");
            float x0 = float.Parse(Console.ReadLine());
            Console.Write("Введите Хn: ");
            float xn = float.Parse(Console.ReadLine());
            Console.Write("Введите h: ");
            float h = float.Parse(Console.ReadLine());
            Console.Write("Введите eps: ");
            float eps = float.Parse(Console.ReadLine());
            //int n = (int)((xn - x0) / h);   //div??
            int k, km;
            km = 6;
            float x00 = x0;
            while (x0 <= xn)
            {
                k = 1;
                //x section
                Console.Write("\n\nx:   ");
                while ((x00 <= xn) && (k < km))
                {
                    Console.Write("{0:f8}  ", x00);
                    x00 = x00 + h;
                    k++;
                };
                k = 1;
                //x-count section
                Console.Write("\nx-c: ");
                x00 = x0;
                while ((x00 <= xn) && (k < km))
                {
                    Console.Write("{0:f8}  ", Math.Exp(x00 * x00 * (-1)));
                    x00 = x00 + h;
                    k++;
                };
                //x-formulae section
                k = 1;
                Console.Write("\nx-f: ");
                x00 = x0;
                while ((x00 <= xn) && (k < km))
                {
                    float r = 0;
                    float xp = 1;
                    int i = 0;
                    while (Math.Abs(xp) >= eps)
                    {
                        r = r + xp;
                        xp = xp * (x00 * x00) / (i + 1) * (-1);
                        i++;
                    };
                    Console.Write("{0:f8}  ", r);
                    x00 = x00 + h;
                    k++;
                };
                x0 = x00;
            };
            Console.ReadLine();
        }
    }
}
