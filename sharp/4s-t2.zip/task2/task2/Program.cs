﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace task2
{
    class Program
    {
        static void Main(string[] args)
        {
            float x0, xn, eps, h;
            string str;
            //////// Ввод х0 ///////////
            do
            {
                Console.Write("Введите x0: ");
                str = Console.ReadLine();
                try
                {
                    x0 = float.Parse(str);
                }
                catch (FormatException exc)
                {
                    Console.WriteLine(exc.Message);
                    x0 = 0;
                }
                catch (OverflowException exc)
                {
                    Console.WriteLine(exc.Message);
                    x0 = 0;
                }
            } while (x0 < -1 || x0 > 1);
            //////// Ввод хn ///////////
            do { Console.Write("Введите Хn: ");
            str = Console.ReadLine();
            try
            {
                xn = float.Parse(str);
            }
            catch (FormatException exc)
            {
                Console.WriteLine(exc.Message);
                xn = 0;
            }
            catch (OverflowException exc)
            {
                Console.WriteLine(exc.Message);
                xn = 0;
            }
            } while (xn < -1 || xn > 1);
            //////// Ввод H ///////////
            Console.Write("Введите h: ");
            str = Console.ReadLine();
            try
            {
                h = float.Parse(str);
            }
            catch (FormatException exc)
            {
                Console.WriteLine(exc.Message);
                h = 0;
            }
            catch (OverflowException exc)
            {
                Console.WriteLine(exc.Message);
                h = 0;
            }
            //////// Ввод эписилон ///////////
            Console.Write("Введите eps: ");
            str = Console.ReadLine();
            try
            {
                eps = float.Parse(str);
            }
            catch (FormatException exc)
            {
                Console.WriteLine(exc.Message);
                eps = 0;
            }
            catch (OverflowException exc)
            {
                Console.WriteLine(exc.Message);
                eps = 0;
            }
            int k, width;
            width = 7;
            float Xcur = x0; // Текущее значение Х
            while (x0 <= xn)
            {
                k = 1;
                // Вывод строки с иксами
                Console.Write("\n\nx:               ");
                while ((Xcur <= xn) && (k < width))
                {
                    Console.Write("{0:f3}\t", Xcur);
                    Xcur +=h;
                    k++;
                };
                k = 1;
                //Вывод строки со значениями, посчитанными через функцию
                Console.Write("\nf(x) вычисл:     ");
                Xcur = x0;
                while ((Xcur <= xn) && (k < width))
                {
                    Console.Write("{0:f3}\t", Math.Asin(Xcur));
                    Xcur +=h;
                    k++;
                };
                //Вывод строки со значениями, посчитанными по формуле
                k = 1;
                Console.Write("\nf(x) по формуле: ");
                Xcur = x0;
                while ((Xcur <= xn) && (k < width))
                { // вычисление значения при текущем Х
                    float rez = 0;  // сумма слагаемых
                    float slag = Xcur; // значение текущего слагаемого
                    int i = 0; // номер слагаемого
                    float drob = Xcur;
                    float sqrXcur = Xcur * Xcur; // квадрат текущего икса
                    while (Math.Abs(slag) >= eps)   // пока слагаемое по модулю больше е
                    {
                        i++; // увеличение номера слагаемого
                        rez += slag;  // прибавление слагаемого к сумме
                        drob = drob * ((i * 2) - 1) * sqrXcur / (i * 2) ;
                        slag = drob / ((i * 2) + 1); // вычисление следующего слагаемого
                    };
                    Console.Write("{0:f3}\t", rez);
                    Xcur += h;
                    k++;
                };
                x0 = Xcur;
            };
            Console.ReadLine();
        }
    }
}
